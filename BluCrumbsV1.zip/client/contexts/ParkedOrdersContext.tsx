import { createContext, useContext, useState, ReactNode } from "react";

export interface ParkedOrderItem {
  id: string;
  originalItemId?: string; // Store original menu item ID for reference
  name: string;
  price: number;
  quantity: number;
  amount: number;
  specialInstructions?: string;
  ingredients?: string[];
  estimatedTime?: number;
  addedInVersion?: number; // Track which version this item was added in
  isNew?: boolean; // Flag for newly added items that need to be sent to stations
  completedAt?: string; // When this item was marked as completed at its station
  isCompleted?: boolean; // Flag to track if item is completed at station
}

export interface ParkedOrder {
  id: string;
  orderType: "dinein" | "takeaway" | "driveThru" | "delivery";
  tableNumber?: string;
  customerName?: string;
  customerPhone?: string;
  items: ParkedOrderItem[];
  netTotal: number;
  discount: number;
  additionalDiscount: number;
  taxableAmount: number;
  vatAmount: number;
  grandTotal: number;
  timestamp: string;
  status: "parked" | "in-kitchen" | "ready" | "paid";
  priority: "normal" | "urgent";
  branch?: string;
  site?: string;
  notes?: string;
  recommendedStation?: string;
  recommendedWorkflow?: string[];
  lastEditedAt?: string;
  version: number; // Current version number for tracking changes
  originalItems?: ParkedOrderItem[]; // Store original items for comparison
  autoRouted?: boolean; // Flag to indicate if order was automatically routed to stations
}

interface ParkedOrdersContextType {
  parkedOrders: ParkedOrder[];
  addParkedOrder: (order: ParkedOrder) => void;
  updateParkedOrder: (orderId: string, updates: Partial<ParkedOrder>) => void;
  removeParkedOrder: (orderId: string) => void;
  getParkedOrderByTable: (tableNumber: string) => ParkedOrder | undefined;
  sendOrderToKitchen: (orderId: string) => void;
  markOrderReady: (orderId: string) => void;
  markOrderPaid: (orderId: string) => void;
  sendNewItemsToKitchen: (orderId: string) => ParkedOrderItem[]; // Send only new items to kitchen
  markItemCompleted: (orderId: string, itemId: string) => void; // Mark individual item as completed
  getStationAssignment: (items: ParkedOrderItem[]) => {
    station: string;
    workflow: string[];
  }; // Get station assignment for items
}

const ParkedOrdersContext = createContext<ParkedOrdersContextType | undefined>(
  undefined,
);

interface ParkedOrdersProviderProps {
  children: ReactNode;
}

// Helper function to generate unique item ID for each order
const generateUniqueItemId = (
  originalItemId: string,
  orderId: string,
  itemIndex: number,
) => {
  // Extract just the basic item ID if it's already been processed
  const baseItemId = originalItemId.split("-")[0] || originalItemId;
  // Create a simple unique ID with order suffix and index
  const uniqueId = `${baseItemId}-${orderId.split("-").slice(-1)[0]}-${itemIndex + 1}`;
  return uniqueId;
};

// Helper function to determine station and workflow based on items
const determineStationAndWorkflow = (items: ParkedOrderItem[]) => {
  const hasGrilledItems = items.some(
    (item) =>
      item.name.toLowerCase().includes("chicken") ||
      item.name.toLowerCase().includes("burger") ||
      item.name.toLowerCase().includes("beef") ||
      item.name.toLowerCase().includes("grilled"),
  );
  const hasFriedItems = items.some(
    (item) =>
      item.name.toLowerCase().includes("fries") ||
      item.name.toLowerCase().includes("nuggets") ||
      item.name.toLowerCase().includes("fried"),
  );
  const hasSaladItems = items.some((item) =>
    item.name.toLowerCase().includes("salad"),
  );
  const hasBeverageItems = items.some(
    (item) =>
      item.name.toLowerCase().includes("drink") ||
      item.name.toLowerCase().includes("juice") ||
      item.name.toLowerCase().includes("coffee") ||
      item.name.toLowerCase().includes("tea"),
  );

  if (hasSaladItems && !hasGrilledItems && !hasFriedItems) {
    return { station: "salad", workflow: ["salad"] };
  } else if (
    hasBeverageItems &&
    !hasGrilledItems &&
    !hasFriedItems &&
    !hasSaladItems
  ) {
    return { station: "beverages", workflow: ["beverages"] };
  } else if (hasFriedItems && hasGrilledItems) {
    return { station: "grill", workflow: ["grill", "fry", "assembly"] };
  } else if (hasFriedItems) {
    return { station: "fry", workflow: ["fry", "assembly"] };
  } else if (hasGrilledItems) {
    return { station: "grill", workflow: ["grill", "assembly"] };
  } else {
    return { station: "grill", workflow: ["grill", "assembly"] }; // Default
  }
};

export function ParkedOrdersProvider({ children }: ParkedOrdersProviderProps) {
  const [parkedOrders, setParkedOrders] = useState<ParkedOrder[]>([]);

  const addParkedOrder = (order: ParkedOrder) => {
    console.log("ParkedOrdersContext: Adding order", order);

    // Automatically determine station assignment
    const { station, workflow } = determineStationAndWorkflow(order.items);

    // Initialize version and mark items with version 1, generate unique item IDs
    const initializedOrder: ParkedOrder = {
      ...order,
      version: 1,
      recommendedStation: station,
      recommendedWorkflow: workflow,
      autoRouted: true,
      items: order.items.map((item, index) => ({
        ...item,
        id: generateUniqueItemId(item.id, order.id, index), // Generate unique ID per order
        originalItemId: item.id, // Store original item ID for reference
        addedInVersion: 1,
        isNew: false, // Initial items are not "new" since order hasn't been sent to kitchen yet
        isCompleted: false,
      })),
      status: "in-kitchen", // Automatically send to kitchen instead of parking
    };

    setParkedOrders((prev) => {
      const newOrders = [...prev, initializedOrder];
      console.log(
        "ParkedOrdersContext: New orders array with auto-routing",
        newOrders,
      );
      return newOrders;
    });

    // Log automatic routing
    console.log(
      `Order ${order.id} automatically routed to ${station} station with workflow: ${workflow.join(" → ")}`,
    );
  };

  const updateParkedOrder = (
    orderId: string,
    updates: Partial<ParkedOrder>,
  ) => {
    setParkedOrders((prev) =>
      prev.map((order) => {
        if (order.id !== orderId) return order;

        const updatedOrder = { ...order, ...updates };

        // If items are being updated, handle versioning and automatic re-routing
        if (updates.items) {
          const originalItems = order.originalItems || order.items;
          const newItems = updates.items;

          // Increment version number
          updatedOrder.version = (order.version || 1) + 1;

          // Process items - new items will automatically appear in stations
          const hasNewItems = newItems.some((item) => {
            const existsInOriginal = originalItems.some(
              (origItem) => origItem.id === item.id,
            );
            return !existsInOriginal;
          });

          updatedOrder.items = newItems.map((item) => {
            const existsInOriginal = originalItems.some(
              (origItem) => origItem.id === item.id,
            );
            return {
              ...item,
              addedInVersion: existsInOriginal
                ? item.addedInVersion || 1
                : updatedOrder.version,
              isNew: false, // Don't mark as new - items appear automatically in assigned stations
              isCompleted: existsInOriginal ? item.isCompleted || false : false, // Preserve completion status for existing items
            };
          });

          // Log new items being auto-sent
          if (hasNewItems && order.status !== "parked") {
            console.log(
              `Order ${order.id} has new items that will auto-appear in assigned stations`,
            );
          }

          // Preserve original items for comparison
          if (!order.originalItems) {
            updatedOrder.originalItems = order.items;
          }

          // Automatically re-route if items changed significantly
          const { station, workflow } = determineStationAndWorkflow(newItems);
          if (station !== order.recommendedStation) {
            updatedOrder.recommendedStation = station;
            updatedOrder.recommendedWorkflow = workflow;
            updatedOrder.autoRouted = true;
            console.log(
              `Order ${order.id} automatically re-routed to ${station} station`,
            );
          }

          // Automatically send to kitchen if not already or if new items added
          if (order.status === "parked" || hasNewItems) {
            updatedOrder.status = "in-kitchen";
            if (hasNewItems && order.status !== "parked") {
              console.log(
                `Order ${order.id} updated with new items - ensuring in-kitchen status`,
              );
            } else {
              console.log(`Order ${order.id} automatically sent to kitchen`);
            }
          }
        }

        return updatedOrder;
      }),
    );
  };

  const removeParkedOrder = (orderId: string) => {
    setParkedOrders((prev) => prev.filter((order) => order.id !== orderId));
  };

  const getParkedOrderByTable = (tableNumber: string) => {
    return parkedOrders.find(
      (order) =>
        order.tableNumber === tableNumber &&
        (order.status === "parked" ||
          order.status === "in-kitchen" ||
          order.status === "ready"),
    );
  };

  const sendOrderToKitchen = (orderId: string) => {
    updateParkedOrder(orderId, { status: "in-kitchen" });
  };

  const markOrderReady = (orderId: string) => {
    updateParkedOrder(orderId, { status: "ready" });
  };

  const markOrderPaid = (orderId: string) => {
    updateParkedOrder(orderId, { status: "paid" });
    // Remove from parked orders after payment
    setTimeout(() => {
      removeParkedOrder(orderId);
    }, 1000);
  };

  const sendNewItemsToKitchen = (orderId: string): ParkedOrderItem[] => {
    const order = parkedOrders.find((o) => o.id === orderId);
    if (!order) return [];

    // Get items marked as new
    const newItems = order.items.filter((item) => item.isNew);

    if (newItems.length > 0) {
      console.log(
        `🚀 Sending ${newItems.length} new items to kitchen for order ${orderId}:`,
        newItems.map((item) => item.name),
      );

      // Clear the isNew flag for these items AND change status to 'ready' if order was ready
      // This prevents the original order from appearing in station view
      const newStatus = order.status === "ready" ? "ready" : "in-kitchen";

      updateParkedOrder(orderId, {
        items: order.items.map((item) => ({ ...item, isNew: false })),
        status: newStatus, // Keep ready orders as ready, others as in-kitchen
      });

      console.log(
        `✅ Cleared isNew flags and set status to ${newStatus} for original order ${orderId}`,
      );
    } else {
      console.log(`❌ No new items found for order ${orderId}`);
    }

    return newItems;
  };

  const markItemCompleted = (orderId: string, itemId: string) => {
    const order = parkedOrders.find((o) => o.id === orderId);
    if (!order) return;

    const updatedItems = order.items.map((item) =>
      item.id === itemId
        ? {
            ...item,
            isCompleted: true,
            completedAt: new Date().toISOString(),
          }
        : item,
    );

    // Check if all items are completed
    const allItemsCompleted = updatedItems.every((item) => item.isCompleted);

    updateParkedOrder(orderId, {
      items: updatedItems,
      ...(allItemsCompleted ? { status: "ready" as const } : {}),
    });

    console.log(`Item ${itemId} marked as completed for order ${orderId}`);
    if (allItemsCompleted) {
      console.log(`All items completed for order ${orderId} - marked as ready`);
    }
  };

  const getStationAssignment = (items: ParkedOrderItem[]) => {
    return determineStationAndWorkflow(items);
  };

  const value: ParkedOrdersContextType = {
    parkedOrders,
    addParkedOrder,
    updateParkedOrder,
    removeParkedOrder,
    getParkedOrderByTable,
    sendOrderToKitchen,
    markOrderReady,
    markOrderPaid,
    sendNewItemsToKitchen,
    markItemCompleted,
    getStationAssignment,
  };

  return (
    <ParkedOrdersContext.Provider value={value}>
      {children}
    </ParkedOrdersContext.Provider>
  );
}

export function useParkedOrders() {
  const context = useContext(ParkedOrdersContext);
  if (context === undefined) {
    throw new Error(
      "useParkedOrders must be used within a ParkedOrdersProvider",
    );
  }
  return context;
}
