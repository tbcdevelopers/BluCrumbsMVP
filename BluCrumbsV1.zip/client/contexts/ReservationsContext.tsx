import React, { createContext, useContext, useState, useEffect } from 'react';
import { Reservation, ReservationContextType, getTableStatus } from '@shared/reservations';

const ReservationsContext = createContext<ReservationContextType | undefined>(undefined);

const mockReservations: Reservation[] = [
  {
    id: "RES001",
    customer: "Ahmed Al-Rashid",
    mobileNumber: "+966501234567",
    date: "2024-01-20",
    timeStart: "19:00",
    timeEnd: "21:00",
    peopleCount: 4,
    tableNumber: "T05",
    description: "Birthday celebration",
    status: "confirmed",
    createdDate: "2024-01-18",
  },
  {
    id: "RES002",
    customer: "Sarah Johnson",
    mobileNumber: "+966509876543",
    date: "2024-01-20",
    timeStart: "20:30",
    timeEnd: "22:30",
    peopleCount: 2,
    tableNumber: "T02",
    description: "Anniversary dinner",
    status: "confirmed",
    createdDate: "2024-01-19",
  },
  {
    id: "RES003",
    customer: "Mohammed Al-Fahad",
    mobileNumber: "+966505555555",
    date: "2024-01-21",
    timeStart: "18:00",
    timeEnd: "20:00",
    peopleCount: 6,
    tableNumber: "T03",
    description: "Business meeting",
    status: "pending",
    createdDate: "2024-01-20",
  },
];

export function ReservationsProvider({ children }: { children: React.ReactNode }) {
  const [reservations, setReservations] = useState<Reservation[]>(mockReservations);

  const addReservation = (reservation: Reservation) => {
    setReservations(prev => [...prev, reservation]);
  };

  const updateReservation = (id: string, updates: Partial<Reservation>) => {
    setReservations(prev =>
      prev.map(reservation =>
        reservation.id === id ? { ...reservation, ...updates } : reservation
      )
    );
  };

  const deleteReservation = (id: string) => {
    setReservations(prev => prev.filter(reservation => reservation.id !== id));
  };

  const getTableReservations = (tableNumber: string, date?: string) => {
    return reservations.filter(reservation => {
      const matchesTable = reservation.tableNumber === tableNumber;
      const matchesDate = date ? reservation.date === date : true;
      return matchesTable && matchesDate;
    });
  };

  const isTableReserved = (tableNumber: string, currentTime?: string) => {
    const status = getTableStatus(tableNumber, reservations);
    return status !== "available";
  };

  const value: ReservationContextType = {
    reservations,
    setReservations,
    addReservation,
    updateReservation,
    deleteReservation,
    getTableReservations,
    isTableReserved,
  };

  return (
    <ReservationsContext.Provider value={value}>
      {children}
    </ReservationsContext.Provider>
  );
}

export function useReservations() {
  const context = useContext(ReservationsContext);
  if (context === undefined) {
    throw new Error('useReservations must be used within a ReservationsProvider');
  }
  return context;
}
