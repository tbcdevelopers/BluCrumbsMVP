import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Building2,
  Users,
  Package,
  Receipt,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingCart,
  ChefHat,
  Clock,
} from "lucide-react";

const stats = [
  {
    title: "Total Revenue",
    value: "$45,231.89",
    change: "+20.1%",
    changeType: "positive" as const,
    icon: DollarSign,
  },
  {
    title: "Active Orders",
    value: "23",
    change: "+5",
    changeType: "positive" as const,
    icon: ShoppingCart,
  },
  {
    title: "Staff On Duty",
    value: "12",
    change: "±0",
    changeType: "neutral" as const,
    icon: Users,
  },
  {
    title: "Low Stock Items",
    value: "7",
    change: "+2",
    changeType: "negative" as const,
    icon: Package,
  },
];

const recentOrders = [
  {
    id: "#ORD-001",
    customer: "John Doe",
    items: 3,
    total: "$24.50",
    status: "preparing",
    time: "5 min ago",
  },
  {
    id: "#ORD-002",
    customer: "Sarah Wilson",
    items: 2,
    total: "$18.75",
    status: "ready",
    time: "8 min ago",
  },
  {
    id: "#ORD-003",
    customer: "Mike Johnson",
    items: 5,
    total: "$42.00",
    status: "preparing",
    time: "12 min ago",
  },
  {
    id: "#ORD-004",
    customer: "Emily Brown",
    items: 1,
    total: "$12.25",
    status: "delivered",
    time: "15 min ago",
  },
];

const kitchenAlerts = [
  {
    type: "urgent",
    message: "Chicken breast running low - only 5 portions left",
    time: "2 min ago",
  },
  {
    type: "warning",
    message: "Table 7 has been waiting for 15+ minutes",
    time: "5 min ago",
  },
  {
    type: "info",
    message: "New staff member Jane started shift",
    time: "30 min ago",
  },
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case "preparing":
      return <Badge className="bg-yellow-100 text-yellow-800">Preparing</Badge>;
    case "ready":
      return <Badge className="bg-green-100 text-green-800">Ready</Badge>;
    case "delivered":
      return <Badge className="bg-gray-100 text-gray-800">Delivered</Badge>;
    default:
      return <Badge>{status}</Badge>;
  }
};

const getAlertColor = (type: string) => {
  switch (type) {
    case "urgent":
      return "border-l-red-500 bg-red-50";
    case "warning":
      return "border-l-yellow-500 bg-yellow-50";
    case "info":
      return "border-l-blue-500 bg-blue-50";
    default:
      return "border-l-gray-500 bg-gray-50";
  }
};

export default function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">
          Welcome back! Here's what's happening at your restaurant today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {stat.title}
              </CardTitle>
              <stat.icon className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">
                {stat.value}
              </div>
              <div className="flex items-center text-xs text-gray-600 mt-1">
                {stat.changeType === "positive" && (
                  <TrendingUp className="h-3 w-3 text-green-500 mr-1" />
                )}
                {stat.changeType === "negative" && (
                  <TrendingDown className="h-3 w-3 text-red-500 mr-1" />
                )}
                <span
                  className={
                    stat.changeType === "positive"
                      ? "text-green-600"
                      : stat.changeType === "negative"
                        ? "text-red-600"
                        : "text-gray-600"
                  }
                >
                  {stat.change}
                </span>
                <span className="ml-1">from last week</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5" />
              Recent Orders
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-3 rounded-lg border"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{order.id}</span>
                      {getStatusBadge(order.status)}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {order.customer} • {order.items} items
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{order.total}</div>
                    <div className="text-xs text-gray-500 flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {order.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Kitchen Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ChefHat className="h-5 w-5" />
              Kitchen Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {kitchenAlerts.map((alert, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg border-l-4 ${getAlertColor(alert.type)}`}
                >
                  <div className="text-sm font-medium">{alert.message}</div>
                  <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {alert.time}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button className="p-4 rounded-lg border-2 border-dashed border-gray-300 hover:border-blucrumbs-blue-500 hover:bg-blucrumbs-blue-50 transition-colors text-center">
              <Building2 className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <div className="text-sm font-medium">Add Branch</div>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-gray-300 hover:border-blucrumbs-blue-500 hover:bg-blucrumbs-blue-50 transition-colors text-center">
              <Users className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <div className="text-sm font-medium">Add Staff</div>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-gray-300 hover:border-blucrumbs-blue-500 hover:bg-blucrumbs-blue-50 transition-colors text-center">
              <Package className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <div className="text-sm font-medium">Add Inventory</div>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-gray-300 hover:border-blucrumbs-blue-500 hover:bg-blucrumbs-blue-50 transition-colors text-center">
              <ChefHat className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <div className="text-sm font-medium">New Menu Item</div>
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
