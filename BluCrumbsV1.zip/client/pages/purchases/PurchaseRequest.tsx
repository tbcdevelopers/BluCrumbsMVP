import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  ShoppingCart,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  X,
  FileText,
  Printer,
  Send,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PurchaseRequestItem {
  id: string;
  description: string;
  unitCost: number;
  quantity: number;
  netCost: number;
  discount: number;
  vatPercent: number;
  subtotal: number;
}

interface PurchaseRequest {
  id: string;
  documentNumber: string;
  vendor?: string;
  requestDate: string;
  items: PurchaseRequestItem[];
  additionalDiscountPercent: number;
  remarks: string;
  netTotal: number;
  discountAmount: number;
  additionalDiscountAmount: number;
  vatAmount: number;
  grandTotal: number;
  status: "draft" | "submitted" | "approved" | "completed" | "cancelled";
  createdBy: string;
}

const mockPurchaseRequests: PurchaseRequest[] = [
  {
    id: "1",
    documentNumber: "PR001",
    vendor: "Al-Jouf Farms",
    requestDate: "2024-01-15",
    items: [
      {
        id: "1",
        description: "Premium Olive Oil",
        unitCost: 25.5,
        quantity: 10,
        netCost: 255.0,
        discount: 5,
        vatPercent: 15,
        subtotal: 250.25,
      },
      {
        id: "2",
        description: "Fresh Tomatoes",
        unitCost: 8.0,
        quantity: 20,
        netCost: 160.0,
        discount: 0,
        vatPercent: 15,
        subtotal: 160.0,
      },
    ],
    additionalDiscountPercent: 2,
    remarks: "Regular monthly order",
    netTotal: 415.0,
    discountAmount: 12.75,
    additionalDiscountAmount: 8.3,
    vatAmount: 59.09,
    grandTotal: 453.04,
    status: "submitted",
    createdBy: "John Smith",
  },
];

const mockVendors = [
  { id: "1", name: "Al-Jouf Farms", code: "VEN001" },
  { id: "2", name: "Fresh Produce Co", code: "VEN002" },
  { id: "3", name: "Dairy Suppliers Ltd", code: "VEN003" },
  { id: "4", name: "Meat Masters", code: "VEN004" },
];

const mockInventoryItems = [
  { id: "1", description: "Premium Olive Oil", unitCost: 25.5 },
  { id: "2", description: "Fresh Tomatoes", unitCost: 8.0 },
  { id: "3", description: "Chicken Breast", unitCost: 18.0 },
  { id: "4", description: "Basmati Rice", unitCost: 12.0 },
  { id: "5", description: "White Onions", unitCost: 6.5 },
];

export default function PurchaseRequest() {
  const [requests] = useState<PurchaseRequest[]>(mockPurchaseRequests);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemSearchTerm, setItemSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<PurchaseRequest>>({
    items: [],
    additionalDiscountPercent: 0,
    remarks: "",
    requestDate: new Date().toISOString().split("T")[0],
  });

  const handleInputChange = (field: keyof PurchaseRequest, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddItem = (inventoryItem: (typeof mockInventoryItems)[0]) => {
    const existingItem = formData.items?.find(
      (item) => item.description === inventoryItem.description,
    );
    if (existingItem) {
      alert("Item already added to the request");
      return;
    }

    const newItem: PurchaseRequestItem = {
      id: `${Date.now()}`,
      description: inventoryItem.description,
      unitCost: inventoryItem.unitCost,
      quantity: 1,
      netCost: inventoryItem.unitCost,
      discount: 0,
      vatPercent: 15,
      subtotal: inventoryItem.unitCost,
    };

    setFormData((prev) => ({
      ...prev,
      items: [...(prev.items || []), newItem],
    }));
    setItemSearchTerm("");
    calculateTotals([...(formData.items || []), newItem]);
  };

  const handleRemoveItem = (itemId: string) => {
    const updatedItems =
      formData.items?.filter((item) => item.id !== itemId) || [];
    setFormData((prev) => ({
      ...prev,
      items: updatedItems,
    }));
    calculateTotals(updatedItems);
  };

  const handleItemChange = (
    itemId: string,
    field: keyof PurchaseRequestItem,
    value: number,
  ) => {
    const updatedItems =
      formData.items?.map((item) => {
        if (item.id === itemId) {
          const updatedItem = { ...item, [field]: value };

          // Recalculate based on changes
          if (field === "quantity" || field === "unitCost") {
            updatedItem.netCost = updatedItem.quantity * updatedItem.unitCost;
          }

          if (
            field === "quantity" ||
            field === "unitCost" ||
            field === "discount"
          ) {
            const afterDiscount =
              updatedItem.netCost -
              (updatedItem.netCost * updatedItem.discount) / 100;
            updatedItem.subtotal = afterDiscount;
          }

          return updatedItem;
        }
        return item;
      }) || [];

    setFormData((prev) => ({
      ...prev,
      items: updatedItems,
    }));
    calculateTotals(updatedItems);
  };

  const calculateTotals = (items: PurchaseRequestItem[]) => {
    const netTotal = items.reduce((sum, item) => sum + item.netCost, 0);
    const discountAmount = items.reduce(
      (sum, item) => sum + (item.netCost * item.discount) / 100,
      0,
    );
    const afterItemDiscounts = netTotal - discountAmount;
    const additionalDiscountAmount =
      (afterItemDiscounts * (formData.additionalDiscountPercent || 0)) / 100;
    const afterAllDiscounts = afterItemDiscounts - additionalDiscountAmount;
    const vatAmount = afterAllDiscounts * 0.15; // 15% VAT
    const grandTotal = afterAllDiscounts + vatAmount;

    setFormData((prev) => ({
      ...prev,
      netTotal,
      discountAmount,
      additionalDiscountAmount,
      vatAmount,
      grandTotal,
    }));
  };

  const resetForm = () => {
    setFormData({
      items: [],
      additionalDiscountPercent: 0,
      remarks: "",
      requestDate: new Date().toISOString().split("T")[0],
    });
    setItemSearchTerm("");
  };

  const filteredRequests = requests.filter(
    (request) =>
      request.documentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.vendor.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredInventoryItems = mockInventoryItems.filter((item) =>
    item.description.toLowerCase().includes(itemSearchTerm.toLowerCase()),
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "approved":
        return "bg-blue-100 text-blue-800";
      case "submitted":
        return "bg-yellow-100 text-yellow-800";
      case "draft":
        return "bg-gray-100 text-gray-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ShoppingCart className="h-8 w-8 text-blucrumbs-blue-500" />
            Purchase Request
          </h1>
          <p className="text-gray-600 mt-1">
            Create and manage purchase requests
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Request
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Purchase Request</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="documentNumber">Document Number</Label>
                  <Input
                    id="documentNumber"
                    value={`PR${String(requests.length + 1).padStart(3, "0")}`}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="vendor">Vendor</Label>
                  <Select
                    value={formData.vendor || ""}
                    onValueChange={(value) =>
                      handleInputChange("vendor", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select vendor (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockVendors.map((vendor) => (
                        <SelectItem key={vendor.id} value={vendor.name}>
                          {vendor.name} ({vendor.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="requestDate">Request Date *</Label>
                  <Input
                    id="requestDate"
                    type="date"
                    value={formData.requestDate || ""}
                    onChange={(e) =>
                      handleInputChange("requestDate", e.target.value)
                    }
                    required
                  />
                </div>
              </div>

              {/* Item Search */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Items</h3>
                <div>
                  <Label htmlFor="itemSearch">Item Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="itemSearch"
                      placeholder="Search items to add..."
                      value={itemSearchTerm}
                      onChange={(e) => setItemSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  {/* Search Results */}
                  {itemSearchTerm && filteredInventoryItems.length > 0 && (
                    <Card className="mt-2">
                      <CardContent className="p-2">
                        <div className="max-h-40 overflow-y-auto">
                          {filteredInventoryItems.map((item) => (
                            <div
                              key={item.id}
                              className="flex items-center justify-between p-2 hover:bg-gray-50 cursor-pointer rounded"
                              onClick={() => handleAddItem(item)}
                            >
                              <div>
                                <span className="font-medium">
                                  {item.description}
                                </span>
                                <div className="text-sm text-gray-500">
                                  Unit Cost: ${item.unitCost.toFixed(2)}
                                </div>
                              </div>
                              <Button size="sm" variant="outline">
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Items Table */}
                {formData.items && formData.items.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Request Items</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>#</TableHead>
                              <TableHead>Description</TableHead>
                              <TableHead>Unit Cost</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>Net Cost</TableHead>
                              <TableHead>Discount %</TableHead>
                              <TableHead>VAT %</TableHead>
                              <TableHead>Subtotal</TableHead>
                              <TableHead>Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {formData.items.map((item, index) => (
                              <TableRow key={item.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell className="font-medium">
                                  {item.description}
                                </TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    value={item.unitCost}
                                    onChange={(e) =>
                                      handleItemChange(
                                        item.id,
                                        "unitCost",
                                        parseFloat(e.target.value) || 0,
                                      )
                                    }
                                    className="w-24"
                                  />
                                </TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    min="0"
                                    step="0.1"
                                    value={item.quantity}
                                    onChange={(e) =>
                                      handleItemChange(
                                        item.id,
                                        "quantity",
                                        parseFloat(e.target.value) || 0,
                                      )
                                    }
                                    className="w-20"
                                  />
                                </TableCell>
                                <TableCell>
                                  ${item.netCost.toFixed(2)}
                                </TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    min="0"
                                    max="100"
                                    step="0.1"
                                    value={item.discount}
                                    onChange={(e) =>
                                      handleItemChange(
                                        item.id,
                                        "discount",
                                        parseFloat(e.target.value) || 0,
                                      )
                                    }
                                    className="w-20"
                                  />
                                </TableCell>
                                <TableCell>15%</TableCell>
                                <TableCell>
                                  ${item.subtotal.toFixed(2)}
                                </TableCell>
                                <TableCell>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleRemoveItem(item.id)}
                                    className="text-red-600 hover:text-red-800"
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Additional Information and Totals */}
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="additionalDiscountPercent">
                      Additional Discount Percentage
                    </Label>
                    <Input
                      id="additionalDiscountPercent"
                      type="number"
                      min="0"
                      max="100"
                      step="0.1"
                      value={formData.additionalDiscountPercent || 0}
                      onChange={(e) => {
                        const value = parseFloat(e.target.value) || 0;
                        handleInputChange("additionalDiscountPercent", value);
                        calculateTotals(formData.items || []);
                      }}
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <Label htmlFor="remarks">Remarks</Label>
                    <Textarea
                      id="remarks"
                      value={formData.remarks || ""}
                      onChange={(e) =>
                        handleInputChange("remarks", e.target.value)
                      }
                      placeholder="Enter any remarks..."
                      rows={4}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-lg">TOTAL</h4>
                  <div className="space-y-2 bg-gray-50 p-4 rounded">
                    <div className="flex justify-between">
                      <span>Net Total:</span>
                      <span className="font-medium">
                        ${(formData.netTotal || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Discount:</span>
                      <span className="font-medium">
                        ${(formData.discountAmount || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Additional Discount:</span>
                      <span className="font-medium">
                        ${(formData.additionalDiscountAmount || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>VAT Amount:</span>
                      <span className="font-medium">
                        ${(formData.vatAmount || 0).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between border-t pt-2 text-lg font-bold">
                      <span>Grand Total:</span>
                      <span className="text-blucrumbs-blue-600">
                        ${(formData.grandTotal || 0).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="bg-gray-100 hover:bg-gray-200"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="bg-blue-100 hover:bg-blue-200 text-blue-700"
                >
                  <Printer className="h-4 w-4 mr-2" />
                  Print
                </Button>
                <Button
                  type="button"
                  className="bg-blubites-orange-500 hover:bg-blubites-orange-600"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Post
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by document number or vendor..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Purchase Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase Requests Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredRequests.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Requests Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No requests match your search criteria."
                  : "No purchase requests have been created yet."}
              </p>
              {!searchTerm && (
                <Button
                  onClick={() => setIsAddDialogOpen(true)}
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create First Request
                </Button>
              )}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Document Number</TableHead>
                  <TableHead>Vendor</TableHead>
                  <TableHead>Request Date</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium">
                      {request.documentNumber}
                    </TableCell>
                    <TableCell>{request.vendor}</TableCell>
                    <TableCell>
                      {new Date(request.requestDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{request.items.length} items</TableCell>
                    <TableCell>${request.grandTotal.toFixed(2)}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(request.status)}>
                        {request.status.charAt(0).toUpperCase() +
                          request.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>{request.createdBy}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            Inquiry
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
