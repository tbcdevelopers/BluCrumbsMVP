import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  VendorReceivingLineItem,
  mockInventoryItemsWithExpiry,
  ReceivingSubAllocation,
} from "@shared/inventory";
import {
  Truck,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  X,
  FileText,
  Package,
  Copy,
  Calendar,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface VendorReceivingItem extends VendorReceivingLineItem {}

interface VendorReceiving {
  id: string;
  receivingNumber: string;
  vendor: string;
  poNumber: string;
  toBranch: string;
  receivingDate: string;
  items: VendorReceivingItem[];
  remarks: string;
  totalQuantityOrdered: number;
  totalQuantityShipped: number;
  totalQuantityReceived: number;
  totalQuantityShort: number;
  totalQuantityExcess: number;
  status: "pending" | "completed" | "partial" | "cancelled";
  receivedBy: string;
}

const mockVendorReceivings: VendorReceiving[] = [
  {
    id: "1",
    receivingNumber: "VR001",
    vendor: "Al-Jouf Farms",
    poNumber: "PO001",
    toBranch: "Main Kitchen",
    receivingDate: "2024-01-15",
    items: [
      {
        id: "1",
        code: "OIL001",
        description: "Premium Olive Oil",
        unitCost: 25.5,
        quantityOrdered: 10,
        quantityShipped: 10,
        quantityReceived: 10,
        quantityShort: 0,
        quantityExcess: 0,
        unit: "ltr",
        hasExpiry: true,
        subAllocations: [
          {
            id: "sub1",
            quantity: 6,
            expiryDate: "2024-12-31",
            lotNumber: "OIL001-LOT-A",
          },
          {
            id: "sub2",
            quantity: 4,
            expiryDate: "2025-01-15",
            lotNumber: "OIL001-LOT-B",
          },
        ],
      },
      {
        id: "2",
        code: "TOM001",
        description: "Fresh Tomatoes",
        unitCost: 8.0,
        quantityOrdered: 20,
        quantityShipped: 18,
        quantityReceived: 18,
        quantityShort: 2,
        quantityExcess: 0,
        unit: "kg",
        hasExpiry: true,
        subAllocations: [
          {
            id: "sub3",
            quantity: 10,
            expiryDate: "2024-02-15",
            lotNumber: "TOM001-LOT-A",
          },
          {
            id: "sub4",
            quantity: 8,
            expiryDate: "2024-02-20",
            lotNumber: "TOM001-LOT-B",
          },
        ],
      },
    ],
    remarks: "Partial shortage in tomatoes delivery",
    totalQuantityOrdered: 30,
    totalQuantityShipped: 28,
    totalQuantityReceived: 28,
    totalQuantityShort: 2,
    totalQuantityExcess: 0,
    status: "partial",
    receivedBy: "John Smith",
  },
];

const mockVendors = [
  { id: "1", name: "Al-Jouf Farms", code: "VEN001" },
  { id: "2", name: "Fresh Produce Co", code: "VEN002" },
  { id: "3", name: "Dairy Suppliers Ltd", code: "VEN003" },
  { id: "4", name: "Meat Masters", code: "VEN004" },
];

const mockPONumbers = [
  {
    id: "1",
    number: "PO001",
    vendor: "Al-Jouf Farms",
    items: [
      {
        code: "OIL001",
        description: "Premium Olive Oil",
        unitCost: 25.5,
        quantityOrdered: 10,
        unit: "ltr",
      },
      {
        code: "TOM001",
        description: "Fresh Tomatoes",
        unitCost: 8.0,
        quantityOrdered: 20,
        unit: "kg",
      },
    ],
  },
  {
    id: "2",
    number: "PO002",
    vendor: "Fresh Produce Co",
    items: [
      {
        code: "CHK001",
        description: "Chicken Breast",
        unitCost: 18.0,
        quantityOrdered: 15,
        unit: "kg",
      },
    ],
  },
  {
    id: "3",
    number: "PO003",
    vendor: "Dairy Suppliers Ltd",
    items: [
      {
        code: "RIC001",
        description: "Basmati Rice",
        unitCost: 12.0,
        quantityOrdered: 25,
        unit: "kg",
      },
    ],
  },
];

export default function VendorReceiving() {
  const [receivings] = useState<VendorReceiving[]>(mockVendorReceivings);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemSearchTerm, setItemSearchTerm] = useState("");
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());
  const [formData, setFormData] = useState<Partial<VendorReceiving>>({
    items: [],
    remarks: "",
    receivingDate: new Date().toISOString().split("T")[0],
    toBranch: "Main Kitchen",
    totalQuantityOrdered: 0,
    totalQuantityShipped: 0,
    totalQuantityReceived: 0,
    totalQuantityShort: 0,
    totalQuantityExcess: 0,
  });

  const handleInputChange = (field: keyof VendorReceiving, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleItemExpansion = (itemId: string) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(itemId)) {
      newExpanded.delete(itemId);
    } else {
      newExpanded.add(itemId);
    }
    setExpandedItems(newExpanded);
  };

  const addSubAllocation = (itemId: string) => {
    const item = formData.items?.find((i) => i.id === itemId);
    if (!item || !item.hasExpiry) return;

    const totalAllocated =
      item.subAllocations?.reduce((sum, sub) => sum + sub.quantity, 0) || 0;
    const remaining = item.quantityShipped - totalAllocated;

    if (remaining <= 0) {
      alert("No remaining quantity to allocate");
      return;
    }

    const newSubAllocation: ReceivingSubAllocation = {
      id: `sub-${Date.now()}`,
      quantity: Math.min(remaining, 1), // Default to 1 or remaining quantity
      expiryDate: "",
      lotNumber: "",
    };

    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations: [...(i.subAllocations || []), newSubAllocation],
              }
            : i,
        ) || [],
    }));

    // Auto-expand the item
    setExpandedItems((prev) => new Set(prev).add(itemId));
  };

  const removeSubAllocation = (itemId: string, subId: string) => {
    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations:
                  i.subAllocations?.filter((sub) => sub.id !== subId) || [],
              }
            : i,
        ) || [],
    }));
    updateQuantityReceived(itemId);
  };

  const updateSubAllocation = (
    itemId: string,
    subId: string,
    field: keyof ReceivingSubAllocation,
    value: any,
  ) => {
    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations:
                  i.subAllocations?.map((sub) =>
                    sub.id === subId ? { ...sub, [field]: value } : sub,
                  ) || [],
              }
            : i,
        ) || [],
    }));

    if (field === "quantity") {
      updateQuantityReceived(itemId);
    }
  };

  const updateQuantityReceived = (itemId: string) => {
    setFormData((prev) => {
      const updatedItems =
        prev.items?.map((item) => {
          if (item.id === itemId) {
            const totalSubAllocation =
              item.subAllocations?.reduce(
                (sum, sub) => sum + sub.quantity,
                0,
              ) || 0;
            const updatedItem = {
              ...item,
              quantityReceived: totalSubAllocation,
            };

            // Auto-calculate short and excess
            if (totalSubAllocation < item.quantityShipped) {
              updatedItem.quantityShort =
                item.quantityShipped - totalSubAllocation;
              updatedItem.quantityExcess = 0;
            } else if (totalSubAllocation > item.quantityShipped) {
              updatedItem.quantityShort = 0;
              updatedItem.quantityExcess =
                totalSubAllocation - item.quantityShipped;
            } else {
              updatedItem.quantityShort = 0;
              updatedItem.quantityExcess = 0;
            }

            return updatedItem;
          }
          return item;
        }) || [];

      calculateTotals(updatedItems);
      return {
        ...prev,
        items: updatedItems,
      };
    });
  };

  const copyExpiryToAll = (itemId: string, expiryDate: string) => {
    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations:
                  i.subAllocations?.map((sub) => ({
                    ...sub,
                    expiryDate,
                  })) || [],
              }
            : i,
        ) || [],
    }));
  };

  const isNearExpiry = (expiryDate: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7 && diffDays >= 0; // Within 7 days
  };

  const getRemainingQuantity = (item: VendorReceivingItem) => {
    const totalAllocated =
      item.subAllocations?.reduce((sum, sub) => sum + sub.quantity, 0) || 0;
    return item.quantityShipped - totalAllocated;
  };

  const handlePOSelection = (poNumber: string) => {
    const selectedPO = mockPONumbers.find((po) => po.number === poNumber);
    if (selectedPO) {
      // Auto-populate vendor and items from selected PO
      const poItems = selectedPO.items.map((item) => ({
        id: `${Date.now()}-${item.code}`,
        code: item.code,
        description: item.description,
        unitCost: item.unitCost,
        quantityOrdered: item.quantityOrdered,
        quantityShipped: item.quantityOrdered, // Default to ordered quantity
        quantityReceived: 0,
        quantityShort: 0,
        quantityExcess: 0,
        unit: item.unit,
        hasExpiry: true, // Assume PO items have expiry for now
        subAllocations: [],
        expiryDate: "",
        lotNumber: "",
      }));

      setFormData((prev) => ({
        ...prev,
        poNumber,
        vendor: selectedPO.vendor,
        items: poItems,
      }));

      calculateTotals(poItems);
    }
  };

  const handleAddItem = (
    inventoryItem: (typeof mockInventoryItemsWithExpiry)[0],
  ) => {
    const existingItem = formData.items?.find(
      (item) => item.code === inventoryItem.code,
    );
    if (existingItem) {
      alert("Item already added to the receiving list");
      return;
    }

    const newItem: VendorReceivingItem = {
      id: `${Date.now()}`,
      code: inventoryItem.code,
      description: inventoryItem.description,
      unitCost: inventoryItem.unitCost!,
      quantityOrdered: 0,
      quantityShipped: 0,
      quantityReceived: 0,
      quantityShort: 0,
      quantityExcess: 0,
      unit: inventoryItem.unit,
      hasExpiry: inventoryItem.hasExpiry,
      subAllocations: inventoryItem.hasExpiry ? [] : undefined,
      expiryDate: inventoryItem.hasExpiry ? "" : undefined,
      lotNumber: inventoryItem.hasExpiry ? "" : undefined,
    };

    setFormData((prev) => ({
      ...prev,
      items: [...(prev.items || []), newItem],
    }));
    setItemSearchTerm("");
  };

  const handleRemoveItem = (itemId: string) => {
    const updatedItems =
      formData.items?.filter((item) => item.id !== itemId) || [];
    setFormData((prev) => ({
      ...prev,
      items: updatedItems,
    }));
    calculateTotals(updatedItems);
  };

  const calculateTotals = (items: VendorReceivingItem[]) => {
    const totalQuantityOrdered = items.reduce(
      (sum, item) => sum + item.quantityOrdered,
      0,
    );
    const totalQuantityShipped = items.reduce(
      (sum, item) => sum + item.quantityShipped,
      0,
    );
    const totalQuantityReceived = items.reduce(
      (sum, item) => sum + item.quantityReceived,
      0,
    );
    const totalQuantityShort = items.reduce(
      (sum, item) => sum + item.quantityShort,
      0,
    );
    const totalQuantityExcess = items.reduce(
      (sum, item) => sum + item.quantityExcess,
      0,
    );

    setFormData((prev) => ({
      ...prev,
      totalQuantityOrdered,
      totalQuantityShipped,
      totalQuantityReceived,
      totalQuantityShort,
      totalQuantityExcess,
    }));
  };

  const handleQuantityChange = (
    itemId: string,
    field: string,
    value: number,
  ) => {
    const updatedItems =
      formData.items?.map((item) => {
        if (item.id === itemId) {
          const updatedItem = { ...item, [field]: value };

          // Auto-calculate short and excess when received quantity changes
          if (field === "quantityReceived" || field === "quantityShipped") {
            const received =
              field === "quantityReceived"
                ? value
                : updatedItem.quantityReceived;
            const shipped =
              field === "quantityShipped" ? value : updatedItem.quantityShipped;

            if (received < shipped) {
              updatedItem.quantityShort = shipped - received;
              updatedItem.quantityExcess = 0;
            } else if (received > shipped) {
              updatedItem.quantityShort = 0;
              updatedItem.quantityExcess = received - shipped;
            } else {
              updatedItem.quantityShort = 0;
              updatedItem.quantityExcess = 0;
            }
          }

          return updatedItem;
        }
        return item;
      }) || [];

    setFormData((prev) => ({
      ...prev,
      items: updatedItems,
    }));
    calculateTotals(updatedItems);
  };

  const resetForm = () => {
    setFormData({
      items: [],
      remarks: "",
      receivingDate: new Date().toISOString().split("T")[0],
      toBranch: "Main Kitchen",
      totalQuantityOrdered: 0,
      totalQuantityShipped: 0,
      totalQuantityReceived: 0,
      totalQuantityShort: 0,
      totalQuantityExcess: 0,
    });
    setItemSearchTerm("");
    setExpandedItems(new Set());
  };

  const filteredReceivings = receivings.filter(
    (receiving) =>
      receiving.receivingNumber
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      receiving.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      receiving.poNumber.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredInventoryItems = mockInventoryItemsWithExpiry.filter(
    (item) =>
      item.code.toLowerCase().includes(itemSearchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(itemSearchTerm.toLowerCase()),
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "partial":
        return "bg-yellow-100 text-yellow-800";
      case "pending":
        return "bg-blue-100 text-blue-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Truck className="h-8 w-8 text-blucrumbs-blue-500" />
            Vendor Receiving
          </h1>
          <p className="text-gray-600 mt-1">
            Manage vendor goods receiving and track quantities with
            sub-allocations
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Receiving
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Goods Receiving</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Header Information */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div>
                  <Label htmlFor="receivingNumber">Receiving Number</Label>
                  <Input
                    id="receivingNumber"
                    value={`VR${String(receivings.length + 1).padStart(3, "0")}`}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="vendor">Vendor *</Label>
                  <Select
                    value={formData.vendor || ""}
                    onValueChange={(value) =>
                      handleInputChange("vendor", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select vendor" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockVendors.map((vendor) => (
                        <SelectItem key={vendor.id} value={vendor.name}>
                          {vendor.name} ({vendor.code})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="poNumber">PO Number *</Label>
                  <Select
                    value={formData.poNumber || ""}
                    onValueChange={handlePOSelection}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select PO" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockPONumbers.map((po) => (
                        <SelectItem key={po.id} value={po.number}>
                          {po.number} - {po.vendor}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toBranch">To Branch</Label>
                  <Input
                    id="toBranch"
                    value={formData.toBranch || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="receivingDate">Receiving Date</Label>
                  <Input
                    id="receivingDate"
                    value={formData.receivingDate || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
              </div>

              {/* Item Search */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Items</h3>
                <div>
                  <Label htmlFor="itemSearch">Item Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="itemSearch"
                      placeholder="Search items by code or description..."
                      value={itemSearchTerm}
                      onChange={(e) => setItemSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  {/* Search Results */}
                  {itemSearchTerm && filteredInventoryItems.length > 0 && (
                    <Card className="mt-2">
                      <CardContent className="p-2">
                        <div className="max-h-40 overflow-y-auto">
                          {filteredInventoryItems.map((item) => (
                            <div
                              key={item.code}
                              className="flex items-center justify-between p-2 hover:bg-gray-50 cursor-pointer rounded"
                              onClick={() => handleAddItem(item)}
                            >
                              <div>
                                <span className="font-medium">{item.code}</span>{" "}
                                - {item.description}
                                <div className="text-sm text-gray-500">
                                  Unit Cost: ${item.unitCost!.toFixed(2)} per{" "}
                                  {item.unit}
                                  {item.hasExpiry && (
                                    <span className="ml-2 text-orange-600 font-medium">
                                      (Has Expiry)
                                    </span>
                                  )}
                                </div>
                              </div>
                              <Button size="sm" variant="outline">
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Items Table */}
                {formData.items && formData.items.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">
                        Receiving Items
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Unit Cost</TableHead>
                              <TableHead>Qty Ordered</TableHead>
                              <TableHead>Qty Shipped</TableHead>
                              <TableHead>Qty Received</TableHead>
                              <TableHead>Expiry/Lot Info</TableHead>
                              <TableHead>Qty Short</TableHead>
                              <TableHead>Qty Excess</TableHead>
                              <TableHead>Unit</TableHead>
                              <TableHead>Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {formData.items.map((item) => (
                              <React.Fragment key={item.id}>
                                {/* Main Item Row */}
                                <TableRow
                                  className={
                                    item.hasExpiry &&
                                    item.subAllocations &&
                                    item.subAllocations.length > 0
                                      ? "bg-blue-50"
                                      : ""
                                  }
                                >
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      {item.hasExpiry && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          onClick={() =>
                                            toggleItemExpansion(item.id)
                                          }
                                          className="p-1 h-6 w-6"
                                        >
                                          {expandedItems.has(item.id) ? (
                                            <ChevronDown className="h-4 w-4" />
                                          ) : (
                                            <ChevronRight className="h-4 w-4" />
                                          )}
                                        </Button>
                                      )}
                                      <div>
                                        <div className="font-medium">
                                          {item.code}
                                        </div>
                                        <div className="text-sm text-gray-600">
                                          {item.description}
                                        </div>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    ${item.unitCost.toFixed(2)}
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      type="number"
                                      min="0"
                                      step="0.1"
                                      value={item.quantityOrdered}
                                      onChange={(e) =>
                                        handleQuantityChange(
                                          item.id,
                                          "quantityOrdered",
                                          parseFloat(e.target.value) || 0,
                                        )
                                      }
                                      className="w-20"
                                    />
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      type="number"
                                      min="0"
                                      step="0.1"
                                      value={item.quantityShipped}
                                      onChange={(e) =>
                                        handleQuantityChange(
                                          item.id,
                                          "quantityShipped",
                                          parseFloat(e.target.value) || 0,
                                        )
                                      }
                                      className="w-20"
                                    />
                                  </TableCell>
                                  <TableCell>
                                    {item.hasExpiry ? (
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium">
                                          {item.quantityReceived}
                                        </span>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() =>
                                            addSubAllocation(item.id)
                                          }
                                          className="h-6 px-2 text-xs"
                                          disabled={
                                            getRemainingQuantity(item) <= 0
                                          }
                                        >
                                          <Plus className="h-3 w-3 mr-1" />
                                          Sub
                                        </Button>
                                      </div>
                                    ) : (
                                      <Input
                                        type="number"
                                        min="0"
                                        step="0.1"
                                        value={item.quantityReceived}
                                        onChange={(e) =>
                                          handleQuantityChange(
                                            item.id,
                                            "quantityReceived",
                                            parseFloat(e.target.value) || 0,
                                          )
                                        }
                                        className="w-20"
                                        required
                                      />
                                    )}
                                  </TableCell>
                                  <TableCell>
                                    {item.hasExpiry ? (
                                      <div className="text-sm">
                                        {item.subAllocations &&
                                        item.subAllocations.length > 0 ? (
                                          <span className="text-blue-600">
                                            {item.subAllocations.length}{" "}
                                            sub-allocations
                                          </span>
                                        ) : (
                                          <span className="text-gray-400">
                                            No sub-allocations
                                          </span>
                                        )}
                                      </div>
                                    ) : (
                                      <span className="text-gray-400 text-sm">
                                        N/A
                                      </span>
                                    )}
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      value={item.quantityShort}
                                      readOnly
                                      className="w-20 bg-red-50 text-red-700 font-medium"
                                    />
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      value={item.quantityExcess}
                                      readOnly
                                      className="w-20 bg-green-50 text-green-700 font-medium"
                                    />
                                  </TableCell>
                                  <TableCell>{item.unit}</TableCell>
                                  <TableCell>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleRemoveItem(item.id)}
                                      className="text-red-600 hover:text-red-800"
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </TableCell>
                                </TableRow>

                                {/* Sub-allocation Rows */}
                                {item.hasExpiry &&
                                  expandedItems.has(item.id) && (
                                    <>
                                      {/* Sub-allocation header */}
                                      <TableRow className="bg-gray-50">
                                        <TableCell
                                          colSpan={2}
                                          className="pl-12 text-sm font-medium"
                                        >
                                          Sub-allocations
                                          {item.subAllocations &&
                                            item.subAllocations.length > 0 && (
                                              <span className="ml-2 text-xs text-gray-500">
                                                (Remaining:{" "}
                                                {getRemainingQuantity(item)}{" "}
                                                {item.unit})
                                              </span>
                                            )}
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          Quantity
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          Expiry Date
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          <div className="flex items-center gap-2">
                                            Lot Number
                                            {item.subAllocations &&
                                              item.subAllocations.length >
                                                1 && (
                                                <Button
                                                  variant="ghost"
                                                  size="sm"
                                                  onClick={() => {
                                                    const firstExpiry =
                                                      item.subAllocations![0]
                                                        ?.expiryDate;
                                                    if (firstExpiry) {
                                                      copyExpiryToAll(
                                                        item.id,
                                                        firstExpiry,
                                                      );
                                                    }
                                                  }}
                                                  className="h-5 px-1 text-xs"
                                                  title="Copy first expiry date to all"
                                                >
                                                  <Copy className="h-3 w-3" />
                                                </Button>
                                              )}
                                          </div>
                                        </TableCell>
                                        <TableCell colSpan={3}></TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          Actions
                                        </TableCell>
                                      </TableRow>

                                      {/* Sub-allocation data rows */}
                                      {item.subAllocations?.map(
                                        (subAllocation, index) => (
                                          <TableRow
                                            key={subAllocation.id}
                                            className="bg-gray-25"
                                          >
                                            <TableCell
                                              colSpan={2}
                                              className="pl-16 text-sm"
                                            >
                                              Sub #{index + 1}
                                            </TableCell>
                                            <TableCell>
                                              <Input
                                                type="number"
                                                min="0"
                                                max={
                                                  getRemainingQuantity(item) +
                                                  subAllocation.quantity
                                                }
                                                step="0.1"
                                                value={subAllocation.quantity}
                                                onChange={(e) =>
                                                  updateSubAllocation(
                                                    item.id,
                                                    subAllocation.id,
                                                    "quantity",
                                                    parseFloat(
                                                      e.target.value,
                                                    ) || 0,
                                                  )
                                                }
                                                className="w-20"
                                                required
                                              />
                                            </TableCell>
                                            <TableCell>
                                              <div className="flex items-center gap-1">
                                                <Input
                                                  type="date"
                                                  value={
                                                    subAllocation.expiryDate
                                                  }
                                                  onChange={(e) =>
                                                    updateSubAllocation(
                                                      item.id,
                                                      subAllocation.id,
                                                      "expiryDate",
                                                      e.target.value,
                                                    )
                                                  }
                                                  className={`w-32 ${
                                                    isNearExpiry(
                                                      subAllocation.expiryDate,
                                                    )
                                                      ? "border-orange-500 bg-orange-50"
                                                      : ""
                                                  }`}
                                                  required
                                                />
                                                {isNearExpiry(
                                                  subAllocation.expiryDate,
                                                ) && (
                                                  <AlertTriangle
                                                    className="h-4 w-4 text-orange-500"
                                                    aria-label="Expires within 7 days"
                                                  />
                                                )}
                                              </div>
                                            </TableCell>
                                            <TableCell>
                                              <Input
                                                type="text"
                                                placeholder="Lot #"
                                                value={subAllocation.lotNumber}
                                                onChange={(e) =>
                                                  updateSubAllocation(
                                                    item.id,
                                                    subAllocation.id,
                                                    "lotNumber",
                                                    e.target.value,
                                                  )
                                                }
                                                className="w-24"
                                                required
                                              />
                                            </TableCell>
                                            <TableCell colSpan={3}></TableCell>
                                            <TableCell>
                                              <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() =>
                                                  removeSubAllocation(
                                                    item.id,
                                                    subAllocation.id,
                                                  )
                                                }
                                                className="text-red-600 hover:text-red-800 h-6 w-6 p-0"
                                              >
                                                <X className="h-3 w-3" />
                                              </Button>
                                            </TableCell>
                                          </TableRow>
                                        ),
                                      )}
                                    </>
                                  )}
                              </React.Fragment>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Footer - Remarks and Totals */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="remarks">Remarks</Label>
                  <Textarea
                    id="remarks"
                    value={formData.remarks || ""}
                    onChange={(e) =>
                      handleInputChange("remarks", e.target.value)
                    }
                    placeholder="Enter any remarks about this receiving..."
                    rows={6}
                  />
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-lg">TOTAL QUANTITIES</h4>
                  <div className="space-y-2 bg-gray-50 p-4 rounded">
                    <div className="flex justify-between">
                      <span>Total Quantity Ordered:</span>
                      <span className="font-medium">
                        {formData.totalQuantityOrdered || 0}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Quantity Shipped:</span>
                      <span className="font-medium">
                        {formData.totalQuantityShipped || 0}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Quantity Received:</span>
                      <span className="font-medium text-blue-600">
                        {formData.totalQuantityReceived || 0}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Quantity Short:</span>
                      <span className="font-medium text-red-600">
                        {formData.totalQuantityShort || 0}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Quantity Excess:</span>
                      <span className="font-medium text-green-600">
                        {formData.totalQuantityExcess || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                  onClick={() => {
                    // Handle form submission here
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Save Receiving
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by receiving number, vendor, or PO number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Vendor Receiving Table */}
      <Card>
        <CardHeader>
          <CardTitle>Vendor Receiving Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredReceivings.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Receivings Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No receivings match your search criteria."
                  : "No vendor receivings have been created yet."}
              </p>
              {!searchTerm && (
                <Button
                  onClick={() => setIsAddDialogOpen(true)}
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create First Receiving
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Receiving Number</TableHead>
                    <TableHead>Vendor</TableHead>
                    <TableHead>PO Number</TableHead>
                    <TableHead>To Branch</TableHead>
                    <TableHead>Receiving Date</TableHead>
                    <TableHead>Items</TableHead>
                    <TableHead>Ordered</TableHead>
                    <TableHead>Shipped</TableHead>
                    <TableHead>Received</TableHead>
                    <TableHead>Short</TableHead>
                    <TableHead>Excess</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReceivings.map((receiving) => (
                    <TableRow key={receiving.id}>
                      <TableCell className="font-medium">
                        {receiving.receivingNumber}
                      </TableCell>
                      <TableCell>{receiving.vendor}</TableCell>
                      <TableCell>{receiving.poNumber}</TableCell>
                      <TableCell>{receiving.toBranch}</TableCell>
                      <TableCell>
                        {new Date(receiving.receivingDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{receiving.items.length} items</TableCell>
                      <TableCell>{receiving.totalQuantityOrdered}</TableCell>
                      <TableCell>{receiving.totalQuantityShipped}</TableCell>
                      <TableCell>
                        <Badge className="bg-blue-100 text-blue-800">
                          {receiving.totalQuantityReceived}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            receiving.totalQuantityShort > 0
                              ? "bg-red-100 text-red-800"
                              : "bg-gray-100 text-gray-800"
                          }
                        >
                          {receiving.totalQuantityShort}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            receiving.totalQuantityExcess > 0
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }
                        >
                          {receiving.totalQuantityExcess}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(receiving.status)}>
                          {receiving.status.charAt(0).toUpperCase() +
                            receiving.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <FileText className="mr-2 h-4 w-4" />
                              Inquiry
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
