import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Package, Plus, Search, Edit, Eye, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Storage {
  id: string;
  branch: string;
  floor: string;
  section: string;
  description: string;
  arabicDescription: string;
  internalRequest: boolean;
  isDefault: boolean;
  status: "active" | "inactive";
}

const mockStorages: Storage[] = [
  {
    id: "ST001",
    branch: "Main Branch - Riyadh",
    floor: "Ground Floor",
    section: "Section A",
    description: "Main Kitchen Storage",
    arabicDescription: "مخزن المطبخ الرئيسي",
    internalRequest: true,
    isDefault: true,
    status: "active",
  },
  {
    id: "ST002",
    branch: "Main Branch - Riyadh",
    floor: "First Floor",
    section: "Section B",
    description: "Dry Goods Storage",
    arabicDescription: "مخزن البضائع الجافة",
    internalRequest: false,
    isDefault: false,
    status: "active",
  },
];

export default function Storage() {
  const [storages] = useState<Storage[]>(mockStorages);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<Storage>>({
    internalRequest: false,
    isDefault: false,
    status: "active",
  });

  const handleInputChange = (field: keyof Storage, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setFormData({
      internalRequest: false,
      isDefault: false,
      status: "active",
    });
  };

  const filteredStorages = storages.filter(
    (storage) =>
      storage.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      storage.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      storage.branch.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Package className="h-8 w-8 text-blucrumbs-blue-500" />
            Storage Page
          </h1>
          <p className="text-gray-600 mt-1">
            Manage storage locations and configurations
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Storage
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Storage</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="branch">Branch *</Label>
                  <Select
                    value={formData.branch || ""}
                    onValueChange={(value) =>
                      handleInputChange("branch", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="main-riyadh">
                        Main Branch - Riyadh
                      </SelectItem>
                      <SelectItem value="branch-jeddah">
                        Branch - Jeddah
                      </SelectItem>
                      <SelectItem value="branch-dammam">
                        Branch - Dammam
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="floor">Floor *</Label>
                  <Select
                    value={formData.floor || ""}
                    onValueChange={(value) => handleInputChange("floor", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select floor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ground">Ground Floor</SelectItem>
                      <SelectItem value="first">First Floor</SelectItem>
                      <SelectItem value="second">Second Floor</SelectItem>
                      <SelectItem value="basement">Basement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="section">Section *</Label>
                  <Select
                    value={formData.section || ""}
                    onValueChange={(value) =>
                      handleInputChange("section", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select section" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="section-a">Section A</SelectItem>
                      <SelectItem value="section-b">Section B</SelectItem>
                      <SelectItem value="section-c">Section C</SelectItem>
                      <SelectItem value="section-d">Section D</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="storageId">ID *</Label>
                  <Input
                    id="storageId"
                    value={formData.id || ""}
                    onChange={(e) => handleInputChange("id", e.target.value)}
                    placeholder="Enter storage ID"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter description"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">
                    Arabic Description *
                  </Label>
                  <Input
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="Enter Arabic description"
                    dir="rtl"
                    required
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="internalRequest"
                    checked={formData.internalRequest || false}
                    onCheckedChange={(checked) =>
                      handleInputChange("internalRequest", checked)
                    }
                  />
                  <Label htmlFor="internalRequest">Internal Request</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="setAsDefault"
                    checked={formData.isDefault || false}
                    onCheckedChange={(checked) =>
                      handleInputChange("isDefault", checked)
                    }
                  />
                  <Label htmlFor="setAsDefault">Set as Default Storage</Label>
                </div>
              </div>

              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-4 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Storage
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search storages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Storage Table */}
      <Card>
        <CardHeader>
          <CardTitle>Storage Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredStorages.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Branch</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Arabic Description</TableHead>
                  <TableHead>Floor</TableHead>
                  <TableHead>Section</TableHead>
                  <TableHead>Internal Request</TableHead>
                  <TableHead>Default</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStorages.map((storage) => (
                  <TableRow key={storage.id}>
                    <TableCell>{storage.branch}</TableCell>
                    <TableCell className="font-medium">{storage.id}</TableCell>
                    <TableCell>{storage.description}</TableCell>
                    <TableCell dir="rtl">{storage.arabicDescription}</TableCell>
                    <TableCell>{storage.floor}</TableCell>
                    <TableCell>{storage.section}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          storage.internalRequest
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }
                      >
                        {storage.internalRequest ? "Yes" : "No"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          storage.isDefault
                            ? "bg-blue-100 text-blue-800"
                            : "bg-gray-100 text-gray-800"
                        }
                      >
                        {storage.isDefault ? "Default" : "No"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          storage.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {storage.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Package className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Storage Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No storage locations match your search criteria."
                  : "Get started by adding your first storage location."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Storage
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
