import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Users,
  Plus,
  Search,
  Edit,
  Trash2,
  MoreHorizontal,
  Settings,
} from "lucide-react";

interface Team {
  id: string;
  name: string;
  arabicName: string;
  memberCount?: number;
  isActive: boolean;
  createdDate: string;
}

const mockTeams: Team[] = [
  {
    id: "T001",
    name: "Kitchen Staff",
    arabicName: "طاقم المطبخ",
    memberCount: 8,
    isActive: true,
    createdDate: "2024-01-15",
  },
  {
    id: "T002",
    name: "Service Team",
    arabicName: "فريق الخدمة",
    memberCount: 12,
    isActive: true,
    createdDate: "2024-01-16",
  },
  {
    id: "T003",
    name: "Management",
    arabicName: "الإدارة",
    memberCount: 5,
    isActive: true,
    createdDate: "2024-01-10",
  },
  {
    id: "T004",
    name: "Cleaning Staff",
    arabicName: "فريق النظافة",
    memberCount: 4,
    isActive: false,
    createdDate: "2024-01-20",
  },
];

export default function Teams() {
  const [teams, setTeams] = useState<Team[]>(mockTeams);
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [formData, setFormData] = useState<Partial<Team>>({
    name: "",
    arabicName: "",
    isActive: true,
  });

  const filteredTeams = teams.filter(
    (team) =>
      team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      team.arabicName.includes(searchTerm) ||
      team.id.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const handleAdd = () => {
    if (!formData.name || !formData.arabicName) {
      alert("Please fill in all required fields");
      return;
    }

    const newTeam: Team = {
      id: `T${String(teams.length + 1).padStart(3, "0")}`,
      name: formData.name,
      arabicName: formData.arabicName,
      memberCount: 0,
      isActive: formData.isActive ?? true,
      createdDate: new Date().toISOString().split("T")[0],
    };

    setTeams([...teams, newTeam]);
    setFormData({ name: "", arabicName: "", isActive: true });
    setIsAddDialogOpen(false);
    alert("Team added successfully!");
  };

  const handleEdit = () => {
    if (!selectedTeam || !formData.name || !formData.arabicName) {
      alert("Please fill in all required fields");
      return;
    }

    setTeams(
      teams.map((team) =>
        team.id === selectedTeam.id
          ? {
              ...team,
              name: formData.name,
              arabicName: formData.arabicName,
              isActive: formData.isActive ?? true,
            }
          : team,
      ),
    );

    setIsEditDialogOpen(false);
    setSelectedTeam(null);
    setFormData({ name: "", arabicName: "", isActive: true });
    alert("Team updated successfully!");
  };

  const handleDelete = (team: Team) => {
    if (confirm(`Are you sure you want to delete team "${team.name}"?`)) {
      setTeams(teams.filter((t) => t.id !== team.id));
      alert("Team deleted successfully!");
    }
  };

  const openEditDialog = (team: Team) => {
    setSelectedTeam(team);
    setFormData({
      name: team.name,
      arabicName: team.arabicName,
      isActive: team.isActive,
    });
    setIsEditDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({ name: "", arabicName: "", isActive: true });
    setSelectedTeam(null);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Users className="h-8 w-8 text-blucrumbs-blue-500" />
            Teams
          </h1>
          <p className="text-gray-600 mt-1">
            Manage teams and team assignments
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Team
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Team</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Team Name *</Label>
                <Input
                  id="name"
                  value={formData.name || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Enter team name"
                />
              </div>
              <div>
                <Label htmlFor="arabicName">Arabic Name *</Label>
                <Input
                  id="arabicName"
                  value={formData.arabicName || ""}
                  onChange={(e) =>
                    setFormData({ ...formData, arabicName: e.target.value })
                  }
                  placeholder="Enter Arabic name"
                  dir="rtl"
                />
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={(e) =>
                    setFormData({ ...formData, isActive: e.target.checked })
                  }
                />
                <Label htmlFor="isActive">Active Team</Label>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                  onClick={handleAdd}
                >
                  Add Team
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blucrumbs-blue-600">
                {teams.length}
              </div>
              <div className="text-sm text-gray-500">Total Teams</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {teams.filter((t) => t.isActive).length}
              </div>
              <div className="text-sm text-gray-500">Active Teams</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {teams.reduce((sum, t) => sum + (t.memberCount || 0), 0)}
              </div>
              <div className="text-sm text-gray-500">Total Members</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {Math.round(
                  teams.reduce((sum, t) => sum + (t.memberCount || 0), 0) /
                    teams.filter((t) => t.isActive).length || 0,
                )}
              </div>
              <div className="text-sm text-gray-500">Avg Members/Team</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Teams List</CardTitle>
            <div className="relative w-64">
              <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Search teams..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredTeams.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Arabic Name</TableHead>
                  <TableHead>Members</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTeams.map((team) => (
                  <TableRow key={team.id}>
                    <TableCell className="font-medium">{team.id}</TableCell>
                    <TableCell>{team.name}</TableCell>
                    <TableCell dir="rtl" className="font-medium">
                      {team.arabicName}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {team.memberCount || 0} members
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          team.isActive
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }
                      >
                        {team.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(team.createdDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => openEditDialog(team)}
                          >
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => handleDelete(team)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Teams Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No teams match your search criteria."
                  : "Get started by adding your first team."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Team
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog
        open={isEditDialogOpen}
        onOpenChange={(open) => {
          setIsEditDialogOpen(open);
          if (!open) resetForm();
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Team</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="editName">Team Name *</Label>
              <Input
                id="editName"
                value={formData.name || ""}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                placeholder="Enter team name"
              />
            </div>
            <div>
              <Label htmlFor="editArabicName">Arabic Name *</Label>
              <Input
                id="editArabicName"
                value={formData.arabicName || ""}
                onChange={(e) =>
                  setFormData({ ...formData, arabicName: e.target.value })
                }
                placeholder="Enter Arabic name"
                dir="rtl"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="editIsActive"
                checked={formData.isActive}
                onChange={(e) =>
                  setFormData({ ...formData, isActive: e.target.checked })
                }
              />
              <Label htmlFor="editIsActive">Active Team</Label>
            </div>
            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={handleEdit}
              >
                Update Team
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
