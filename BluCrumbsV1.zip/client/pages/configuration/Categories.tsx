import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Tags,
  Plus,
  Search,
  Edit,
  Trash2,
  Eye,
  MoreHorizontal,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";

interface Category {
  id: string;
  name: string;
  description: string;
  status: "active" | "inactive";
  createdAt: string;
  updatedAt: string;
}

const mockCategories: Category[] = [
  {
    id: "CAT001",
    name: "Appetizers",
    description:
      "Starter dishes and small plates served before the main course",
    status: "active",
    createdAt: "2024-01-15",
    updatedAt: "2024-01-15",
  },
  {
    id: "CAT002",
    name: "Main Courses",
    description:
      "Primary dishes including meat, seafood, and vegetarian options",
    status: "active",
    createdAt: "2024-01-15",
    updatedAt: "2024-01-20",
  },
  {
    id: "CAT003",
    name: "Desserts",
    description: "Sweet dishes served at the end of the meal",
    status: "active",
    createdAt: "2024-01-15",
    updatedAt: "2024-01-15",
  },
  {
    id: "CAT004",
    name: "Beverages",
    description: "Hot and cold drinks including coffee, tea, and soft drinks",
    status: "active",
    createdAt: "2024-01-15",
    updatedAt: "2024-01-18",
  },
  {
    id: "CAT005",
    name: "Seasonal Specials",
    description: "Limited time offerings based on seasonal ingredients",
    status: "inactive",
    createdAt: "2024-01-10",
    updatedAt: "2024-01-22",
  },
];

export default function Categories() {
  const [categories, setCategories] = useState<Category[]>(mockCategories);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(
    null,
  );
  const [formData, setFormData] = useState<Partial<Category>>({
    status: "active",
  });

  const handleInputChange = (field: keyof Category, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAdd = () => {
    if (!formData.name || !formData.description) {
      alert("Please fill in all required fields");
      return;
    }

    // Check if category name already exists
    const categoryExists = categories.some(
      (category) =>
        category.name.toLowerCase() === formData.name?.toLowerCase(),
    );

    if (categoryExists) {
      alert("Category name already exists");
      return;
    }

    const newCategory: Category = {
      id: `CAT${String(categories.length + 1).padStart(3, "0")}`,
      name: formData.name!,
      description: formData.description!,
      status: formData.status || "active",
      createdAt: new Date().toISOString().split("T")[0],
      updatedAt: new Date().toISOString().split("T")[0],
    };

    setCategories((prev) => [...prev, newCategory]);
    setFormData({ status: "active" });
    setIsAddDialogOpen(false);
  };

  const handleEdit = () => {
    if (!formData.name || !formData.description || !selectedCategory) {
      alert("Please fill in all required fields");
      return;
    }

    // Check if category name already exists (excluding current category)
    const categoryExists = categories.some(
      (category) =>
        category.name.toLowerCase() === formData.name?.toLowerCase() &&
        category.id !== selectedCategory.id,
    );

    if (categoryExists) {
      alert("Category name already exists");
      return;
    }

    const updatedCategory: Category = {
      ...selectedCategory,
      name: formData.name!,
      description: formData.description!,
      status: formData.status || "active",
      updatedAt: new Date().toISOString().split("T")[0],
    };

    setCategories((prev) =>
      prev.map((category) =>
        category.id === selectedCategory.id ? updatedCategory : category,
      ),
    );

    setFormData({ status: "active" });
    setSelectedCategory(null);
    setIsEditDialogOpen(false);
  };

  const handleDelete = () => {
    if (!selectedCategory) return;

    setCategories((prev) =>
      prev.filter((category) => category.id !== selectedCategory.id),
    );

    setSelectedCategory(null);
    setIsDeleteDialogOpen(false);
  };

  const openEditDialog = (category: Category) => {
    setSelectedCategory(category);
    setFormData({
      name: category.name,
      description: category.description,
      status: category.status,
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (category: Category) => {
    setSelectedCategory(category);
    setIsDeleteDialogOpen(true);
  };

  const filteredCategories = categories.filter(
    (category) =>
      category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      category.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      category.description.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Tags className="h-8 w-8 text-blucrumbs-blue-500" />
            Categories Master
          </h1>
          <p className="text-gray-600 mt-1">
            Manage menu categories for organizing menu items
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Category
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add New Category</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="categoryName">Category Name *</Label>
                <Input
                  id="categoryName"
                  value={formData.name || ""}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter category name"
                  required
                />
              </div>
              <div>
                <Label htmlFor="categoryDescription">
                  Category Description *
                </Label>
                <Textarea
                  id="categoryDescription"
                  value={formData.description || ""}
                  onChange={(e) =>
                    handleInputChange("description", e.target.value)
                  }
                  placeholder="Enter category description"
                  rows={3}
                  required
                />
              </div>
              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-4 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    setFormData({ status: "active" });
                  }}
                >
                  Cancel
                </Button>
                <Button
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                  onClick={handleAdd}
                >
                  Save Category
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search categories..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Categories Table */}
      <Card>
        <CardHeader>
          <CardTitle>Categories List</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredCategories.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Category ID</TableHead>
                  <TableHead>Category Name</TableHead>
                  <TableHead>Category Description</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created Date</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCategories.map((category) => (
                  <TableRow key={category.id}>
                    <TableCell className="font-medium">{category.id}</TableCell>
                    <TableCell className="font-medium">
                      {category.name}
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <div className="truncate" title={category.description}>
                        {category.description}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          category.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {category.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>{category.createdAt}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => openEditDialog(category)}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => openDeleteDialog(category)}
                            className="text-red-600"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Tags className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Categories Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No categories match your search criteria."
                  : "Get started by adding your first category."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Category
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Category</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="editCategoryName">Category Name *</Label>
              <Input
                id="editCategoryName"
                value={formData.name || ""}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Enter category name"
                required
              />
            </div>
            <div>
              <Label htmlFor="editCategoryDescription">
                Category Description *
              </Label>
              <Textarea
                id="editCategoryDescription"
                value={formData.description || ""}
                onChange={(e) =>
                  handleInputChange("description", e.target.value)
                }
                placeholder="Enter category description"
                rows={3}
                required
              />
            </div>
            <div>
              <Label>Status</Label>
              <div className="flex items-center space-x-4 mt-2">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="editStatus"
                    value="active"
                    checked={formData.status === "active"}
                    onChange={(e) =>
                      handleInputChange("status", e.target.value)
                    }
                  />
                  <span className="text-sm">Active</span>
                </label>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="editStatus"
                    value="inactive"
                    checked={formData.status === "inactive"}
                    onChange={(e) =>
                      handleInputChange("status", e.target.value)
                    }
                  />
                  <span className="text-sm">Inactive</span>
                </label>
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setFormData({ status: "active" });
                  setSelectedCategory(null);
                }}
              >
                Cancel
              </Button>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={handleEdit}
              >
                Update Category
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Category</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the category "
              {selectedCategory?.name}"? This action cannot be undone and may
              affect menu items that use this category.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              onClick={() => {
                setIsDeleteDialogOpen(false);
                setSelectedCategory(null);
              }}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete Category
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
