import { useState, useCallback, useEffect } from "react";
import { useReservations } from "@/contexts/ReservationsContext";
import { getTableStatus } from "@shared/reservations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
  DragStartEvent,
  DragEndEvent,
} from "@dnd-kit/core";
import { useDraggable, useDroppable, DragOverEvent } from "@dnd-kit/core";
import {
  Layout as LayoutIcon,
  Plus,
  Edit,
  Trash2,
  Clock,
  MapPin,
  Square,
  Circle,
  RotateCcw,
  Save,
  Upload,
  Settings,
  Move,
  Ungroup,
  X,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

interface Table {
  id: string;
  number: string;
  seats: number;
  shape: "square" | "round";
  x: number;
  y: number;
  width: number;
  height: number;
  status: "available" | "occupied" | "reserved";
  originalTables?: string[]; // Store original table numbers for merged tables
}

interface Section {
  id: string;
  name: string;
  type: "indoor" | "outdoor" | "terrace";
  isActive: boolean;
  tables: Table[];
  operatingHours: {
    startTime: string;
    endTime: string;
  };
}

const mockSections: Section[] = [
  {
    id: "section1",
    name: "Section 01",
    type: "terrace",
    isActive: true,
    operatingHours: {
      startTime: "08:00",
      endTime: "23:00",
    },
    tables: [
      {
        id: "t1",
        number: "T01",
        seats: 4,
        shape: "square",
        x: 100,
        y: 100,
        width: 60,
        height: 60,
        status: "available",
      },
      {
        id: "t2",
        number: "T02",
        seats: 2,
        shape: "round",
        x: 200,
        y: 100,
        width: 50,
        height: 50,
        status: "occupied",
      },
      {
        id: "t3",
        number: "T03",
        seats: 6,
        shape: "square",
        x: 300,
        y: 100,
        width: 80,
        height: 60,
        status: "reserved",
      },
      {
        id: "t4",
        number: "T04",
        seats: 4,
        shape: "square",
        x: 100,
        y: 200,
        width: 60,
        height: 60,
        status: "available",
      },
      {
        id: "t5",
        number: "T05",
        seats: 2,
        shape: "round",
        x: 200,
        y: 200,
        width: 50,
        height: 50,
        status: "available",
      },
      {
        id: "t6",
        number: "T06",
        seats: 8,
        shape: "square",
        x: 320,
        y: 200,
        width: 100,
        height: 60,
        status: "occupied",
      },
      {
        id: "t7",
        number: "T07",
        seats: 4,
        shape: "square",
        x: 100,
        y: 300,
        width: 60,
        height: 60,
        status: "available",
      },
      {
        id: "t8",
        number: "T08",
        seats: 2,
        shape: "round",
        x: 250,
        y: 320,
        width: 50,
        height: 50,
        status: "reserved",
      },
      {
        id: "t9",
        number: "T09+T10",
        seats: 8,
        shape: "square",
        x: 450,
        y: 100,
        width: 120,
        height: 60,
        status: "available",
        originalTables: ["T09", "T10"],
      },
    ],
  },
];

const getTableStatusColor = (status: string) => {
  switch (status) {
    case "available":
      return "bg-green-500";
    case "occupied":
      return "bg-red-500";
    case "reserved":
      return "bg-yellow-500";
    default:
      return "bg-gray-500";
  }
};

interface DraggableTableProps {
  table: Table;
  onTableClick: (table: Table) => void;
  isOverlapping?: boolean;
}

function DraggableTable({
  table,
  onTableClick,
  isOverlapping,
}: DraggableTableProps) {
  const { attributes, listeners, setNodeRef, transform, isDragging } =
    useDraggable({
      id: table.id,
      data: {
        type: "table",
        table,
      },
    });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      }
    : undefined;

  const baseClasses =
    "absolute border-2 border-gray-300 cursor-move hover:border-blue-500 hover:shadow-lg transition-all duration-200 flex flex-col items-center justify-center text-white font-semibold text-xs select-none";
  const statusColor = getTableStatusColor(table.status);
  const shapeClasses = table.shape === "round" ? "rounded-full" : "rounded-lg";
  const overlappingClasses = isOverlapping
    ? "ring-4 ring-blue-400 ring-opacity-50 scale-105"
    : "";
  const draggingClasses = isDragging ? "opacity-50 z-50" : "";
  const mergedClasses =
    table.originalTables && table.originalTables.length > 1
      ? "ring-2 ring-blue-300"
      : "";

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    console.log("Table clicked:", table.number);
    onTableClick(table);
  };

  return (
    <div
      ref={setNodeRef}
      style={{
        left: table.x,
        top: table.y,
        width: table.width,
        height: table.height,
        ...style,
      }}
      className={`${baseClasses} ${statusColor} ${shapeClasses} ${overlappingClasses} ${draggingClasses} ${mergedClasses}`}
      {...listeners}
      {...attributes}
      onClick={handleClick}
    >
      <div className="text-center pointer-events-none">
        <div className="flex items-center gap-1">
          <Move className="h-3 w-3" />
          {table.number}
          {table.originalTables && table.originalTables.length > 1 && (
            <span className="text-xs bg-blue-500 text-white px-1 rounded">
              M
            </span>
          )}
        </div>
        <div className="text-xs opacity-80">{table.seats} seats</div>
      </div>
    </div>
  );
}

export default function Layout() {
  // Get reservations from context with error handling
  let reservations: any[] = [];
  try {
    const context = useReservations();
    reservations = context.reservations;
  } catch (error) {
    console.warn("ReservationsContext not available in Layout component");
    reservations = [];
  }
  const [sections, setSections] = useState<Section[]>(mockSections);
  const [selectedSection, setSelectedSection] = useState<Section>(
    mockSections[0],
  );
  const [isAddTableDialogOpen, setIsAddTableDialogOpen] = useState(false);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [newTable, setNewTable] = useState<Partial<Table>>({
    seats: 4,
    shape: "square",
    status: "available",
  });
  const [activeId, setActiveId] = useState<string | null>(null);
  const [overlappingTables, setOverlappingTables] = useState<string[]>([]);
  const [pendingMerge, setPendingMerge] = useState<{
    draggedTable: Table;
    targetTable: Table;
    updatedTable: Table;
  } | null>(null);
  const [showMergeDialog, setShowMergeDialog] = useState(false);
  const [showUnmergeDialog, setShowUnmergeDialog] = useState(false);
  const [tableToUnmerge, setTableToUnmerge] = useState<Table | null>(null);
  const [isManagementMode, setIsManagementMode] = useState(false);

  // Update table statuses based on reservations
  useEffect(() => {
    const updateTableStatuses = () => {
      setSections((prevSections) =>
        prevSections.map((section) => ({
          ...section,
          tables: section.tables.map((table) => ({
            ...table,
            status: getTableStatus(table.number, reservations),
          })),
        })),
      );

      // Update selected section as well
      setSelectedSection((prevSection) => ({
        ...prevSection,
        tables: prevSection.tables.map((table) => ({
          ...table,
          status: getTableStatus(table.number, reservations),
        })),
      }));
    };

    updateTableStatuses();

    // Update every minute to handle time-based status changes
    const interval = setInterval(updateTableStatuses, 60000);

    return () => clearInterval(interval);
  }, [reservations]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8, // Require 8px movement before starting drag
      },
    }),
    useSensor(KeyboardSensor),
  );

  const handleTableClick = (table: Table) => {
    console.log("handleTableClick called with:", table);
    // If clicking the same table, just toggle selection
    if (selectedTable?.id === table.id) {
      setSelectedTable(null);
    } else {
      // New table selected
      setSelectedTable(table);
    }
  };

  const isTablesOverlapping = (table1: Table, table2: Table): boolean => {
    const margin = 10; // Allow some margin for merging
    return (
      table1.x < table2.x + table2.width + margin &&
      table1.x + table1.width + margin > table2.x &&
      table1.y < table2.y + table2.height + margin &&
      table1.y + table1.height + margin > table2.y
    );
  };

  const findOverlappingTables = (
    draggedTable: Table,
    allTables: Table[],
  ): Table[] => {
    return allTables.filter(
      (table) =>
        table.id !== draggedTable.id &&
        isTablesOverlapping(draggedTable, table),
    );
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!active.data.current?.table) return;

    const draggedTable = active.data.current.table as Table;
    const draggedTableUpdated = {
      ...draggedTable,
      x: draggedTable.x + (event.delta?.x || 0),
      y: draggedTable.y + (event.delta?.y || 0),
    };

    const overlapping = findOverlappingTables(
      draggedTableUpdated,
      selectedSection.tables,
    );
    setOverlappingTables(overlapping.map((t) => t.id));
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, delta } = event;
    setActiveId(null);
    setOverlappingTables([]);

    if (!active.data.current?.table || !delta) return;

    const draggedTable = active.data.current.table as Table;
    const newX = Math.max(0, draggedTable.x + delta.x);
    const newY = Math.max(0, draggedTable.y + delta.y);

    const updatedTable = {
      ...draggedTable,
      x: newX,
      y: newY,
    };

    // Check for overlapping tables for merging
    const overlappingTables = findOverlappingTables(
      updatedTable,
      selectedSection.tables,
    );

    if (overlappingTables.length > 0) {
      // Show merge confirmation dialog
      const tableToMergeWith = overlappingTables[0];
      setPendingMerge({
        draggedTable,
        targetTable: tableToMergeWith,
        updatedTable,
      });
      setShowMergeDialog(true);
    } else {
      // Just update position
      setSections((prevSections) =>
        prevSections.map((section) =>
          section.id === selectedSection.id
            ? {
                ...section,
                tables: section.tables.map((table) =>
                  table.id === draggedTable.id ? updatedTable : table,
                ),
              }
            : section,
        ),
      );

      // Update selected section
      const updatedSection = {
        ...selectedSection,
        tables: selectedSection.tables.map((table) =>
          table.id === draggedTable.id ? updatedTable : table,
        ),
      };
      setSelectedSection(updatedSection);
    }
  };

  const handleSectionChange = (sectionId: string) => {
    const section = sections.find((s) => s.id === sectionId);
    if (section) {
      setSelectedSection(section);
    }
  };

  const handleOperatingHoursChange = (
    type: "startTime" | "endTime",
    value: string,
  ) => {
    const updatedSection = {
      ...selectedSection,
      operatingHours: {
        ...selectedSection.operatingHours,
        [type]: value,
      },
    };

    setSelectedSection(updatedSection);

    // Update sections array
    setSections((prevSections) =>
      prevSections.map((section) =>
        section.id === selectedSection.id ? updatedSection : section,
      ),
    );
  };

  const confirmMerge = () => {
    if (!pendingMerge) return;

    const { draggedTable, targetTable } = pendingMerge;
    const mergedSeats = draggedTable.seats + targetTable.seats;
    const mergedTable = {
      ...targetTable,
      seats: mergedSeats,
      number: `${targetTable.number}+${draggedTable.number}`,
      width: Math.max(targetTable.width, draggedTable.width + 20),
      height: Math.max(targetTable.height, draggedTable.height),
      originalTables: [
        ...(targetTable.originalTables || [targetTable.number]),
        ...(draggedTable.originalTables || [draggedTable.number]),
      ],
    };

    // Update sections with merged table and remove dragged table
    setSections((prevSections) =>
      prevSections.map((section) =>
        section.id === selectedSection.id
          ? {
              ...section,
              tables: section.tables
                .filter((table) => table.id !== draggedTable.id)
                .map((table) =>
                  table.id === targetTable.id ? mergedTable : table,
                ),
            }
          : section,
      ),
    );

    // Update selected section
    const updatedSection = {
      ...selectedSection,
      tables: selectedSection.tables
        .filter((table) => table.id !== draggedTable.id)
        .map((table) => (table.id === targetTable.id ? mergedTable : table)),
    };
    setSelectedSection(updatedSection);

    // Clean up
    setPendingMerge(null);
    setShowMergeDialog(false);
  };

  const cancelMerge = () => {
    if (!pendingMerge) return;

    // Just update position without merging
    const { draggedTable, updatedTable } = pendingMerge;

    setSections((prevSections) =>
      prevSections.map((section) =>
        section.id === selectedSection.id
          ? {
              ...section,
              tables: section.tables.map((table) =>
                table.id === draggedTable.id ? updatedTable : table,
              ),
            }
          : section,
      ),
    );

    const updatedSection = {
      ...selectedSection,
      tables: selectedSection.tables.map((table) =>
        table.id === draggedTable.id ? updatedTable : table,
      ),
    };
    setSelectedSection(updatedSection);

    // Clean up
    setPendingMerge(null);
    setShowMergeDialog(false);
  };

  const handleUnmergeTable = (table: Table) => {
    if (!table.originalTables || table.originalTables.length < 2) {
      alert("This table is not merged and cannot be unmerged.");
      return;
    }

    setTableToUnmerge(table);
    setShowUnmergeDialog(true);
  };

  const confirmUnmerge = () => {
    if (!tableToUnmerge) return;

    // Create individual tables from the merged table
    const individualTables: Table[] = tableToUnmerge.originalTables!.map(
      (originalNumber, index) => {
        const seatsPerTable = Math.floor(
          tableToUnmerge.seats / tableToUnmerge.originalTables!.length,
        );
        const remainingSeats =
          tableToUnmerge.seats % tableToUnmerge.originalTables!.length;

        return {
          id: `${tableToUnmerge.id}_unmerged_${index}`,
          number: originalNumber,
          seats: seatsPerTable + (index === 0 ? remainingSeats : 0), // Give remaining seats to first table
          shape: tableToUnmerge.shape,
          x: tableToUnmerge.x + index * 70, // Spread tables horizontally
          y: tableToUnmerge.y,
          width: Math.max(
            50,
            tableToUnmerge.width / tableToUnmerge.originalTables!.length,
          ),
          height: tableToUnmerge.height,
          status: tableToUnmerge.status,
          originalTables: undefined, // Clear merged info
        };
      },
    );

    // Update sections with unmerged tables
    setSections((prevSections) =>
      prevSections.map((section) =>
        section.id === selectedSection.id
          ? {
              ...section,
              tables: [
                ...section.tables.filter(
                  (table) => table.id !== tableToUnmerge.id,
                ),
                ...individualTables,
              ],
            }
          : section,
      ),
    );

    // Update selected section
    const updatedSection = {
      ...selectedSection,
      tables: [
        ...selectedSection.tables.filter(
          (table) => table.id !== tableToUnmerge.id,
        ),
        ...individualTables,
      ],
    };
    setSelectedSection(updatedSection);
    setSelectedTable(null); // Clear selection since the merged table no longer exists

    // Clean up
    setTableToUnmerge(null);
    setShowUnmergeDialog(false);
  };

  const cancelUnmerge = () => {
    setTableToUnmerge(null);
    setShowUnmergeDialog(false);
  };

  const handleAddTable = () => {
    if (!newTable.number || !newTable.seats) {
      alert("Please enter table number and seats");
      return;
    }

    // Check if table number already exists
    const tableExists = selectedSection.tables.some(
      (table) => table.number === newTable.number,
    );

    if (tableExists) {
      alert("Table number already exists");
      return;
    }

    const newTableData: Table = {
      id: `table_${Date.now()}`,
      number: newTable.number,
      seats: newTable.seats || 4,
      shape: newTable.shape || "square",
      x: 50 + selectedSection.tables.length * 80, // Position new tables in a row
      y: 50,
      width: newTable.shape === "round" ? 50 : 60,
      height: newTable.shape === "round" ? 50 : 60,
      status: "available",
    };

    // Update sections with new table
    setSections((prevSections) =>
      prevSections.map((section) =>
        section.id === selectedSection.id
          ? {
              ...section,
              tables: [...section.tables, newTableData],
            }
          : section,
      ),
    );

    // Update selected section
    const updatedSection = {
      ...selectedSection,
      tables: [...selectedSection.tables, newTableData],
    };
    setSelectedSection(updatedSection);

    // Reset form and close dialog
    setNewTable({
      seats: 4,
      shape: "square",
      status: "available",
    });
    setIsAddTableDialogOpen(false);
  };

  const activeTable = activeId
    ? selectedSection.tables.find((t) => t.id === activeId)
    : null;

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left Sidebar */}
      <div className="w-80 bg-white shadow-lg p-6 overflow-y-auto">
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <LayoutIcon className="h-6 w-6 text-blucrumbs-blue-500" />
              Layout
            </h1>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blucrumbs-blue-600">
                  {selectedSection.tables.length}
                </div>
                <div className="text-sm text-gray-500">TABLES</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {selectedSection.tables.reduce(
                    (sum, table) => sum + table.seats,
                    0,
                  )}
                </div>
                <div className="text-sm text-gray-500">CAPACITY</div>
              </CardContent>
            </Card>
          </div>

          {/* Floors */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Floors</h3>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                className="bg-blue-50 text-blue-600"
              >
                Ground Floor
              </Button>
              <Button size="sm" variant="outline">
                First Floor
              </Button>
            </div>
          </div>

          {/* Section Selection */}
          <div>
            <Label htmlFor="section">Section</Label>
            <Select
              value={selectedSection.id}
              onValueChange={handleSectionChange}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select section" />
              </SelectTrigger>
              <SelectContent>
                {sections.map((section) => (
                  <SelectItem key={section.id} value={section.id}>
                    {section.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Section Type */}
          <div>
            <Label>Section Type</Label>
            <div className="flex gap-2 mt-2">
              <Button
                size="sm"
                variant={
                  selectedSection.type === "indoor" ? "default" : "outline"
                }
                className={
                  selectedSection.type === "indoor" ? "bg-gray-600" : ""
                }
              >
                INDOOR
              </Button>
              <Button
                size="sm"
                variant={
                  selectedSection.type === "outdoor" ? "default" : "outline"
                }
                className={
                  selectedSection.type === "outdoor" ? "bg-gray-600" : ""
                }
              >
                OUTDOOR
              </Button>
              <Button
                size="sm"
                variant={
                  selectedSection.type === "terrace" ? "default" : "outline"
                }
                className={
                  selectedSection.type === "terrace" ? "bg-blue-600" : ""
                }
              >
                TERRACE
              </Button>
            </div>
          </div>

          {/* Operating Hours */}
          <div>
            <Label>Operating Hours</Label>
            <div className="space-y-2 mt-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gray-500" />
                <span className="text-sm">Start Time</span>
              </div>
              <Input
                type="time"
                value={selectedSection.operatingHours.startTime}
                onChange={(e) =>
                  handleOperatingHoursChange("startTime", e.target.value)
                }
                className="text-sm"
              />
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gray-500" />
                <span className="text-sm">End Time</span>
              </div>
              <Input
                type="time"
                value={selectedSection.operatingHours.endTime}
                onChange={(e) =>
                  handleOperatingHoursChange("endTime", e.target.value)
                }
                className="text-sm"
              />
            </div>
          </div>

          {/* Table Management Instructions */}
          <div>
            <Label>Table Management</Label>
            <div className="mt-2 p-4 border rounded-lg bg-gray-50 space-y-2">
              <div className="flex items-center gap-2 mb-2">
                <Square className="h-6 w-6 text-blue-600" />
                <span className="text-sm font-medium">How to Use</span>
              </div>
              <div className="space-y-1 text-xs text-gray-600">
                <div>
                  • <strong>Click</strong> on a table to select and see options
                </div>
                <div>
                  • <strong>Drag</strong> a table onto another to merge them
                </div>
                <div>
                  • <strong>Unmerge</strong> button appears for merged tables
                  only
                </div>
                <div>• Tables with "M" badge are merged</div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            <Dialog
              open={isAddTableDialogOpen}
              onOpenChange={setIsAddTableDialogOpen}
            >
              <DialogTrigger asChild>
                <Button className="w-full bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Table
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Table</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="tableNumber">Table Number</Label>
                    <Input
                      id="tableNumber"
                      value={newTable.number || ""}
                      onChange={(e) =>
                        setNewTable({ ...newTable, number: e.target.value })
                      }
                      placeholder="e.g., T09"
                    />
                  </div>
                  <div>
                    <Label htmlFor="seats">Number of Seats</Label>
                    <Input
                      id="seats"
                      type="number"
                      value={newTable.seats || ""}
                      onChange={(e) =>
                        setNewTable({
                          ...newTable,
                          seats: parseInt(e.target.value),
                        })
                      }
                      placeholder="4"
                    />
                  </div>
                  <div>
                    <Label>Table Shape</Label>
                    <div className="flex gap-2 mt-2">
                      <Button
                        size="sm"
                        variant={
                          newTable.shape === "square" ? "default" : "outline"
                        }
                        onClick={() =>
                          setNewTable({ ...newTable, shape: "square" })
                        }
                      >
                        <Square className="h-4 w-4 mr-1" />
                        Square
                      </Button>
                      <Button
                        size="sm"
                        variant={
                          newTable.shape === "round" ? "default" : "outline"
                        }
                        onClick={() =>
                          setNewTable({ ...newTable, shape: "round" })
                        }
                      >
                        <Circle className="h-4 w-4 mr-1" />
                        Round
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setIsAddTableDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                      onClick={handleAddTable}
                    >
                      Add Table
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Button variant="outline" className="w-full">
              <Upload className="h-4 w-4 mr-2" />
              Upload Image
            </Button>
          </div>
        </div>
      </div>

      {/* Main Layout Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="bg-white shadow-sm p-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              {selectedSection.name}
            </h2>
            <p className="text-sm text-gray-500">
              {selectedSection.tables.length} tables •{" "}
              {selectedSection.tables.reduce(
                (sum, table) => sum + table.seats,
                0,
              )}{" "}
              total seats
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge
              className={`${selectedSection.type === "terrace" ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800"}`}
            >
              {selectedSection.type.toUpperCase()}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              className={
                isManagementMode ? "bg-blucrumbs-blue-500 text-white" : ""
              }
              onClick={() => setIsManagementMode(!isManagementMode)}
            >
              <Settings className="h-4 w-4 mr-1" />
              {isManagementMode ? "Exit Manage" : "Manage"}
            </Button>
            <Button variant="outline" size="sm">
              <Upload className="h-4 w-4 mr-1" />
              Upload Image
            </Button>
          </div>
        </div>

        {/* Layout Canvas */}
        <div className="flex-1 p-6 overflow-auto">
          <div className="relative bg-white rounded-lg shadow-sm min-h-[600px] border-2 border-dashed border-gray-200">
            {/* Background Image */}
            <div
              className="absolute inset-0 bg-cover bg-center rounded-lg opacity-50"
              style={{
                backgroundImage: `url('${`https://cdn.builder.io/api/v1/image/assets%2F531704f2c74f4e22a03ce745905af349%2F806014e8659941fd81a6073928c5f968?format=webp&width=800`}')`,
              }}
            />

            {/* Tables Overlay */}
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
              onDragEnd={handleDragEnd}
            >
              <div className="relative z-10 w-full h-full">
                {selectedSection.tables.map((table) => (
                  <DraggableTable
                    key={table.id}
                    table={table}
                    onTableClick={handleTableClick}
                    isOverlapping={overlappingTables.includes(table.id)}
                  />
                ))}
              </div>
              <DragOverlay>
                {activeTable ? (
                  <div
                    className={`border-2 border-gray-300 cursor-move hover:border-blue-500 transition-colors flex flex-col items-center justify-center text-white font-semibold text-xs select-none ${getTableStatusColor(
                      activeTable.status,
                    )} ${
                      activeTable.shape === "round"
                        ? "rounded-full"
                        : "rounded-lg"
                    } opacity-80`}
                    style={{
                      width: activeTable.width,
                      height: activeTable.height,
                    }}
                  >
                    <div className="text-center pointer-events-none">
                      <div className="flex items-center gap-1">
                        <Move className="h-3 w-3" />
                        {activeTable.number}
                      </div>
                      <div className="text-xs opacity-80">
                        {activeTable.seats} seats
                      </div>
                    </div>
                  </div>
                ) : null}
              </DragOverlay>
            </DndContext>

            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg">
              <h4 className="text-sm font-semibold mb-2">Table Status</h4>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <span className="text-xs">Available</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded"></div>
                  <span className="text-xs">Occupied</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                  <span className="text-xs">Reserved</span>
                </div>
              </div>
            </div>

            {/* Selected Table Info */}
            {selectedTable && (
              <div className="absolute top-4 right-4 bg-white p-4 rounded-lg shadow-lg min-w-[250px] border-2 border-blucrumbs-blue-500 z-20">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">
                    Table {selectedTable.number}
                  </h4>
                  {selectedTable.originalTables &&
                    selectedTable.originalTables.length > 1 && (
                      <Badge className="bg-blue-100 text-blue-800 text-xs">
                        MERGED
                      </Badge>
                    )}
                </div>
                <div className="space-y-1 text-sm">
                  <div>Seats: {selectedTable.seats}</div>
                  <div>Shape: {selectedTable.shape}</div>
                  <div className="flex items-center gap-2">
                    Status:
                    <Badge
                      className={`${getTableStatusColor(selectedTable.status)} text-white text-xs`}
                    >
                      {selectedTable.status}
                    </Badge>
                  </div>
                  {selectedTable.originalTables && (
                    <div className="text-xs text-blue-600">
                      Merged from: {selectedTable.originalTables.join(", ")}
                    </div>
                  )}
                  {(selectedTable.status === "reserved" ||
                    selectedTable.status === "occupied") && (
                    <>
                      <div className="border-t pt-2 mt-2">
                        <h5 className="font-medium text-xs text-gray-700 mb-1">
                          Reservation Details:
                        </h5>
                        {(() => {
                          const tableReservations = reservations.filter(
                            (res) =>
                              res.tableNumber === selectedTable.number &&
                              (res.status === "confirmed" ||
                                res.status === "pending") &&
                              res.date ===
                                new Date().toISOString().split("T")[0],
                          );

                          return tableReservations.length > 0 ? (
                            tableReservations.map((reservation, index) => (
                              <div
                                key={reservation.id}
                                className="text-xs bg-gray-50 p-2 rounded mb-1"
                              >
                                <div className="font-medium">
                                  {reservation.customer}
                                </div>
                                <div>
                                  {reservation.timeStart} -{" "}
                                  {reservation.timeEnd}
                                </div>
                                <div>{reservation.peopleCount} guests</div>
                                <div className="text-gray-600">
                                  {reservation.description}
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="text-xs text-gray-500">
                              No current reservations
                            </div>
                          );
                        })()}
                      </div>
                    </>
                  )}
                </div>

                {/* Only show actions when in management mode */}
                {isManagementMode && (
                  <div className="border-t pt-3 mt-3">
                    <div className="text-xs font-medium text-gray-600 mb-3 uppercase tracking-wide">
                      Table Actions
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button size="sm" variant="outline">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      {selectedTable.originalTables &&
                      selectedTable.originalTables.length > 1 ? (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-blue-600 hover:bg-blue-50"
                          onClick={() => handleUnmergeTable(selectedTable)}
                        >
                          <Ungroup className="h-3 w-3 mr-1" />
                          Unmerge
                        </Button>
                      ) : (
                        <div className="text-xs text-gray-400 px-2 py-1">
                          (Not merged - drag onto another table to merge)
                        </div>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        Delete
                      </Button>
                    </div>
                    {selectedTable.number.includes("+") &&
                      !selectedTable.originalTables && (
                        <div className="text-xs text-red-500 mt-2 p-2 bg-red-50 rounded">
                          ⚠️ This appears to be a merged table but missing merge
                          data
                        </div>
                      )}
                  </div>
                )}

                {/* Show help text when not in management mode */}
                {!isManagementMode && (
                  <div className="border-t pt-3 mt-3">
                    <div className="text-xs text-gray-500 text-center">
                      Click "Manage" above to see table options
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Debug Panel */}
            {!selectedTable && (
              <div className="absolute top-4 right-4 bg-yellow-100 p-4 rounded-lg shadow-lg min-w-[200px] border-2 border-yellow-400 z-20">
                <div className="text-center text-yellow-800">
                  <div className="text-sm font-medium mb-1">
                    No Table Selected
                  </div>
                  <div className="text-xs">1. Click "Manage" button above</div>
                  <div className="text-xs">2. Then click on any table</div>
                  <div className="text-xs mt-2">
                    Tables: {selectedSection.tables.length}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="bg-white border-t p-4 flex justify-end gap-2">
          <Button variant="outline">
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
          <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
            <Save className="h-4 w-4 mr-2" />
            Save Layout
          </Button>
        </div>
      </div>

      {/* Merge Confirmation Dialog */}
      <Dialog open={showMergeDialog} onOpenChange={setShowMergeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Table Merge</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Are you sure you want to merge these tables?</p>
            {pendingMerge && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <div className="font-medium">Tables to merge:</div>
                  <Badge variant="outline">
                    {pendingMerge.draggedTable.number}
                  </Badge>
                  <span>+</span>
                  <Badge variant="outline">
                    {pendingMerge.targetTable.number}
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">
                  Combined seats:{" "}
                  {pendingMerge.draggedTable.seats +
                    pendingMerge.targetTable.seats}
                </div>
                <div className="text-sm text-gray-600">
                  New table name: {pendingMerge.targetTable.number}+
                  {pendingMerge.draggedTable.number}
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={cancelMerge}>
                Cancel
              </Button>
              <Button
                onClick={confirmMerge}
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
              >
                Merge Tables
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Unmerge Confirmation Dialog */}
      <Dialog open={showUnmergeDialog} onOpenChange={setShowUnmergeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Table Unmerge</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>
              Are you sure you want to unmerge this table back into its original
              tables?
            </p>
            {tableToUnmerge && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex items-center gap-2">
                  <div className="font-medium">Current merged table:</div>
                  <Badge variant="outline">{tableToUnmerge.number}</Badge>
                </div>
                <div className="text-sm text-gray-600">
                  Will be split into:{" "}
                  {tableToUnmerge.originalTables?.join(", ")}
                </div>
                <div className="text-sm text-gray-600">
                  Total seats: {tableToUnmerge.seats} (will be distributed
                  evenly)
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={cancelUnmerge}>
                Cancel
              </Button>
              <Button
                onClick={confirmUnmerge}
                className="bg-red-500 hover:bg-red-600 text-white"
              >
                Unmerge Table
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
