import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { FileText, Search, Eye, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface CashRegisterLogEntry {
  id: string;
  date: string;
  documentNo: string;
  amount: number;
  paymentMethod: string;
  cashier: string;
}

const mockLogEntries: CashRegisterLogEntry[] = [
  {
    id: "1",
    date: "2024-01-15",
    documentNo: "DOC-001",
    amount: 25.5,
    paymentMethod: "Cash",
    cashier: "Ahmed Al-Saud",
  },
  {
    id: "2",
    date: "2024-01-15",
    documentNo: "DOC-002",
    amount: 42.75,
    paymentMethod: "Card",
    cashier: "Sarah Wilson",
  },
  {
    id: "3",
    date: "2024-01-15",
    documentNo: "DOC-003",
    amount: 18.25,
    paymentMethod: "Cash",
    cashier: "Ahmed Al-Saud",
  },
  {
    id: "4",
    date: "2024-01-14",
    documentNo: "DOC-004",
    amount: 67.9,
    paymentMethod: "Digital Wallet",
    cashier: "Mike Johnson",
  },
  {
    id: "5",
    date: "2024-01-14",
    documentNo: "DOC-005",
    amount: 33.2,
    paymentMethod: "Card",
    cashier: "Sarah Wilson",
  },
];

export default function CashRegisterLog() {
  const [logEntries] = useState<CashRegisterLogEntry[]>(mockLogEntries);
  const [searchTerm, setSearchTerm] = useState("");

  const filteredEntries = logEntries.filter(
    (entry) =>
      entry.documentNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.cashier.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.paymentMethod.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const getPaymentMethodBadge = (method: string) => {
    switch (method.toLowerCase()) {
      case "cash":
        return <Badge className="bg-green-100 text-green-800">Cash</Badge>;
      case "card":
        return <Badge className="bg-blue-100 text-blue-800">Card</Badge>;
      case "digital wallet":
        return (
          <Badge className="bg-purple-100 text-purple-800">
            Digital Wallet
          </Badge>
        );
      default:
        return <Badge className="bg-gray-100 text-gray-800">{method}</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <FileText className="h-8 w-8 text-blucrumbs-blue-500" />
            Log - Cash Register 001
          </h1>
          <p className="text-gray-600 mt-1">
            View transaction log for Cash Register 001
          </p>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="relative max-w-sm">
              <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <Input type="date" placeholder="From Date" className="w-40" />
              <span className="text-gray-500">to</span>
              <Input type="date" placeholder="To Date" className="w-40" />
              <Button variant="outline">Filter</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Log Entries Table */}
      <Card>
        <CardHeader>
          <CardTitle>Transaction Log</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredEntries.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Document No.</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Payment Method</TableHead>
                  <TableHead>Cashier</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEntries.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell>
                      {new Date(entry.date).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="font-medium">
                      {entry.documentNo}
                    </TableCell>
                    <TableCell className="font-medium">
                      ${entry.amount.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      {getPaymentMethodBadge(entry.paymentMethod)}
                    </TableCell>
                    <TableCell>{entry.cashier}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <FileText className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Transactions Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No transactions match your search criteria."
                  : "No transactions have been recorded yet."}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {filteredEntries.length}
              </div>
              <div className="text-sm text-gray-500">Total Transactions</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                $
                {filteredEntries
                  .reduce((sum, entry) => sum + entry.amount, 0)
                  .toFixed(2)}
              </div>
              <div className="text-sm text-gray-500">Total Amount</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                $
                {filteredEntries
                  .filter((entry) => entry.paymentMethod === "Cash")
                  .reduce((sum, entry) => sum + entry.amount, 0)
                  .toFixed(2)}
              </div>
              <div className="text-sm text-gray-500">Cash Transactions</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                $
                {filteredEntries
                  .filter((entry) => entry.paymentMethod !== "Cash")
                  .reduce((sum, entry) => sum + entry.amount, 0)
                  .toFixed(2)}
              </div>
              <div className="text-sm text-gray-500">Non-Cash Transactions</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
