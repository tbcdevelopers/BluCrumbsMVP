import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Building2,
  Edit,
  Save,
  X,
  Upload,
  FileText,
  Calendar,
  Plus,
} from "lucide-react";

interface Document {
  id: string;
  description: string;
  date: string;
  file: File | null;
}

interface Company {
  id: string;
  code: string;
  name: string;
  arabicName: string;
  commercialName: string;
  commercialArabicName: string;
  crNumber: string;
  taxRegistration: boolean;
  taxRegistrationNumber: string;
  phone: string;
  email: string;
  website: string;
  facebook: string;
  instagram: string;
  region: string;
  city: string;
  area: string;
  building: string;
  unitNumber: string;
  additionalNumber: string;
  postalCode: string;
  logo: File | null;
  documents: Document[];
  status: "active" | "inactive";
}

const companyData: Company = {
  id: "1",
  code: "BLU001",
  name: "Blubites Restaurant Chain",
  arabicName: "مطاعم بلوبايتس",
  commercialName: "Blubites",
  commercialArabicName: "بلوبايتس",
  crNumber: "1234567890",
  taxRegistration: true,
  taxRegistrationNumber: "300123456789012",
  phone: "+966501234567",
  email: "info@blubites.com",
  website: "www.blubites.com",
  facebook: "blubites.official",
  instagram: "blubites_restaurants",
  region: "Riyadh Region",
  city: "Riyadh",
  area: "King Fahd District",
  building: "Tower A",
  unitNumber: "101",
  additionalNumber: "1234",
  postalCode: "12345",
  logo: null,
  documents: [
    {
      id: "1",
      description: "Commercial Registration",
      date: "2024-01-15",
      file: null,
    },
    {
      id: "2",
      description: "Tax Certificate",
      date: "2024-01-10",
      file: null,
    },
  ],
  status: "active",
};

export default function Company() {
  const [company, setCompany] = useState<Company>(companyData);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Company>(companyData);
  const [newDocument, setNewDocument] = useState<Partial<Document>>({});

  const handleInputChange = (field: keyof Company, value: any) => {
    setEditData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    setCompany(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData(company);
    setIsEditing(false);
  };

  const handleAddDocument = () => {
    if (newDocument.description && newDocument.date) {
      const doc: Document = {
        id: Date.now().toString(),
        description: newDocument.description,
        date: newDocument.date,
        file: newDocument.file || null,
      };
      setEditData((prev) => ({
        ...prev,
        documents: [...prev.documents, doc],
      }));
      setNewDocument({});
    }
  };

  const handleRemoveDocument = (docId: string) => {
    setEditData((prev) => ({
      ...prev,
      documents: prev.documents.filter((doc) => doc.id !== docId),
    }));
  };

  const handleFileUpload = (file: File, type: "logo" | "document") => {
    if (type === "logo") {
      setEditData((prev) => ({ ...prev, logo: file }));
    } else {
      setNewDocument((prev) => ({ ...prev, file }));
    }
  };

  const currentData = isEditing ? editData : company;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Building2 className="h-8 w-8 text-blucrumbs-blue-500" />
            Company Profile
          </h1>
          <p className="text-gray-600 mt-1">
            View and manage your company information
          </p>
        </div>
        <div className="flex gap-2">
          {isEditing ? (
            <>
              <Button variant="outline" onClick={handleCancel}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={handleSave}
              >
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </>
          ) : (
            <Button
              className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
              onClick={() => setIsEditing(true)}
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit Profile
            </Button>
          )}
        </div>
      </div>

      {/* Company Status Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 bg-blucrumbs-blue-100 rounded-lg flex items-center justify-center">
                <Building2 className="h-8 w-8 text-blucrumbs-blue-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {currentData.name}
                </h2>
                <p className="text-gray-600">{currentData.commercialName}</p>
                <p className="text-sm text-gray-500">
                  Code: {currentData.code}
                </p>
              </div>
            </div>
            <div className="text-right">
              <Badge
                className={
                  currentData.status === "active"
                    ? "bg-green-100 text-green-800"
                    : "bg-red-100 text-red-800"
                }
              >
                {currentData.status === "active" ? "Active" : "Inactive"}
              </Badge>
              {currentData.taxRegistration && (
                <div className="mt-2">
                  <Badge className="bg-blue-100 text-blue-800">
                    VAT Registered
                  </Badge>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyName">Company Name *</Label>
              <Input
                id="companyName"
                value={currentData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Enter company name"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="arabicName">Company Arabic Name</Label>
              <Input
                id="arabicName"
                value={currentData.arabicName}
                onChange={(e) =>
                  handleInputChange("arabicName", e.target.value)
                }
                placeholder="Enter Arabic name"
                dir="rtl"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="commercialName">Commercial Name</Label>
              <Input
                id="commercialName"
                value={currentData.commercialName}
                onChange={(e) =>
                  handleInputChange("commercialName", e.target.value)
                }
                placeholder="Enter commercial name"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="commercialArabicName">
                Commercial Arabic Name
              </Label>
              <Input
                id="commercialArabicName"
                value={currentData.commercialArabicName}
                onChange={(e) =>
                  handleInputChange("commercialArabicName", e.target.value)
                }
                placeholder="Enter commercial Arabic name"
                dir="rtl"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="crNumber">CR Number *</Label>
              <Input
                id="crNumber"
                value={currentData.crNumber}
                onChange={(e) => handleInputChange("crNumber", e.target.value)}
                placeholder="Enter CR number"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="taxRegistration"
                checked={currentData.taxRegistration}
                onCheckedChange={(checked) =>
                  handleInputChange("taxRegistration", checked)
                }
                disabled={!isEditing}
              />
              <Label htmlFor="taxRegistration">Tax Registration</Label>
            </div>
          </div>
          {currentData.taxRegistration && (
            <div>
              <Label htmlFor="taxNumber">Tax Registration Number *</Label>
              <Input
                id="taxNumber"
                value={currentData.taxRegistrationNumber}
                onChange={(e) =>
                  handleInputChange("taxRegistrationNumber", e.target.value)
                }
                placeholder="Enter tax registration number"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Contact Information */}
      <Card>
        <CardHeader>
          <CardTitle>Contact Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={currentData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+966501234567"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={currentData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="info@company.com"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="website">Website</Label>
              <Input
                id="website"
                value={currentData.website}
                onChange={(e) => handleInputChange("website", e.target.value)}
                placeholder="www.company.com"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="facebook">Facebook</Label>
              <Input
                id="facebook"
                value={currentData.facebook}
                onChange={(e) => handleInputChange("facebook", e.target.value)}
                placeholder="company.page"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="instagram">Instagram</Label>
              <Input
                id="instagram"
                value={currentData.instagram}
                onChange={(e) => handleInputChange("instagram", e.target.value)}
                placeholder="@company"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Address Information */}
      <Card>
        <CardHeader>
          <CardTitle>Address Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="region">Region *</Label>
              <Input
                id="region"
                value={currentData.region}
                onChange={(e) => handleInputChange("region", e.target.value)}
                placeholder="Enter region"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="city">City *</Label>
              <Input
                id="city"
                value={currentData.city}
                onChange={(e) => handleInputChange("city", e.target.value)}
                placeholder="Enter city"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="area">Area</Label>
              <Input
                id="area"
                value={currentData.area}
                onChange={(e) => handleInputChange("area", e.target.value)}
                placeholder="Enter area"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="building">Building</Label>
              <Input
                id="building"
                value={currentData.building}
                onChange={(e) => handleInputChange("building", e.target.value)}
                placeholder="Enter building"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="unitNumber">Unit Number</Label>
              <Input
                id="unitNumber"
                value={currentData.unitNumber}
                onChange={(e) =>
                  handleInputChange("unitNumber", e.target.value)
                }
                placeholder="Enter unit number"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="additionalNumber">Additional Number</Label>
              <Input
                id="additionalNumber"
                value={currentData.additionalNumber}
                onChange={(e) =>
                  handleInputChange("additionalNumber", e.target.value)
                }
                placeholder="Enter additional number"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
            <div>
              <Label htmlFor="postalCode">Postal Code</Label>
              <Input
                id="postalCode"
                value={currentData.postalCode}
                onChange={(e) =>
                  handleInputChange("postalCode", e.target.value)
                }
                placeholder="Enter postal code"
                readOnly={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Company Logo */}
      <Card>
        <CardHeader>
          <CardTitle>Company Logo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <Upload className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <div className="space-y-2">
              <p className="text-sm text-gray-600">
                {currentData.logo
                  ? "Company logo uploaded"
                  : "No company logo uploaded"}
              </p>
              {isEditing && (
                <>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file, "logo");
                    }}
                    className="hidden"
                    id="logo-upload"
                  />
                  <label
                    htmlFor="logo-upload"
                    className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
                  >
                    {currentData.logo ? "Change Logo" : "Upload Logo"}
                  </label>
                </>
              )}
            </div>
            {currentData.logo && (
              <div className="mt-4">
                <p className="text-sm text-green-600">
                  ✓ {currentData.logo.name}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Documents */}
      <Card>
        <CardHeader>
          <CardTitle>Documents</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isEditing && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
              <div>
                <Label htmlFor="docDescription">Document Description</Label>
                <Input
                  id="docDescription"
                  value={newDocument.description || ""}
                  onChange={(e) =>
                    setNewDocument((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                  placeholder="Enter description"
                />
              </div>
              <div>
                <Label htmlFor="docDate">Document Date</Label>
                <Input
                  id="docDate"
                  type="date"
                  value={newDocument.date || ""}
                  onChange={(e) =>
                    setNewDocument((prev) => ({
                      ...prev,
                      date: e.target.value,
                    }))
                  }
                />
              </div>
              <div>
                <Label htmlFor="docFile">Document File</Label>
                <div className="flex gap-2">
                  <input
                    type="file"
                    accept=".pdf,.docx"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file, "document");
                    }}
                    className="hidden"
                    id="doc-upload"
                  />
                  <label
                    htmlFor="doc-upload"
                    className="flex-1 inline-flex items-center justify-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Choose File
                  </label>
                  <Button
                    type="button"
                    onClick={handleAddDocument}
                    disabled={!newDocument.description || !newDocument.date}
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add
                  </Button>
                </div>
              </div>
            </div>
          )}

          {currentData.documents && currentData.documents.length > 0 ? (
            <div className="space-y-2">
              <Label>Company Documents</Label>
              {currentData.documents.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="h-4 w-4 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium">{doc.description}</p>
                      <p className="text-xs text-gray-500 flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {doc.date}
                      </p>
                    </div>
                  </div>
                  {isEditing && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveDocument(doc.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <FileText className="h-8 w-8 mx-auto mb-2 text-gray-300" />
              <p>No documents uploaded yet</p>
              {isEditing && (
                <p className="text-sm">Add documents using the form above</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
