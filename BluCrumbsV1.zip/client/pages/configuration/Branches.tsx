import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Building2,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Branch {
  id: string;
  description: string;
  arabicDescription: string;
  serving: string[];
  city: string;
  address: string;
  addressUrl: string;
  status: "active" | "inactive";
  salesAccountSegment?: string;
  inventoryAccountSegment?: string;
  branchManager?: string;
}

const mockBranches: Branch[] = [
  {
    id: "BR001",
    description: "Main Branch - Riyadh",
    arabicDescription: "الفرع الرئيسي - الرياض",
    serving: ["Dine In", "Take Away"],
    city: "Riyadh",
    address: "King Fahd Road, Al Olaya District",
    addressUrl: "https://maps.google.com/location1",
    status: "active",
    branchManager: "Ahmed Al-Saud",
  },
];

export default function Branches() {
  const [branches] = useState<Branch[]>(mockBranches);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<Branch>>({
    serving: [],
    status: "active",
  });

  const handleInputChange = (field: keyof Branch, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleServingChange = (value: string) => {
    const currentServing = formData.serving || [];
    if (currentServing.includes(value)) {
      setFormData((prev) => ({
        ...prev,
        serving: currentServing.filter((item) => item !== value),
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        serving: [...currentServing, value],
      }));
    }
  };

  const filteredBranches = branches.filter(
    (branch) =>
      branch.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      branch.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      branch.city.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Building2 className="h-8 w-8 text-blucrumbs-blue-500" />
            Branch Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage branch locations and configurations
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Branch
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Branch</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="branchId">Branch ID *</Label>
                  <Input
                    id="branchId"
                    value={formData.id || ""}
                    onChange={(e) => handleInputChange("id", e.target.value)}
                    placeholder="Enter branch ID"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter description"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">Arabic Description</Label>
                  <Input
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="Enter Arabic description"
                    dir="rtl"
                  />
                </div>
              </div>

              <div>
                <Label>Serving Options *</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {["Dine In", "Take Away", "Drive-Through", "Delivery"].map(
                    (option) => (
                      <label
                        key={option}
                        className="flex items-center space-x-2 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={formData.serving?.includes(option) || false}
                          onChange={() => handleServingChange(option)}
                          className="rounded border-gray-300"
                        />
                        <span className="text-sm">{option}</span>
                      </label>
                    ),
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Select
                    value={formData.city || ""}
                    onValueChange={(value) => handleInputChange("city", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select city" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Riyadh">Riyadh</SelectItem>
                      <SelectItem value="Jeddah">Jeddah</SelectItem>
                      <SelectItem value="Dammam">Dammam</SelectItem>
                      <SelectItem value="Mecca">Mecca</SelectItem>
                      <SelectItem value="Medina">Medina</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <div className="flex items-center space-x-4 mt-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="status"
                        value="active"
                        checked={formData.status === "active"}
                        onChange={(e) =>
                          handleInputChange("status", e.target.value)
                        }
                      />
                      <span className="text-sm">Active</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="status"
                        value="inactive"
                        checked={formData.status === "inactive"}
                        onChange={(e) =>
                          handleInputChange("status", e.target.value)
                        }
                      />
                      <span className="text-sm">Inactive</span>
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address *</Label>
                <Input
                  id="address"
                  value={formData.address || ""}
                  onChange={(e) => handleInputChange("address", e.target.value)}
                  placeholder="Enter full address"
                  required
                />
              </div>

              <div>
                <Label htmlFor="addressUrl">Address URL *</Label>
                <Input
                  id="addressUrl"
                  value={formData.addressUrl || ""}
                  onChange={(e) =>
                    handleInputChange("addressUrl", e.target.value)
                  }
                  placeholder="Enter Google Maps URL"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="salesAccountSegment">
                    Sales Account Segment
                  </Label>
                  <Select
                    value={formData.salesAccountSegment || ""}
                    onValueChange={(value) =>
                      handleInputChange("salesAccountSegment", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select segment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="segment1">Segment 1</SelectItem>
                      <SelectItem value="segment2">Segment 2</SelectItem>
                      <SelectItem value="segment3">Segment 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="inventoryAccountSegment">
                    Inventory Account Segment
                  </Label>
                  <Select
                    value={formData.inventoryAccountSegment || ""}
                    onValueChange={(value) =>
                      handleInputChange("inventoryAccountSegment", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select segment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inventory1">Inventory 1</SelectItem>
                      <SelectItem value="inventory2">Inventory 2</SelectItem>
                      <SelectItem value="inventory3">Inventory 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Branch
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search branches..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Branches Table */}
      <Card>
        <CardHeader>
          <CardTitle>Branches</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredBranches.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Arabic Description</TableHead>
                  <TableHead>Branch Manager</TableHead>

                  <TableHead>Serving</TableHead>
                  <TableHead>City</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBranches.map((branch) => (
                  <TableRow key={branch.id}>
                    <TableCell className="font-medium">{branch.id}</TableCell>
                    <TableCell>{branch.description}</TableCell>
                    <TableCell dir="rtl">{branch.arabicDescription}</TableCell>
                    <TableCell>{branch.branchManager || "N/A"}</TableCell>

                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {branch.serving.map((service) => (
                          <Badge
                            key={service}
                            variant="secondary"
                            className="text-xs"
                          >
                            {service}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>{branch.city}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          branch.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {branch.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Building2 className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Branches Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No branches match your search criteria."
                  : "Get started by adding your first branch."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Branch
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
