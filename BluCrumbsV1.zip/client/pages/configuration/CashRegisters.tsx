import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Monitor, Plus, Search, Edit, Eye, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface CashRegister {
  id: string;
  branch: string;
  description: string;
  arabicDescription: string;
  account: string;
  floatAmount: number;
  spanTerminals: string[];
  status: "active" | "inactive";
}

const mockCashRegisters: CashRegister[] = [
  {
    id: "CR001",
    branch: "Main Branch - Riyadh",
    description: "Main Counter Register",
    arabicDescription: "سجل الكاونتر الرئيسي",
    account: "Cash Account 001",
    floatAmount: 500.0,
    spanTerminals: ["Terminal 1", "Terminal 2"],
    status: "active",
  },
  {
    id: "CR002",
    branch: "Main Branch - Riyadh",
    description: "Secondary Register",
    arabicDescription: "السجل الثانوي",
    account: "Cash Account 002",
    floatAmount: 300.0,
    spanTerminals: ["Terminal 3"],
    status: "active",
  },
];

export default function CashRegisters() {
  const [cashRegisters] = useState<CashRegister[]>(mockCashRegisters);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<
    Partial<CashRegister & { password: string; confirmPassword: string }>
  >({
    spanTerminals: [],
    status: "active",
    floatAmount: 0,
  });

  const handleInputChange = (
    field: keyof (CashRegister & { password: string; confirmPassword: string }),
    value: any,
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSpanTerminalChange = (value: string) => {
    const currentTerminals = formData.spanTerminals || [];
    if (currentTerminals.includes(value)) {
      setFormData((prev) => ({
        ...prev,
        spanTerminals: currentTerminals.filter((item) => item !== value),
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        spanTerminals: [...currentTerminals, value],
      }));
    }
  };

  const filteredCashRegisters = cashRegisters.filter(
    (register) =>
      register.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      register.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      register.branch.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Monitor className="h-8 w-8 text-blucrumbs-blue-500" />
            Register Setup
          </h1>
          <p className="text-gray-600 mt-1">
            Manage cash registers and POS configurations
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Cash Register
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Cash Register</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="branch">Branch *</Label>
                  <Select
                    value={formData.branch || ""}
                    onValueChange={(value) =>
                      handleInputChange("branch", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="main-riyadh">
                        Main Branch - Riyadh
                      </SelectItem>
                      <SelectItem value="branch-jeddah">
                        Branch - Jeddah
                      </SelectItem>
                      <SelectItem value="branch-dammam">
                        Branch - Dammam
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="registerId">ID *</Label>
                  <Input
                    id="registerId"
                    value={formData.id || ""}
                    onChange={(e) => handleInputChange("id", e.target.value)}
                    placeholder="Enter register ID"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter description"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">
                    Arabic Description *
                  </Label>
                  <Input
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="Enter Arabic description"
                    dir="rtl"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="account">Account *</Label>
                  <Select
                    value={formData.account || ""}
                    onValueChange={(value) =>
                      handleInputChange("account", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select account" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash-001">Cash Account 001</SelectItem>
                      <SelectItem value="cash-002">Cash Account 002</SelectItem>
                      <SelectItem value="cash-003">Cash Account 003</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="floatAmount">Float Amount</Label>
                  <Input
                    id="floatAmount"
                    type="number"
                    step="0.01"
                    value={formData.floatAmount || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "floatAmount",
                        parseFloat(e.target.value),
                      )
                    }
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div>
                <Label>Span Terminals</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {["Terminal 1", "Terminal 2", "Terminal 3", "Terminal 4"].map(
                    (terminal) => (
                      <label
                        key={terminal}
                        className="flex items-center space-x-2 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={
                            formData.spanTerminals?.includes(terminal) || false
                          }
                          onChange={() => handleSpanTerminalChange(terminal)}
                          className="rounded border-gray-300"
                        />
                        <span className="text-sm">{terminal}</span>
                      </label>
                    ),
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password || ""}
                    onChange={(e) =>
                      handleInputChange("password", e.target.value)
                    }
                    placeholder="Enter password"
                  />
                </div>
                <div>
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={formData.confirmPassword || ""}
                    onChange={(e) =>
                      handleInputChange("confirmPassword", e.target.value)
                    }
                    placeholder="Confirm password"
                  />
                </div>
              </div>

              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-4 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Cash Register
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search cash registers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Cash Registers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Cash Registers Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredCashRegisters.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Branch ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Arabic Description</TableHead>
                  <TableHead>Float Amount</TableHead>
                  <TableHead>Span Terminals</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCashRegisters.map((register) => (
                  <TableRow key={register.id}>
                    <TableCell className="font-medium">
                      {register.branch}
                    </TableCell>
                    <TableCell>{register.description}</TableCell>
                    <TableCell dir="rtl">
                      {register.arabicDescription}
                    </TableCell>
                    <TableCell>${register.floatAmount.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {register.spanTerminals.map((terminal) => (
                          <Badge
                            key={terminal}
                            variant="secondary"
                            className="text-xs"
                          >
                            {terminal}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          register.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {register.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Monitor className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Cash Registers Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No cash registers match your search criteria."
                  : "Get started by adding your first cash register."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Cash Register
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
