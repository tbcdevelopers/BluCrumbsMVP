import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Terminal,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SpanTerminal {
  id: string;
  description: string;
  arabicDescription: string;
  deviceId: string;
  provider: string;
  account: string;
  status: "active" | "inactive";
}

const mockSpanTerminals: SpanTerminal[] = [
  {
    id: "TERM001",
    description: "Main Terminal 1",
    arabicDescription: "الطرفية الرئيسية 1",
    deviceId: "DEV-001-A",
    provider: "Visa/Mastercard",
    account: "Terminal Account 001",
    status: "active",
  },
  {
    id: "TERM002",
    description: "Secondary Terminal",
    arabicDescription: "الطرفية الثانوية",
    deviceId: "DEV-002-B",
    provider: "MADA",
    account: "Terminal Account 002",
    status: "active",
  },
  {
    id: "TERM003",
    description: "Backup Terminal",
    arabicDescription: "طرفية احتياطية",
    deviceId: "DEV-003-C",
    provider: "AmEx",
    account: "Terminal Account 003",
    status: "inactive",
  },
];

export default function SpanTerminals() {
  const [spanTerminals] = useState<SpanTerminal[]>(mockSpanTerminals);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<SpanTerminal>>({
    status: "active",
  });

  const handleInputChange = (field: keyof SpanTerminal, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const filteredSpanTerminals = spanTerminals.filter(
    (terminal) =>
      terminal.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      terminal.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      terminal.deviceId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      terminal.provider.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Terminal className="h-8 w-8 text-blucrumbs-blue-500" />
            Terminal Configuration
          </h1>
          <p className="text-gray-600 mt-1">
            Manage payment terminals and device configurations
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Span Terminal
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Span Terminal</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="terminalId">ID *</Label>
                  <Input
                    id="terminalId"
                    value={formData.id || ""}
                    onChange={(e) => handleInputChange("id", e.target.value)}
                    placeholder="Enter terminal ID"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter description"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">
                    Arabic Description *
                  </Label>
                  <Input
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="Enter Arabic description"
                    dir="rtl"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="deviceId">Device ID *</Label>
                  <Input
                    id="deviceId"
                    value={formData.deviceId || ""}
                    onChange={(e) =>
                      handleInputChange("deviceId", e.target.value)
                    }
                    placeholder="Enter device ID"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="provider">Provider</Label>
                  <Input
                    id="provider"
                    value={formData.provider || ""}
                    onChange={(e) =>
                      handleInputChange("provider", e.target.value)
                    }
                    placeholder="Enter provider name"
                  />
                </div>
                <div>
                  <Label htmlFor="account">Account *</Label>
                  <Select
                    value={formData.account || ""}
                    onValueChange={(value) =>
                      handleInputChange("account", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select account" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="terminal-001">
                        Terminal Account 001
                      </SelectItem>
                      <SelectItem value="terminal-002">
                        Terminal Account 002
                      </SelectItem>
                      <SelectItem value="terminal-003">
                        Terminal Account 003
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-4 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Terminal
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search terminals..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Span Terminals Table */}
      <Card>
        <CardHeader>
          <CardTitle>Span Terminals Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredSpanTerminals.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Arabic Description</TableHead>
                  <TableHead>Device ID</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSpanTerminals.map((terminal) => (
                  <TableRow key={terminal.id}>
                    <TableCell className="font-medium">{terminal.id}</TableCell>
                    <TableCell>{terminal.description}</TableCell>
                    <TableCell dir="rtl">
                      {terminal.arabicDescription}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {terminal.deviceId}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{terminal.provider}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          terminal.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {terminal.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Terminal className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Terminals Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No terminals match your search criteria."
                  : "Get started by adding your first span terminal."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Terminal
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
