import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  ChefHat,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface UnitOfMeasure {
  id: string;
  unit: string;
  status: "active" | "inactive";
}

interface Supplier {
  id: string;
  supplier: string;
  cost: number;
  lastPurchase: string;
  price: number;
}

interface KitchenItem {
  id: string;
  barcode: string;
  reference: string;
  itemType: "consumable" | "kitchen_item";
  company: string;
  description: string;
  arabicDescription: string;
  brand: string;
  shelfLife: number;
  shelfLifeUnit: "hours" | "days" | "months";
  hasExpiry: boolean;
  perUnitCalory: number;
  unit: string;
  purchaseTaxId: string;
  status: "active" | "inactive";
  unitOfMeasures: UnitOfMeasure[];
  suppliers: Supplier[];
  purchaseCost: number;
  purchaseCostWithVat: number;
  currentCost: number;
  quantity: number;
  category: string;
  space: string;
  image?: string;
}

const mockKitchenItems: KitchenItem[] = [
  {
    id: "KI001",
    barcode: "1234567890123",
    reference: "REF001",
    itemType: "kitchen_item",
    company: "Blubites",
    description: "Premium Olive Oil",
    arabicDescription: "زيت زيتون ممتاز",
    brand: "Al-Jouf",
    shelfLife: 24,
    shelfLifeUnit: "months",
    hasExpiry: true,
    perUnitCalory: 884,
    unit: "Liter",
    purchaseTaxId: "TAX001",
    status: "active",
    unitOfMeasures: [
      { id: "UM1", unit: "Liter", status: "active" },
      { id: "UM2", unit: "Milliliter", status: "active" },
    ],
    suppliers: [
      {
        id: "S1",
        supplier: "Al-Jouf Farms",
        cost: 25.5,
        lastPurchase: "2024-01-10",
        price: 25.5,
      },
    ],
    purchaseCost: 25.5,
    purchaseCostWithVat: 29.33,
    currentCost: 25.5,
    quantity: 50,
    category: "Oils & Fats",
    space: "Dry Storage",
  },
];

export default function KitchenItems() {
  const [kitchenItems] = useState<KitchenItem[]>(mockKitchenItems);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<KitchenItem>>({
    itemType: "kitchen_item",
    hasExpiry: false,
    shelfLifeUnit: "months",
    status: "active",
    unitOfMeasures: [],
    suppliers: [],
  });
  const [newUnit, setNewUnit] = useState("");
  const [newSupplier, setNewSupplier] = useState<Partial<Supplier>>({});

  const handleInputChange = (field: keyof KitchenItem, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddUnit = () => {
    if (newUnit.trim()) {
      const unit: UnitOfMeasure = {
        id: `UM${Date.now()}`,
        unit: newUnit.trim(),
        status: "active",
      };
      setFormData((prev) => ({
        ...prev,
        unitOfMeasures: [...(prev.unitOfMeasures || []), unit],
      }));
      setNewUnit("");
    }
  };

  const predefinedUnits = [
    "kg",
    "g",
    "ltr",
    "ml",
    "pcs",
    "box",
    "dozen",
    "pack",
    "bottle",
    "can",
  ];

  const handleRemoveUnit = (unitId: string) => {
    setFormData((prev) => ({
      ...prev,
      unitOfMeasures:
        prev.unitOfMeasures?.filter((unit) => unit.id !== unitId) || [],
    }));
  };

  const handleAddSupplier = () => {
    if (newSupplier.supplier && newSupplier.cost) {
      const supplier: Supplier = {
        id: `S${Date.now()}`,
        supplier: newSupplier.supplier,
        cost: newSupplier.cost,
        lastPurchase: new Date().toISOString().split("T")[0],
        price: newSupplier.cost,
      };
      setFormData((prev) => ({
        ...prev,
        suppliers: [...(prev.suppliers || []), supplier],
      }));
      setNewSupplier({});
    }
  };

  const resetForm = () => {
    setFormData({
      itemType: "kitchen_item",
      hasExpiry: false,
      shelfLifeUnit: "months",
      status: "active",
      unitOfMeasures: [],
      suppliers: [],
    });
    setNewUnit("");
    setNewSupplier({});
  };

  const filteredItems = kitchenItems.filter(
    (item) =>
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.barcode.includes(searchTerm),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ChefHat className="h-8 w-8 text-blucrumbs-blue-500" />
            Kitchen Items
          </h1>
          <p className="text-gray-600 mt-1">
            Manage kitchen inventory items and supplies
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Kitchen Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Kitchen Item</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="barcode">Item Barcode *</Label>
                      <Input
                        id="barcode"
                        value={formData.barcode || ""}
                        onChange={(e) =>
                          handleInputChange("barcode", e.target.value)
                        }
                        placeholder="Enter barcode"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="reference">Reference *</Label>
                      <Input
                        id="reference"
                        value={formData.reference || ""}
                        onChange={(e) =>
                          handleInputChange("reference", e.target.value)
                        }
                        placeholder="Enter reference"
                        required
                      />
                    </div>
                    <div>
                      <Label>Item Type</Label>
                      <div className="flex items-center space-x-4 mt-2">
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="radio"
                            name="itemType"
                            value="consumable"
                            checked={formData.itemType === "consumable"}
                            onChange={(e) =>
                              handleInputChange("itemType", e.target.value)
                            }
                          />
                          <span className="text-sm">Consumable</span>
                        </label>
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="radio"
                            name="itemType"
                            value="kitchen_item"
                            checked={formData.itemType === "kitchen_item"}
                            onChange={(e) =>
                              handleInputChange("itemType", e.target.value)
                            }
                          />
                          <span className="text-sm">Kitchen Item</span>
                        </label>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="category">Category *</Label>
                      <Select
                        value={formData.category || ""}
                        onValueChange={(value) =>
                          handleInputChange("category", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Oils & Fats">
                            Oils & Fats
                          </SelectItem>
                          <SelectItem value="Proteins">Proteins</SelectItem>
                          <SelectItem value="Vegetables">Vegetables</SelectItem>
                          <SelectItem value="Grains & Rice">
                            Grains & Rice
                          </SelectItem>
                          <SelectItem value="Spices & Herbs">
                            Spices & Herbs
                          </SelectItem>
                          <SelectItem value="Dairy Products">
                            Dairy Products
                          </SelectItem>
                          <SelectItem value="Condiments">Condiments</SelectItem>
                          <SelectItem value="Beverages">Beverages</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="description">Description *</Label>
                      <Input
                        id="description"
                        value={formData.description || ""}
                        onChange={(e) =>
                          handleInputChange("description", e.target.value)
                        }
                        placeholder="Enter description"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="arabicDescription">
                        Arabic Description *
                      </Label>
                      <Input
                        id="arabicDescription"
                        value={formData.arabicDescription || ""}
                        onChange={(e) =>
                          handleInputChange("arabicDescription", e.target.value)
                        }
                        placeholder="Enter Arabic description"
                        dir="rtl"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="brand">Brand</Label>
                      <Select
                        value={formData.brand || ""}
                        onValueChange={(value) =>
                          handleInputChange("brand", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select brand" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="al-jouf">Al-Jouf</SelectItem>
                          <SelectItem value="almarai">Almarai</SelectItem>
                          <SelectItem value="nadec">Nadec</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {formData.itemType === "kitchen_item" && (
                      <div>
                        <Label htmlFor="shelfLife">Shelf Life</Label>
                        <div className="flex gap-2">
                          <Input
                            id="shelfLife"
                            type="number"
                            value={formData.shelfLife || ""}
                            onChange={(e) =>
                              handleInputChange(
                                "shelfLife",
                                parseInt(e.target.value),
                              )
                            }
                            placeholder="Enter shelf life"
                            className="flex-1"
                          />
                          <Select
                            value={formData.shelfLifeUnit || "months"}
                            onValueChange={(value) =>
                              handleInputChange("shelfLifeUnit", value)
                            }
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="hours">Hours</SelectItem>
                              <SelectItem value="days">Days</SelectItem>
                              <SelectItem value="months">Months</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}
                  </div>

                  {formData.itemType === "kitchen_item" && (
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="hasExpiry"
                        checked={formData.hasExpiry || false}
                        onChange={(e) =>
                          handleInputChange("hasExpiry", e.target.checked)
                        }
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="hasExpiry">Expire</Label>
                    </div>
                  )}

                  {formData.itemType === "kitchen_item" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="perUnitCalory">Per Unit Calory</Label>
                        <Input
                          id="perUnitCalory"
                          type="number"
                          value={formData.perUnitCalory || ""}
                          onChange={(e) =>
                            handleInputChange(
                              "perUnitCalory",
                              parseInt(e.target.value),
                            )
                          }
                          placeholder="Enter calories per unit"
                        />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Unit of Measures */}
              <Card>
                <CardHeader>
                  <CardTitle>Unit of Measures</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Select value={newUnit} onValueChange={setNewUnit}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select unit of measure" />
                      </SelectTrigger>
                      <SelectContent>
                        {predefinedUnits.map((unit) => (
                          <SelectItem key={unit} value={unit}>
                            {unit}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button onClick={handleAddUnit} disabled={!newUnit.trim()}>
                      Add Unit
                    </Button>
                  </div>

                  {formData.unitOfMeasures &&
                    formData.unitOfMeasures.length > 0 && (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Unit</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formData.unitOfMeasures.map((unit) => (
                            <TableRow key={unit.id}>
                              <TableCell>{unit.unit}</TableCell>
                              <TableCell>
                                <Badge
                                  className={
                                    unit.status === "active"
                                      ? "bg-green-100 text-green-800"
                                      : "bg-red-100 text-red-800"
                                  }
                                >
                                  {unit.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRemoveUnit(unit.id)}
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                </CardContent>
              </Card>

              {/* Suppliers */}
              <Card>
                <CardHeader>
                  <CardTitle>Suppliers</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <Input
                      placeholder="Supplier name"
                      value={newSupplier.supplier || ""}
                      onChange={(e) =>
                        setNewSupplier((prev) => ({
                          ...prev,
                          supplier: e.target.value,
                        }))
                      }
                    />
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Cost"
                      value={newSupplier.cost || ""}
                      onChange={(e) =>
                        setNewSupplier((prev) => ({
                          ...prev,
                          cost: parseFloat(e.target.value),
                        }))
                      }
                    />
                    <Button
                      onClick={handleAddSupplier}
                      disabled={!newSupplier.supplier || !newSupplier.cost}
                    >
                      Add Supplier
                    </Button>
                  </div>

                  {formData.suppliers && formData.suppliers.length > 0 && (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Supplier</TableHead>
                          <TableHead>Cost</TableHead>
                          <TableHead>Last Purchase</TableHead>
                          <TableHead>Price</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {formData.suppliers.map((supplier) => (
                          <TableRow key={supplier.id}>
                            <TableCell>{supplier.supplier}</TableCell>
                            <TableCell>${supplier.cost.toFixed(2)}</TableCell>
                            <TableCell>{supplier.lastPurchase}</TableCell>
                            <TableCell>${supplier.price.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>

              {/* Status */}
              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-4 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Kitchen Item
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search kitchen items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Kitchen Items Table */}
      <Card>
        <CardHeader>
          <CardTitle>Kitchen Items Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredItems.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Item Name</TableHead>
                  <TableHead>Item Arabic Name</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Space</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.id}</TableCell>
                    <TableCell>{item.description}</TableCell>
                    <TableCell dir="rtl">{item.arabicDescription}</TableCell>
                    <TableCell>${item.currentCost.toFixed(2)}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{item.category}</Badge>
                    </TableCell>
                    <TableCell>{item.space}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          item.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {item.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <ChefHat className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Kitchen Items Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No items match your search criteria."
                  : "Get started by adding your first kitchen item."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Kitchen Item
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
