import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Package, Plus, Search, Edit, Eye, MoreHorizontal } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PackageItem {
  id: string;
  description: string;
  arabicDescription: string;
  vendor: string;
  unit: string;
  quantityInUnit: number;
  unitQuantity: number;
  totalQuantity: number;
  taxId: string;
  purchaseCost: number;
  purchaseCostWithVAT: number;
  status: "active" | "inactive";
  vatPercent: number;
}

const mockPackages: PackageItem[] = [
  {
    id: "PKG001",
    description: "Paper Cups 8oz",
    arabicDescription: "أكواب ورقية 8 أونصة",
    vendor: "Packaging Co",
    unit: "box",
    quantityInUnit: 100,
    unitQuantity: 10,
    totalQuantity: 1000,
    taxId: "TAX001",
    purchaseCost: 25.0,
    purchaseCostWithVAT: 28.75,
    status: "active",
    vatPercent: 15,
  },
];

export default function PackageConsumable() {
  const [packages] = useState<PackageItem[]>(mockPackages);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<PackageItem>>({
    status: "active",
    vatPercent: 15,
  });

  const handleInputChange = (field: keyof PackageItem, value: any) => {
    const newData = { ...formData, [field]: value };

    // Auto-calculate total quantity and VAT
    if (field === "quantityInUnit" || field === "unitQuantity") {
      newData.totalQuantity =
        (newData.quantityInUnit || 0) * (newData.unitQuantity || 0);
    }
    if (field === "purchaseCost" || field === "vatPercent") {
      const cost = newData.purchaseCost || 0;
      const vat = newData.vatPercent || 0;
      newData.purchaseCostWithVAT = cost * (1 + vat / 100);
    }

    setFormData(newData);
  };

  const resetForm = () => {
    setFormData({ status: "active", vatPercent: 15 });
  };

  const filteredPackages = packages.filter(
    (pkg) =>
      pkg.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pkg.id.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Package className="h-8 w-8 text-blucrumbs-blue-500" />
            Package and Consumable
          </h1>
          <p className="text-gray-600 mt-1">
            Manage packaging and consumable items
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Package
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Package and Consumable</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="id">ID</Label>
                  <Input
                    id="id"
                    value={formData.id || ""}
                    onChange={(e) => handleInputChange("id", e.target.value)}
                    placeholder="Enter ID"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter description"
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">Arabic Description</Label>
                  <Input
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="Enter Arabic description"
                    dir="rtl"
                  />
                </div>
                <div>
                  <Label htmlFor="vendor">Vendor</Label>
                  <Select
                    value={formData.vendor || ""}
                    onValueChange={(value) =>
                      handleInputChange("vendor", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select vendor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="packaging-co">Packaging Co</SelectItem>
                      <SelectItem value="supplies-inc">Supplies Inc</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="unit">Unit</Label>
                  <Select
                    value={formData.unit || ""}
                    onValueChange={(value) => handleInputChange("unit", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="box">Box</SelectItem>
                      <SelectItem value="pack">Pack</SelectItem>
                      <SelectItem value="carton">Carton</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="quantityInUnit">Quantity in Unit</Label>
                  <Input
                    id="quantityInUnit"
                    type="number"
                    value={formData.quantityInUnit || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "quantityInUnit",
                        parseInt(e.target.value),
                      )
                    }
                    placeholder="Enter quantity"
                  />
                </div>
                <div>
                  <Label htmlFor="unitQuantity">Unit Quantity</Label>
                  <Input
                    id="unitQuantity"
                    type="number"
                    value={formData.unitQuantity || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "unitQuantity",
                        parseInt(e.target.value),
                      )
                    }
                    placeholder="Enter unit quantity"
                  />
                </div>
                <div>
                  <Label htmlFor="totalQuantity">Total Quantity</Label>
                  <Input
                    id="totalQuantity"
                    type="number"
                    value={formData.totalQuantity || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="taxId">Tax ID</Label>
                  <Select
                    value={formData.taxId || ""}
                    onValueChange={(value) => handleInputChange("taxId", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select tax ID" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TAX001">TAX001</SelectItem>
                      <SelectItem value="TAX002">TAX002</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="purchaseCost">Purchase Cost</Label>
                  <Input
                    id="purchaseCost"
                    type="number"
                    step="0.01"
                    value={formData.purchaseCost || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "purchaseCost",
                        parseFloat(e.target.value),
                      )
                    }
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <Label htmlFor="purchaseCostWithVAT">
                    Purchase Cost with VAT
                  </Label>
                  <Input
                    id="purchaseCostWithVAT"
                    type="number"
                    step="0.01"
                    value={formData.purchaseCostWithVAT?.toFixed(2) || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
              </div>

              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-4 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Package
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search packages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Package & Consumable Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Arabic Description</TableHead>
                <TableHead>Vendor</TableHead>
                <TableHead>Units</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Purchase Cost</TableHead>
                <TableHead>VAT %</TableHead>
                <TableHead>Purchase Cost with VAT</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPackages.map((pkg) => (
                <TableRow key={pkg.id}>
                  <TableCell className="font-medium">{pkg.id}</TableCell>
                  <TableCell>{pkg.description}</TableCell>
                  <TableCell dir="rtl">{pkg.arabicDescription}</TableCell>
                  <TableCell>{pkg.vendor}</TableCell>
                  <TableCell>{pkg.unit}</TableCell>
                  <TableCell>{pkg.totalQuantity}</TableCell>
                  <TableCell>${pkg.purchaseCost.toFixed(2)}</TableCell>
                  <TableCell>{pkg.vatPercent}%</TableCell>
                  <TableCell>${pkg.purchaseCostWithVAT.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge
                      className={
                        pkg.status === "active"
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }
                    >
                      {pkg.status === "active" ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
