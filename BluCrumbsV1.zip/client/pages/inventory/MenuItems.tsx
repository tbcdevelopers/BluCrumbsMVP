import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Receipt,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  ArrowUp,
  ArrowDown,
  Clock,
  FileText,
  Settings,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Ingredient {
  id: string;
  description: string;
  unit: string;
  quantity: number;
  calories: number;
  customizable: boolean;
  cost: number;
}

interface Consumable {
  id: string;
  description: string;
  unit: string;
  quantity: number;
  cost: number;
}

interface Station {
  id: string;
  station: string;
  sequence: number;
  prepTime?: number; // in minutes
  prepTimeUnit?: "minutes" | "hours";
  instructions?: string;
}

interface Supplier {
  id: string;
  supplier: string;
  cost: number;
  lastPurchase: string;
  price: number;
}

interface MenuItem {
  id: string;
  itemId: string;
  barcode: string;
  description: string;
  arabicDescription: string;
  company: string;
  preparationTime: string;
  readyItem: boolean;
  price: number;
  priceWithVat: number;
  ingredients: Ingredient[];
  dineInConsumables: Consumable[];
  deliveryConsumables: Consumable[];
  takeAwayConsumables: Consumable[];
  driveThroughConsumables: Consumable[];
  dineInAvailable: boolean;
  deliveryAvailable: boolean;
  takeAwayAvailable: boolean;
  driveThroughAvailable: boolean;
  stations: Station[];
  suppliers: Supplier[];
  calories: number;
  category: string;
  unitPrice: number;
  salePrice: number;
  vatPercent: number;
  status: "active" | "inactive";
}

const mockMenuItems: MenuItem[] = [
  {
    id: "MI001",
    itemId: "ITEM001",
    barcode: "1234567890123",
    description: "Grilled Chicken Burger",
    arabicDescription: "برجر الدجاج المشوي",
    company: "Blubites",
    preparationTime: "00:15",
    readyItem: false,
    price: 25.0,
    priceWithVat: 28.75,
    ingredients: [],
    dineInConsumables: [],
    deliveryConsumables: [],
    takeAwayConsumables: [],
    driveThroughConsumables: [],
    dineInAvailable: true,
    deliveryAvailable: true,
    takeAwayAvailable: true,
    driveThroughAvailable: true,
    stations: [
      {
        id: "ST1",
        station: "Grill Station",
        sequence: 1,
        prepTime: 8,
        prepTimeUnit: "minutes",
        instructions: "Grill chicken breast until internal temp reaches 165°F",
      },
      {
        id: "ST2",
        station: "Prep Station",
        sequence: 2,
        prepTime: 3,
        prepTimeUnit: "minutes",
        instructions: "Assemble burger with lettuce, tomato, and sauce",
      },
    ],
    suppliers: [],
    calories: 450,
    category: "Burgers",
    unitPrice: 20.0,
    salePrice: 25.0,
    vatPercent: 15,
    status: "active",
  },
];

const predefinedUnits = ["kg", "g", "ltr", "ml", "pcs", "box", "dozen", "pack"];

const availableStations = [
  "Grill Station",
  "Prep Station",
  "Salad Station",
  "Fry Station",
  "Baking Station",
  "Cold Station",
  "Hot Station",
  "Beverage Station",
];

export default function MenuItems() {
  const [menuItems] = useState<MenuItem[]>(mockMenuItems);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [isEditStationDialogOpen, setIsEditStationDialogOpen] = useState(false);
  const [isInstructionsDialogOpen, setIsInstructionsDialogOpen] =
    useState(false);
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<MenuItem>>({
    readyItem: false,
    ingredients: [],
    dineInConsumables: [],
    deliveryConsumables: [],
    takeAwayConsumables: [],
    driveThroughConsumables: [],
    dineInAvailable: true,
    deliveryAvailable: true,
    takeAwayAvailable: true,
    driveThroughAvailable: true,
    stations: [],
    suppliers: [],
    status: "active",
  });

  const [newIngredient, setNewIngredient] = useState<Partial<Ingredient>>({});
  const [newDineInItem, setNewDineInItem] = useState<Partial<Consumable>>({});
  const [newDeliveryItem, setNewDeliveryItem] = useState<Partial<Consumable>>(
    {},
  );
  const [newTakeAwayItem, setNewTakeAwayItem] = useState<Partial<Consumable>>(
    {},
  );
  const [newDriveThroughItem, setNewDriveThroughItem] = useState<
    Partial<Consumable>
  >({});
  const [newSupplier, setNewSupplier] = useState<Partial<Supplier>>({});
  const [newStation, setNewStation] = useState("");
  const [newPrepTime, setNewPrepTime] = useState<number | undefined>();
  const [newPrepTimeUnit, setNewPrepTimeUnit] = useState<"minutes" | "hours">(
    "minutes",
  );
  const [newInstructions, setNewInstructions] = useState("");

  const handleInputChange = (field: keyof MenuItem, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddIngredient = () => {
    if (
      newIngredient.description &&
      newIngredient.unit &&
      newIngredient.quantity
    ) {
      const ingredient: Ingredient = {
        id: `ING${Date.now()}`,
        description: newIngredient.description,
        unit: newIngredient.unit,
        quantity: newIngredient.quantity,
        calories: newIngredient.calories || 0,
        customizable: newIngredient.customizable || false,
        cost: newIngredient.cost || 0,
      };
      setFormData((prev) => ({
        ...prev,
        ingredients: [...(prev.ingredients || []), ingredient],
      }));
      setNewIngredient({});
    }
  };

  const handleAddConsumable = (
    type: "dineIn" | "delivery" | "takeAway" | "driveThrough",
  ) => {
    const getNewItem = () => {
      switch (type) {
        case "dineIn":
          return newDineInItem;
        case "delivery":
          return newDeliveryItem;
        case "takeAway":
          return newTakeAwayItem;
        case "driveThrough":
          return newDriveThroughItem;
      }
    };

    const setNewItem = (value: Partial<Consumable>) => {
      switch (type) {
        case "dineIn":
          setNewDineInItem(value);
          break;
        case "delivery":
          setNewDeliveryItem(value);
          break;
        case "takeAway":
          setNewTakeAwayItem(value);
          break;
        case "driveThrough":
          setNewDriveThroughItem(value);
          break;
      }
    };

    const newItem = getNewItem();
    if (newItem.description && newItem.unit && newItem.quantity) {
      const consumable: Consumable = {
        id: `CONS${Date.now()}`,
        description: newItem.description,
        unit: newItem.unit,
        quantity: newItem.quantity,
        cost: newItem.cost || 0,
      };

      const fieldMap = {
        dineIn: "dineInConsumables",
        delivery: "deliveryConsumables",
        takeAway: "takeAwayConsumables",
        driveThrough: "driveThroughConsumables",
      };

      setFormData((prev) => ({
        ...prev,
        [fieldMap[type]]: [
          ...((prev[fieldMap[type] as keyof MenuItem] as Consumable[]) || []),
          consumable,
        ],
      }));
      setNewItem({});
    }
  };

  const handleAddStation = () => {
    if (newStation.trim()) {
      const station: Station = {
        id: `ST${Date.now()}`,
        station: newStation.trim(),
        sequence: (formData.stations?.length || 0) + 1,
        prepTime: newPrepTime,
        prepTimeUnit: newPrepTimeUnit,
        instructions: newInstructions.trim() || undefined,
      };
      setFormData((prev) => ({
        ...prev,
        stations: [...(prev.stations || []), station],
      }));
      setNewStation("");
      setNewPrepTime(undefined);
      setNewPrepTimeUnit("minutes");
      setNewInstructions("");
    }
  };

  const handleEditStation = (station: Station) => {
    setSelectedStation(station);
    setNewPrepTime(station.prepTime);
    setNewPrepTimeUnit(station.prepTimeUnit || "minutes");
    setNewInstructions(station.instructions || "");
    setIsEditStationDialogOpen(true);
  };

  const handleUpdateStation = () => {
    if (selectedStation) {
      setFormData((prev) => ({
        ...prev,
        stations:
          prev.stations?.map((station) =>
            station.id === selectedStation.id
              ? {
                  ...station,
                  prepTime: newPrepTime,
                  prepTimeUnit: newPrepTimeUnit,
                  instructions: newInstructions.trim() || undefined,
                }
              : station,
          ) || [],
      }));
      setIsEditStationDialogOpen(false);
      setSelectedStation(null);
      setNewPrepTime(undefined);
      setNewPrepTimeUnit("minutes");
      setNewInstructions("");
    }
  };

  const handleViewInstructions = (station: Station) => {
    setSelectedStation(station);
    setIsInstructionsDialogOpen(true);
  };

  const handleDeleteStation = (stationId: string) => {
    setFormData((prev) => {
      const updatedStations =
        prev.stations?.filter((s) => s.id !== stationId) || [];
      // Reorder sequences
      updatedStations.forEach((station, index) => {
        station.sequence = index + 1;
      });
      return {
        ...prev,
        stations: updatedStations,
      };
    });
  };

  const handleAddSupplier = () => {
    if (newSupplier.supplier && newSupplier.cost) {
      const supplier: Supplier = {
        id: `SUP${Date.now()}`,
        supplier: newSupplier.supplier,
        cost: newSupplier.cost,
        lastPurchase: new Date().toISOString().split("T")[0],
        price: newSupplier.cost,
      };
      setFormData((prev) => ({
        ...prev,
        suppliers: [...(prev.suppliers || []), supplier],
      }));
      setNewSupplier({});
    }
  };

  const moveStation = (stationId: string, direction: "up" | "down") => {
    const stations = [...(formData.stations || [])];
    const index = stations.findIndex((s) => s.id === stationId);
    if (index === -1) return;

    if (direction === "up" && index > 0) {
      [stations[index], stations[index - 1]] = [
        stations[index - 1],
        stations[index],
      ];
    } else if (direction === "down" && index < stations.length - 1) {
      [stations[index], stations[index + 1]] = [
        stations[index + 1],
        stations[index],
      ];
    }

    stations.forEach((station, idx) => {
      station.sequence = idx + 1;
    });

    setFormData((prev) => ({ ...prev, stations }));
  };

  const getTotalCost = (items: Consumable[]) => {
    return items.reduce((total, item) => total + item.cost, 0);
  };

  const getTotalCalories = () => {
    return (formData.ingredients || []).reduce(
      (total, ingredient) => total + ingredient.calories * ingredient.quantity,
      0,
    );
  };

  const getTotalIngredientCost = () => {
    return (formData.ingredients || []).reduce(
      (total, ingredient) => total + ingredient.cost * ingredient.quantity,
      0,
    );
  };

  const formatPrepTime = (time?: number, unit?: "minutes" | "hours") => {
    if (!time) return "Not set";
    return `${time} ${unit === "hours" ? "h" : "min"}`;
  };

  const resetForm = () => {
    setFormData({
      readyItem: false,
      ingredients: [],
      dineInConsumables: [],
      deliveryConsumables: [],
      takeAwayConsumables: [],
      driveThroughConsumables: [],
      dineInAvailable: true,
      deliveryAvailable: true,
      takeAwayAvailable: true,
      driveThroughAvailable: true,
      stations: [],
      suppliers: [],
      status: "active",
    });
    setNewIngredient({});
    setNewDineInItem({});
    setNewDeliveryItem({});
    setNewTakeAwayItem({});
    setNewDriveThroughItem({});
    setNewSupplier({});
    setNewStation("");
    setNewPrepTime(undefined);
    setNewPrepTimeUnit("minutes");
    setNewInstructions("");
  };

  const ConsumableSection = ({
    title,
    items,
    newItem,
    setNewItem,
    onAdd,
    available,
    onToggle,
  }: {
    title: string;
    items: Consumable[];
    newItem: Partial<Consumable>;
    setNewItem: (item: Partial<Consumable>) => void;
    onAdd: () => void;
    available: boolean;
    onToggle: (available: boolean) => void;
  }) => (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{title}</CardTitle>
          <div className="flex items-center space-x-2">
            <Switch checked={available} onCheckedChange={onToggle} />
            <Label>Available</Label>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {available && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
              <Select
                value={newItem.description || ""}
                onValueChange={(value) =>
                  setNewItem({ ...newItem, description: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select consumable" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Paper Cups 8oz">Paper Cups 8oz</SelectItem>
                  <SelectItem value="Paper Bags Medium">
                    Paper Bags Medium
                  </SelectItem>
                  <SelectItem value="Plastic Straws">Plastic Straws</SelectItem>
                  <SelectItem value="Napkins">Napkins</SelectItem>
                  <SelectItem value="Food Containers">
                    Food Containers
                  </SelectItem>
                  <SelectItem value="Aluminum Foil">Aluminum Foil</SelectItem>
                  <SelectItem value="Plastic Lids">Plastic Lids</SelectItem>
                  <SelectItem value="Disposable Cutlery">
                    Disposable Cutlery
                  </SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={newItem.unit || ""}
                onValueChange={(value) =>
                  setNewItem({ ...newItem, unit: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Unit" />
                </SelectTrigger>
                <SelectContent>
                  {predefinedUnits.map((unit) => (
                    <SelectItem key={unit} value={unit}>
                      {unit}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="number"
                step="0.01"
                placeholder="Quantity"
                value={newItem.quantity || ""}
                onChange={(e) =>
                  setNewItem({
                    ...newItem,
                    quantity: parseFloat(e.target.value),
                  })
                }
              />
              <Input
                type="number"
                step="0.01"
                placeholder="Cost"
                value={newItem.cost || ""}
                onChange={(e) =>
                  setNewItem({ ...newItem, cost: parseFloat(e.target.value) })
                }
              />
            </div>
            <Button
              onClick={onAdd}
              disabled={
                !newItem.description || !newItem.unit || !newItem.quantity
              }
            >
              Add Item
            </Button>

            {items.length > 0 && (
              <div>
                <div className="flex justify-between items-center mb-2">
                  <Label>Items</Label>
                  <Badge variant="outline">
                    Total Cost: ${getTotalCost(items).toFixed(2)}
                  </Badge>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Cost</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.description}</TableCell>
                        <TableCell>{item.unit}</TableCell>
                        <TableCell>{item.quantity}</TableCell>
                        <TableCell>${item.cost.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );

  const handleViewDetails = (item: MenuItem) => {
    setSelectedItem(item);
    setIsDetailDialogOpen(true);
  };

  const filteredItems = menuItems.filter(
    (item) =>
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.itemId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.barcode.includes(searchTerm),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Receipt className="h-8 w-8 text-blucrumbs-blue-500" />
            Menu Items
          </h1>
          <p className="text-gray-600 mt-1">
            Manage menu items, ingredients, and preparation details
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Menu Item
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Menu Item</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="itemId">Item ID *</Label>
                      <Input
                        id="itemId"
                        value={formData.itemId || ""}
                        onChange={(e) =>
                          handleInputChange("itemId", e.target.value)
                        }
                        placeholder="Enter item ID"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="barcode">Barcode *</Label>
                      <Input
                        id="barcode"
                        value={formData.barcode || ""}
                        onChange={(e) =>
                          handleInputChange("barcode", e.target.value)
                        }
                        placeholder="Enter barcode"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Category *</Label>
                      <Select
                        value={formData.category || ""}
                        onValueChange={(value) =>
                          handleInputChange("category", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Burgers">Burgers</SelectItem>
                          <SelectItem value="Sandwiches">Sandwiches</SelectItem>
                          <SelectItem value="Salads">Salads</SelectItem>
                          <SelectItem value="Appetizers">Appetizers</SelectItem>
                          <SelectItem value="Main Courses">
                            Main Courses
                          </SelectItem>
                          <SelectItem value="Desserts">Desserts</SelectItem>
                          <SelectItem value="Beverages">Beverages</SelectItem>
                          <SelectItem value="Sides">Sides</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="description">Description *</Label>
                      <Input
                        id="description"
                        value={formData.description || ""}
                        onChange={(e) =>
                          handleInputChange("description", e.target.value)
                        }
                        placeholder="Enter description"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="arabicDescription">
                        Arabic Description
                      </Label>
                      <Input
                        id="arabicDescription"
                        value={formData.arabicDescription || ""}
                        onChange={(e) =>
                          handleInputChange("arabicDescription", e.target.value)
                        }
                        placeholder="Enter Arabic description"
                        dir="rtl"
                      />
                    </div>
                    <div>
                      <Label htmlFor="preparationTime">Preparation Time</Label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          min="0"
                          placeholder="Time"
                          value={formData.preparationTime?.split(":")[0] || ""}
                          onChange={(e) => {
                            const value = e.target.value;
                            const unit = formData.preparationTime?.includes("h")
                              ? "h"
                              : "m";
                            handleInputChange(
                              "preparationTime",
                              `${value}${unit}`,
                            );
                          }}
                          className="flex-1"
                        />
                        <Select
                          value={
                            formData.preparationTime?.includes("h")
                              ? "hours"
                              : "minutes"
                          }
                          onValueChange={(unit) => {
                            const timeValue =
                              formData.preparationTime?.replace(/[hm]/g, "") ||
                              "0";
                            const newUnit = unit === "hours" ? "h" : "m";
                            handleInputChange(
                              "preparationTime",
                              `${timeValue}${newUnit}`,
                            );
                          }}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue placeholder="Unit" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="minutes">Minutes</SelectItem>
                            <SelectItem value="hours">Hours</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="readyItem"
                        checked={formData.readyItem || false}
                        onCheckedChange={(checked) =>
                          handleInputChange("readyItem", checked)
                        }
                      />
                      <Label htmlFor="readyItem">Ready Item</Label>
                    </div>
                    <div>
                      <Label htmlFor="price">Price *</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={formData.price || ""}
                        onChange={(e) =>
                          handleInputChange("price", parseFloat(e.target.value))
                        }
                        placeholder="0.00"
                      />
                    </div>
                    <div>
                      <Label htmlFor="priceWithVat">
                        Price With VAT (Restricted)
                      </Label>
                      <Input
                        id="priceWithVat"
                        type="number"
                        step="0.01"
                        value={formData.priceWithVat || ""}
                        readOnly
                        className="bg-gray-50"
                        placeholder="Auto-calculated"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Conditional Sections based on Ready Item */}
              {!formData.readyItem ? (
                /* Ingredients Section for non-ready items */
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle>Ingredients</CardTitle>
                      <div className="space-x-4">
                        <Badge variant="outline">
                          Total Calories: {getTotalCalories()}
                        </Badge>
                        <Badge variant="outline">
                          Total Cost: ${getTotalIngredientCost().toFixed(2)}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
                      <Select
                        value={newIngredient.description || ""}
                        onValueChange={(value) =>
                          setNewIngredient({
                            ...newIngredient,
                            description: value,
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select kitchen item" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Premium Olive Oil">
                            Premium Olive Oil
                          </SelectItem>
                          <SelectItem value="Fresh Tomatoes">
                            Fresh Tomatoes
                          </SelectItem>
                          <SelectItem value="Chicken Breast">
                            Chicken Breast
                          </SelectItem>
                          <SelectItem value="Basmati Rice">
                            Basmati Rice
                          </SelectItem>
                          <SelectItem value="White Onions">
                            White Onions
                          </SelectItem>
                          <SelectItem value="Cooking Oil">
                            Cooking Oil
                          </SelectItem>
                          <SelectItem value="Ground Beef">
                            Ground Beef
                          </SelectItem>
                          <SelectItem value="Cheese Slices">
                            Cheese Slices
                          </SelectItem>
                          <SelectItem value="Lettuce">Lettuce</SelectItem>
                          <SelectItem value="Bell Peppers">
                            Bell Peppers
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <Select
                        value={newIngredient.unit || ""}
                        onValueChange={(value) =>
                          setNewIngredient({ ...newIngredient, unit: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Unit" />
                        </SelectTrigger>
                        <SelectContent>
                          {predefinedUnits.map((unit) => (
                            <SelectItem key={unit} value={unit}>
                              {unit}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Quantity"
                        value={newIngredient.quantity || ""}
                        onChange={(e) =>
                          setNewIngredient({
                            ...newIngredient,
                            quantity: parseFloat(e.target.value),
                          })
                        }
                      />
                      <Input
                        type="number"
                        placeholder="Calories"
                        value={newIngredient.calories || ""}
                        onChange={(e) =>
                          setNewIngredient({
                            ...newIngredient,
                            calories: parseInt(e.target.value),
                          })
                        }
                      />
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Cost"
                        value={newIngredient.cost || ""}
                        onChange={(e) =>
                          setNewIngredient({
                            ...newIngredient,
                            cost: parseFloat(e.target.value),
                          })
                        }
                      />
                      <div className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newIngredient.customizable || false}
                          onChange={(e) =>
                            setNewIngredient({
                              ...newIngredient,
                              customizable: e.target.checked,
                            })
                          }
                        />
                        <Label className="text-xs">Customizable</Label>
                      </div>
                    </div>
                    <Button
                      onClick={handleAddIngredient}
                      disabled={
                        !newIngredient.description ||
                        !newIngredient.unit ||
                        !newIngredient.quantity
                      }
                    >
                      Add Ingredient
                    </Button>

                    {formData.ingredients &&
                      formData.ingredients.length > 0 && (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>#</TableHead>
                              <TableHead>Description</TableHead>
                              <TableHead>Unit</TableHead>
                              <TableHead>Quantity</TableHead>
                              <TableHead>Calories</TableHead>
                              <TableHead>Customizable</TableHead>
                              <TableHead>Cost</TableHead>
                              <TableHead>Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {formData.ingredients.map((ingredient, index) => (
                              <TableRow key={ingredient.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell>{ingredient.description}</TableCell>
                                <TableCell>{ingredient.unit}</TableCell>
                                <TableCell>{ingredient.quantity}</TableCell>
                                <TableCell>{ingredient.calories}</TableCell>
                                <TableCell>
                                  {ingredient.customizable ? (
                                    <Badge className="bg-green-100 text-green-800">
                                      Yes
                                    </Badge>
                                  ) : (
                                    <Badge className="bg-gray-100 text-gray-800">
                                      No
                                    </Badge>
                                  )}
                                </TableCell>
                                <TableCell>
                                  ${ingredient.cost.toFixed(2)}
                                </TableCell>
                                <TableCell>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                  </CardContent>
                </Card>
              ) : (
                /* Suppliers Section for ready items */
                <Card>
                  <CardHeader>
                    <CardTitle>Suppliers</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      <Select
                        value={newSupplier.supplier || ""}
                        onValueChange={(value) =>
                          setNewSupplier({ ...newSupplier, supplier: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select supplier" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="supplier1">Supplier 1</SelectItem>
                          <SelectItem value="supplier2">Supplier 2</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Cost"
                        value={newSupplier.cost || ""}
                        onChange={(e) =>
                          setNewSupplier({
                            ...newSupplier,
                            cost: parseFloat(e.target.value),
                          })
                        }
                      />
                      <Button
                        onClick={handleAddSupplier}
                        disabled={!newSupplier.supplier || !newSupplier.cost}
                      >
                        Add Supplier
                      </Button>
                    </div>

                    {formData.suppliers && formData.suppliers.length > 0 && (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Supplier</TableHead>
                            <TableHead>Cost</TableHead>
                            <TableHead>Last Purchase</TableHead>
                            <TableHead>Price</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formData.suppliers.map((supplier) => (
                            <TableRow key={supplier.id}>
                              <TableCell>{supplier.supplier}</TableCell>
                              <TableCell>${supplier.cost.toFixed(2)}</TableCell>
                              <TableCell>{supplier.lastPurchase}</TableCell>
                              <TableCell>
                                ${supplier.price.toFixed(2)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Consumables Section */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Consumables</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <ConsumableSection
                    title="Dine In"
                    items={formData.dineInConsumables || []}
                    newItem={newDineInItem}
                    setNewItem={setNewDineInItem}
                    onAdd={() => handleAddConsumable("dineIn")}
                    available={formData.dineInAvailable || false}
                    onToggle={(available) =>
                      handleInputChange("dineInAvailable", available)
                    }
                  />
                  <ConsumableSection
                    title="Delivery"
                    items={formData.deliveryConsumables || []}
                    newItem={newDeliveryItem}
                    setNewItem={setNewDeliveryItem}
                    onAdd={() => handleAddConsumable("delivery")}
                    available={formData.deliveryAvailable || false}
                    onToggle={(available) =>
                      handleInputChange("deliveryAvailable", available)
                    }
                  />
                  <ConsumableSection
                    title="Take Away"
                    items={formData.takeAwayConsumables || []}
                    newItem={newTakeAwayItem}
                    setNewItem={setNewTakeAwayItem}
                    onAdd={() => handleAddConsumable("takeAway")}
                    available={formData.takeAwayAvailable || false}
                    onToggle={(available) =>
                      handleInputChange("takeAwayAvailable", available)
                    }
                  />
                  <ConsumableSection
                    title="Drive Through"
                    items={formData.driveThroughConsumables || []}
                    newItem={newDriveThroughItem}
                    setNewItem={setNewDriveThroughItem}
                    onAdd={() => handleAddConsumable("driveThrough")}
                    available={formData.driveThroughAvailable || false}
                    onToggle={(available) =>
                      handleInputChange("driveThroughAvailable", available)
                    }
                  />
                </div>
              </div>

              {/* Enhanced Preparation Stations */}
              <Card>
                <CardHeader>
                  <CardTitle>Preparation Stations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Select value={newStation} onValueChange={setNewStation}>
                        <SelectTrigger className="flex-1">
                          <SelectValue placeholder="Select station" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableStations.map((station) => (
                            <SelectItem key={station} value={station}>
                              {station}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button onClick={handleAddStation} disabled={!newStation}>
                        Add Station
                      </Button>
                    </div>

                    {/* Optional fields when station is selected */}
                    {newStation && (
                      <div className="bg-gray-50 p-4 rounded-lg space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="prepTime">
                              Prep Time (Optional)
                            </Label>
                            <div className="flex gap-2">
                              <Input
                                id="prepTime"
                                type="number"
                                min="0"
                                placeholder="Time"
                                value={newPrepTime || ""}
                                onChange={(e) =>
                                  setNewPrepTime(
                                    parseInt(e.target.value) || undefined,
                                  )
                                }
                                className="flex-1"
                              />
                              <Select
                                value={newPrepTimeUnit}
                                onValueChange={(value: "minutes" | "hours") =>
                                  setNewPrepTimeUnit(value)
                                }
                              >
                                <SelectTrigger className="w-28">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="minutes">
                                    Minutes
                                  </SelectItem>
                                  <SelectItem value="hours">Hours</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="instructions">
                            Instructions (Optional)
                          </Label>
                          <Textarea
                            id="instructions"
                            placeholder="Enter preparation instructions..."
                            value={newInstructions}
                            onChange={(e) => setNewInstructions(e.target.value)}
                            rows={3}
                            className="resize-none"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {formData.stations && formData.stations.length > 0 && (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>#</TableHead>
                          <TableHead>Station</TableHead>
                          <TableHead>Prep Time</TableHead>
                          <TableHead>Instructions</TableHead>
                          <TableHead>Sequence</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {formData.stations.map((station, index) => (
                          <TableRow key={station.id}>
                            <TableCell>{index + 1}</TableCell>
                            <TableCell>{station.station}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3 text-gray-400" />
                                <span className="text-sm">
                                  {formatPrepTime(
                                    station.prepTime,
                                    station.prepTimeUnit,
                                  )}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              {station.instructions ? (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() =>
                                    handleViewInstructions(station)
                                  }
                                  className="p-1 h-6"
                                >
                                  <FileText className="h-3 w-3 mr-1" />
                                  <span className="text-xs">View</span>
                                </Button>
                              ) : (
                                <span className="text-xs text-gray-400">
                                  None
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => moveStation(station.id, "up")}
                                  disabled={index === 0}
                                >
                                  <ArrowUp className="h-3 w-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() =>
                                    moveStation(station.id, "down")
                                  }
                                  disabled={
                                    index ===
                                    (formData.stations?.length || 0) - 1
                                  }
                                >
                                  <ArrowDown className="h-3 w-3" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-8 w-8 p-0"
                                  >
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem
                                    onClick={() => handleEditStation(station)}
                                  >
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit Prep Time & Instructions
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() =>
                                      handleDeleteStation(station.id)
                                    }
                                    className="text-red-600"
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete Station
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Menu Item
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search menu items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Menu Items Table */}
      <Card>
        <CardHeader>
          <CardTitle>Menu Items Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredItems.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Image</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Item Name</TableHead>
                  <TableHead>Item Name Arabic</TableHead>
                  <TableHead>Calories</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Sale Price</TableHead>
                  <TableHead>VAT%</TableHead>
                  <TableHead>Price with VAT</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredItems.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <div className="h-10 w-10 bg-gray-100 rounded"></div>
                    </TableCell>
                    <TableCell className="font-medium">{item.itemId}</TableCell>
                    <TableCell>{item.description}</TableCell>
                    <TableCell dir="rtl">{item.arabicDescription}</TableCell>
                    <TableCell>{item.calories}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{item.category}</Badge>
                    </TableCell>
                    <TableCell>${item.unitPrice.toFixed(2)}</TableCell>
                    <TableCell>${item.salePrice.toFixed(2)}</TableCell>
                    <TableCell>{item.vatPercent}%</TableCell>
                    <TableCell>${item.priceWithVat.toFixed(2)}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          item.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {item.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => handleViewDetails(item)}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Settings className="h-4 w-4 mr-2" />
                            Sequence Management
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Receipt className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Menu Items Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No items match your search criteria."
                  : "Get started by adding your first menu item."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Menu Item
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detailed View Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Menu Item Details - {selectedItem?.description}
            </DialogTitle>
          </DialogHeader>
          {selectedItem && (
            <div className="space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <Label>Item ID</Label>
                      <div className="font-medium">{selectedItem.itemId}</div>
                    </div>
                    <div>
                      <Label>Description</Label>
                      <div className="font-medium">
                        {selectedItem.description}
                      </div>
                    </div>
                    <div>
                      <Label>Arabic Description</Label>
                      <div className="font-medium" dir="rtl">
                        {selectedItem.arabicDescription}
                      </div>
                    </div>
                    <div>
                      <Label>Barcode</Label>
                      <div className="font-medium">{selectedItem.barcode}</div>
                    </div>
                    <div>
                      <Label>Category</Label>
                      <div className="font-medium">{selectedItem.category}</div>
                    </div>
                    <div>
                      <Label>Calories</Label>
                      <div className="font-medium">{selectedItem.calories}</div>
                    </div>
                    <div>
                      <Label>Unit Price</Label>
                      <div className="font-medium">
                        ${selectedItem.unitPrice?.toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <Label>Sale Price</Label>
                      <div className="font-medium">
                        ${selectedItem.salePrice?.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Preparation Stations Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Preparation Stations</CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedItem.stations && selectedItem.stations.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Sequence</TableHead>
                          <TableHead>Station</TableHead>
                          <TableHead>Prep Time</TableHead>
                          <TableHead>Instructions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedItem.stations.map((station) => (
                          <TableRow key={station.id}>
                            <TableCell>
                              <Badge variant="outline">
                                #{station.sequence}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium">
                              {station.station}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3 text-gray-400" />
                                <span className="text-sm">
                                  {formatPrepTime(
                                    station.prepTime,
                                    station.prepTimeUnit,
                                  )}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              {station.instructions ? (
                                <div className="max-w-xs">
                                  <p className="text-sm text-gray-600 truncate">
                                    {station.instructions}
                                  </p>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() =>
                                      handleViewInstructions(station)
                                    }
                                    className="p-1 h-6 mt-1"
                                  >
                                    <FileText className="h-3 w-3 mr-1" />
                                    <span className="text-xs">View Full</span>
                                  </Button>
                                </div>
                              ) : (
                                <span className="text-xs text-gray-400">
                                  No instructions
                                </span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-gray-500">
                      No preparation stations defined
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Station Dialog */}
      <Dialog
        open={isEditStationDialogOpen}
        onOpenChange={setIsEditStationDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Station Details</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Station: {selectedStation?.station}</Label>
            </div>
            <div>
              <Label htmlFor="editPrepTime">Prep Time (Optional)</Label>
              <div className="flex gap-2">
                <Input
                  id="editPrepTime"
                  type="number"
                  min="0"
                  placeholder="Time"
                  value={newPrepTime || ""}
                  onChange={(e) =>
                    setNewPrepTime(parseInt(e.target.value) || undefined)
                  }
                  className="flex-1"
                />
                <Select
                  value={newPrepTimeUnit}
                  onValueChange={(value: "minutes" | "hours") =>
                    setNewPrepTimeUnit(value)
                  }
                >
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minutes">Minutes</SelectItem>
                    <SelectItem value="hours">Hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="editInstructions">Instructions (Optional)</Label>
              <Textarea
                id="editInstructions"
                placeholder="Enter preparation instructions..."
                value={newInstructions}
                onChange={(e) => setNewInstructions(e.target.value)}
                rows={4}
                className="resize-none"
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setIsEditStationDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleUpdateStation}>Update Station</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Instructions View Dialog */}
      <Dialog
        open={isInstructionsDialogOpen}
        onOpenChange={setIsInstructionsDialogOpen}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Station Instructions</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Station</Label>
              <div className="font-medium">{selectedStation?.station}</div>
            </div>
            <div>
              <Label>Prep Time</Label>
              <div className="font-medium">
                {formatPrepTime(
                  selectedStation?.prepTime,
                  selectedStation?.prepTimeUnit,
                )}
              </div>
            </div>
            <div>
              <Label>Instructions</Label>
              <div className="mt-2 p-3 bg-gray-50 rounded-md">
                <p className="text-sm whitespace-pre-wrap">
                  {selectedStation?.instructions || "No instructions provided"}
                </p>
              </div>
            </div>
            <div className="flex justify-end">
              <Button
                variant="outline"
                onClick={() => setIsInstructionsDialogOpen(false)}
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
