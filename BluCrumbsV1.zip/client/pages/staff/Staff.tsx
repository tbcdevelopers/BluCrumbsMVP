import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Plus } from "lucide-react";

export default function Staff() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Users className="h-8 w-8 text-blucrumbs-blue-500" />
            Staff Management
          </h1>
          <p className="text-gray-600 mt-1">Manage your restaurant staff</p>
        </div>
        <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
          <Plus className="h-4 w-4 mr-2" />
          Add Staff Member
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Staff Members</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Staff Management System
            </h3>
            <p className="text-gray-500 mb-6">Coming soon...</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
