import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Plus, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function StaffSchedules() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Calendar className="h-8 w-8 text-blucrumbs-blue-500" />
            Staff Schedules
          </h1>
          <p className="text-gray-600 mt-1">
            View and manage staff work schedules
          </p>
        </div>
      </div>

      <Card className="border-blucrumbs-blue-200 bg-blucrumbs-blue-50">
        <CardContent className="pt-6">
          <div className="text-center">
            <Calendar className="h-12 w-12 mx-auto text-blucrumbs-blue-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Schedule Management Moved
            </h3>
            <p className="text-gray-600 mb-4">
              Schedule management has been moved to the dedicated Management
              section for better organization.
            </p>
            <Link to="/management/schedules">
              <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                Go to Schedule Setup
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quick Schedule Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-gray-500">
              View a summary of today's staff schedules and upcoming shifts.
              <br />
              Feature coming soon...
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
