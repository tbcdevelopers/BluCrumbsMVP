import { useState } from "react";
import { useReservations } from "@/contexts/ReservationsContext";
import type { Reservation } from "@shared/reservations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  Clock,
  Users,
  MapPin,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const timeSlots = [
  "17:00",
  "17:30",
  "18:00",
  "18:30",
  "19:00",
  "19:30",
  "20:00",
  "20:30",
  "21:00",
  "21:30",
  "22:00",
  "22:30",
];

const generateCalendarDays = (date: Date) => {
  const startOfWeek = new Date(date);
  startOfWeek.setDate(date.getDate() - date.getDay());

  const days = [];
  for (let i = 0; i < 7; i++) {
    const day = new Date(startOfWeek);
    day.setDate(startOfWeek.getDate() + i);
    days.push(day);
  }
  return days;
};

export default function Reservations() {
  const { reservations, addReservation } = useReservations();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedWeek, setSelectedWeek] = useState(new Date());
  const [viewMode, setViewMode] = useState<"calendar" | "list">("calendar");
  const [formData, setFormData] = useState<Partial<Reservation>>({
    status: "pending",
    peopleCount: 2,
  });

  const handleInputChange = (field: keyof Reservation, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setFormData({
      status: "pending",
      peopleCount: 2,
    });
  };

  const filteredReservations = reservations.filter(
    (reservation) =>
      reservation.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.mobileNumber.includes(searchTerm) ||
      reservation.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reservation.description.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getReservationsForDateTime = (date: Date, time: string) => {
    const dateStr = date.toISOString().split("T")[0];
    return reservations.filter(
      (res) =>
        res.date === dateStr && time >= res.timeStart && time < res.timeEnd,
    );
  };

  const navigateWeek = (direction: "prev" | "next") => {
    const newDate = new Date(selectedWeek);
    newDate.setDate(selectedWeek.getDate() + (direction === "next" ? 7 : -7));
    setSelectedWeek(newDate);
  };

  const calendarDays = generateCalendarDays(selectedWeek);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Calendar className="h-8 w-8 text-blucrumbs-blue-500" />
            Reservations
          </h1>
          <p className="text-gray-600 mt-1">
            Manage table reservations and bookings
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <Button
              size="sm"
              variant={viewMode === "calendar" ? "default" : "ghost"}
              onClick={() => setViewMode("calendar")}
            >
              Calendar
            </Button>
            <Button
              size="sm"
              variant={viewMode === "list" ? "default" : "ghost"}
              onClick={() => setViewMode("list")}
            >
              List
            </Button>
          </div>
          <Dialog
            open={isAddDialogOpen}
            onOpenChange={(open) => {
              setIsAddDialogOpen(open);
              if (!open) resetForm();
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                <Plus className="h-4 w-4 mr-2" />
                Add Reservation
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Reservation</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reservationId">ID</Label>
                    <Input
                      id="reservationId"
                      value={`RES${String(reservations.length + 1).padStart(3, "0")}`}
                      disabled
                      className="bg-gray-50"
                    />
                  </div>
                  <div></div>
                  <div>
                    <Label htmlFor="customer">Customer Name *</Label>
                    <Input
                      id="customer"
                      value={formData.customer || ""}
                      onChange={(e) =>
                        handleInputChange("customer", e.target.value)
                      }
                      placeholder="Enter customer name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="mobileNumber">Mobile Number *</Label>
                    <Input
                      id="mobileNumber"
                      value={formData.mobileNumber || ""}
                      onChange={(e) =>
                        handleInputChange("mobileNumber", e.target.value)
                      }
                      placeholder="+966XXXXXXXXX"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="date">Date *</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.date || ""}
                      onChange={(e) =>
                        handleInputChange("date", e.target.value)
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="peopleCount">People Count *</Label>
                    <Input
                      id="peopleCount"
                      type="number"
                      min="1"
                      max="20"
                      value={formData.peopleCount || ""}
                      onChange={(e) =>
                        handleInputChange(
                          "peopleCount",
                          parseInt(e.target.value),
                        )
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="timeStart">Start Time *</Label>
                    <Select
                      value={formData.timeStart || ""}
                      onValueChange={(value) =>
                        handleInputChange("timeStart", value)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select start time" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="timeEnd">End Time *</Label>
                    <Select
                      value={formData.timeEnd || ""}
                      onValueChange={(value) =>
                        handleInputChange("timeEnd", value)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select end time" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((time) => (
                          <SelectItem key={time} value={time}>
                            {time}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="tableNumber">Table Number</Label>
                    <Select
                      value={formData.tableNumber || ""}
                      onValueChange={(value) =>
                        handleInputChange("tableNumber", value)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select table (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from(
                          { length: 20 },
                          (_, i) => `T${String(i + 1).padStart(2, "0")}`,
                        ).map((table) => (
                          <SelectItem key={table} value={table}>
                            {table}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Reservation Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter reservation details, special requests, etc."
                    rows={3}
                    required
                  />
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setIsAddDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                    onClick={() => {
                      console.log("Save Reservation clicked", formData);

                      if (!formData.customer) {
                        alert("Please enter customer name");
                        return;
                      }
                      if (!formData.mobileNumber) {
                        alert("Please enter mobile number");
                        return;
                      }
                      if (!formData.date) {
                        alert("Please select date");
                        return;
                      }
                      if (!formData.timeStart) {
                        alert("Please select start time");
                        return;
                      }
                      if (!formData.timeEnd) {
                        alert("Please select end time");
                        return;
                      }
                      if (!formData.description) {
                        alert("Please enter description");
                        return;
                      }

                      const newReservation = {
                        id: `RES${String(reservations.length + 1).padStart(3, "0")}`,
                        customer: formData.customer,
                        mobileNumber: formData.mobileNumber,
                        date: formData.date,
                        timeStart: formData.timeStart,
                        timeEnd: formData.timeEnd,
                        peopleCount: formData.peopleCount || 2,
                        tableNumber: formData.tableNumber,
                        description: formData.description,
                        status:
                          (formData.status as
                            | "confirmed"
                            | "pending"
                            | "cancelled"
                            | "completed") || "pending",
                        createdDate: new Date().toISOString().split("T")[0],
                      };

                      console.log("Adding reservation:", newReservation);
                      addReservation(newReservation);
                      setIsAddDialogOpen(false);
                      resetForm();
                      alert("Reservation saved successfully!");
                    }}
                  >
                    Save Reservation
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blucrumbs-blue-600">
                {reservations.length}
              </div>
              <div className="text-sm text-gray-500">Total Reservations</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {reservations.filter((r) => r.status === "confirmed").length}
              </div>
              <div className="text-sm text-gray-500">Confirmed</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {reservations.filter((r) => r.status === "pending").length}
              </div>
              <div className="text-sm text-gray-500">Pending</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {reservations.reduce((sum, r) => sum + r.peopleCount, 0)}
              </div>
              <div className="text-sm text-gray-500">Total Guests</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {viewMode === "calendar" ? (
        /* Calendar View */
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Weekly Calendar
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigateWeek("prev")}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm font-medium px-4">
                  {calendarDays[0].toLocaleDateString()} -{" "}
                  {calendarDays[6].toLocaleDateString()}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigateWeek("next")}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="min-w-[800px]">
                {/* Calendar Header */}
                <div className="grid grid-cols-8 gap-1 mb-2">
                  <div className="p-2 text-sm font-medium text-gray-500">
                    Time
                  </div>
                  {calendarDays.map((day, index) => (
                    <div key={index} className="p-2 text-center">
                      <div className="text-sm font-medium">
                        {day.toLocaleDateString("en-US", { weekday: "short" })}
                      </div>
                      <div className="text-xs text-gray-500">
                        {day.getDate()}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Time Rows */}
                {timeSlots.map((time) => (
                  <div
                    key={time}
                    className="grid grid-cols-8 gap-1 border-t border-gray-100"
                  >
                    <div className="p-2 text-xs text-gray-500 font-medium bg-gray-50">
                      {time}
                    </div>
                    {calendarDays.map((day, dayIndex) => {
                      const dayReservations = getReservationsForDateTime(
                        day,
                        time,
                      );
                      return (
                        <div
                          key={dayIndex}
                          className="p-1 min-h-[60px] border-l border-gray-100"
                        >
                          {dayReservations.map((reservation) => (
                            <div
                              key={reservation.id}
                              className={`text-xs p-2 rounded mb-1 cursor-pointer hover:opacity-80 ${
                                reservation.status === "confirmed"
                                  ? "bg-green-100 text-green-800 border border-green-200"
                                  : reservation.status === "pending"
                                    ? "bg-yellow-100 text-yellow-800 border border-yellow-200"
                                    : "bg-gray-100 text-gray-800 border border-gray-200"
                              }`}
                            >
                              <div className="font-medium">
                                {reservation.customer}
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {reservation.timeStart}-{reservation.timeEnd}
                              </div>
                              <div className="flex items-center gap-1">
                                <Users className="h-3 w-3" />
                                {reservation.peopleCount}
                              </div>
                              {reservation.tableNumber && (
                                <div className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3" />
                                  {reservation.tableNumber}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        /* List View */
        <>
          {/* Search */}
          <Card>
            <CardContent className="pt-6">
              <div className="relative max-w-sm">
                <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search reservations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Reservations Table */}
          <Card>
            <CardHeader>
              <CardTitle>Reservations Inquiry</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredReservations.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Mobile</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>People</TableHead>
                      <TableHead>Table</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReservations.map((reservation) => (
                      <TableRow key={reservation.id}>
                        <TableCell className="font-medium">
                          {reservation.id}
                        </TableCell>
                        <TableCell>{reservation.customer}</TableCell>
                        <TableCell>{reservation.mobileNumber}</TableCell>
                        <TableCell>
                          {new Date(reservation.date).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {reservation.timeStart}-{reservation.timeEnd}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {reservation.peopleCount}
                          </div>
                        </TableCell>
                        <TableCell>{reservation.tableNumber || "-"}</TableCell>
                        <TableCell className="max-w-32 truncate">
                          {reservation.description}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(reservation.status)}>
                            {reservation.status.charAt(0).toUpperCase() +
                              reservation.status.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                View
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Cancel
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-12">
                  <Calendar className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No Reservations Found
                  </h3>
                  <p className="text-gray-500 mb-6">
                    {searchTerm
                      ? "No reservations match your search criteria."
                      : "Get started by adding your first reservation."}
                  </p>
                  <Button
                    className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                    onClick={() => setIsAddDialogOpen(true)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Reservation
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
