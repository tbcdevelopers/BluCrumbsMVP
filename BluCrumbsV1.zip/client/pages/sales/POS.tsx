import { useState } from "react";
import { useParkedOrders } from "@/contexts/ParkedOrdersContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import InvoicePrint from "@/components/InvoicePrint";
import {
  Phone,
  User,
  ChevronDown,
  Search,
  X,
  ArrowLeft,
  ChevronUp,
  Plus,
  Minus,
  Car,
  Utensils,
  Receipt,
  Edit,
  FileText,
  Home,
  ShoppingBag,
  Truck,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  amount: number;
}

interface Customer {
  id: string;
  name: string;
  phone: string;
}

interface MenuItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  available: boolean;
}

interface Branch {
  id: string;
  name: string;
}

interface Site {
  id: string;
  name: string;
}

const categories = [
  { name: "Starters", color: "bg-blue-500 hover:bg-blue-600 text-white" },
  { name: "Main Meals", color: "bg-gray-500 hover:bg-gray-600 text-white" },
  { name: "Burger Meals", color: "bg-green-500 hover:bg-green-600 text-white" },
  { name: "Sandwiches", color: "bg-red-500 hover:bg-red-600 text-white" },
  { name: "Kids Meals", color: "bg-yellow-500 hover:bg-yellow-600 text-white" },
  { name: "Sauces", color: "bg-cyan-500 hover:bg-cyan-600 text-white" },
  { name: "School Fees", color: "bg-blue-500 hover:bg-blue-600 text-white" },
];

const mockBranches: Branch[] = [
  { id: "1", name: "Jazan Branch" },
  { id: "2", name: "Riyadh Branch" },
  { id: "3", name: "Jeddah Branch" },
];

const mockSites: Site[] = [
  { id: "1", name: "MNST - Main Site" },
  { id: "2", name: "SEC - Secondary Site" },
  { id: "3", name: "OUT - Outdoor Area" },
];

interface TableData {
  id: string;
  number: string;
  seats: number;
  status: "available" | "occupied" | "reserved";
}

const mockTables: TableData[] = [
  { id: "t1", number: "T01", seats: 4, status: "available" },
  { id: "t2", number: "T02", seats: 2, status: "available" },
  { id: "t3", number: "T03", seats: 6, status: "occupied" },
  { id: "t4", number: "T04", seats: 4, status: "available" },
  { id: "t5", number: "T05", seats: 2, status: "reserved" },
  { id: "t6", number: "T06", seats: 8, status: "available" },
  { id: "t7", number: "T07", seats: 4, status: "available" },
  { id: "t8", number: "T08", seats: 2, status: "available" },
  { id: "t9", number: "T09", seats: 6, status: "available" },
  { id: "t10", number: "T10", seats: 4, status: "available" },
];

const mockMenuItems: MenuItem[] = [
  {
    id: "1",
    name: "Chicken Spring Rolls",
    price: 12.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_971214e0-0e4e-4e5a-aedf-d5ae02c2f66b.png",
    category: "Starters",
    available: true,
  },
  {
    id: "2",
    name: "Cheesy Nuggets",
    price: 8.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_e7029fd6-47fa-4ebf-963a-b82426d98b93.png",
    category: "Starters",
    available: true,
  },
  {
    id: "3",
    name: "French Fries",
    price: 7.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_08a59a8c-a070-4aa4-b280-72d8323f3a1e.png",
    category: "Starters",
    available: false,
  },
  {
    id: "4",
    name: "Chicken Fries",
    price: 5.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_8cb2d684-b9ea-4eed-95c4-b96302da34c0.png",
    category: "Starters",
    available: true,
  },
  {
    id: "5",
    name: "Corn",
    price: 6.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_8278a7e6-9476-420c-9730-f1f47d3e087d.png",
    category: "Starters",
    available: true,
  },
  {
    id: "6",
    name: "Cheesy Fries",
    price: 7.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_07f9c058-286e-4dd8-a007-4cda2df27368.png",
    category: "Starters",
    available: false,
  },
  {
    id: "7",
    name: "Fattoush Salad",
    price: 5.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_29397ef9-38af-4a8c-8c83-d0120494a5b4.png",
    category: "Starters",
    available: false,
  },
  {
    id: "8",
    name: "Coleslaw",
    price: 5.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_4caa500f-7362-4463-82ea-eb35686deb8e.png",
    category: "Starters",
    available: false,
  },
  {
    id: "9",
    name: "Green Salad",
    price: 5.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_dde1854b-73c4-4506-a41d-7b6e0df42853.png",
    category: "Starters",
    available: false,
  },
  {
    id: "10",
    name: "Hummus",
    price: 8.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_64d7dded-8856-4416-b724-304fa1fdb671.png",
    category: "Starters",
    available: false,
  },
  {
    id: "11",
    name: "Tikka Batata",
    price: 9.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_0e9f7755-77a7-45e7-b0f0-edcf0ad36ee8.png",
    category: "Starters",
    available: false,
  },
  {
    id: "12",
    name: "Joy Box",
    price: 10.0,
    image:
      "https://restaurants.blubooks.me/Upload/ProductImages/_b89d80e0-05d7-427f-84ca-c520b5ab46bc.png",
    category: "Starters",
    available: false,
  },
];

export default function POS() {
  const {
    addParkedOrder,
    getParkedOrderByTable,
    parkedOrders,
    markOrderPaid,
    updateParkedOrder,
  } = useParkedOrders();
  const [customer, setCustomer] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("");
  const [selectedSite, setSelectedSite] = useState("");
  const [showMoreCustomer, setShowMoreCustomer] = useState(false);
  const [orderType, setOrderType] = useState<
    "dinein" | "takeaway" | "driveThru" | "delivery"
  >("dinein");
  const [showOrderTypeModal, setShowOrderTypeModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    "Starters",
  );
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchProduct, setSearchProduct] = useState("");
  const [showAdditionalDiscountModal, setShowAdditionalDiscountModal] =
    useState(false);
  const [discountType, setDiscountType] = useState<"AMOUNT" | "PERCENTAGE">(
    "AMOUNT",
  );
  const [discountAmount, setDiscountAmount] = useState("");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [activePaymentTab, setActivePaymentTab] = useState<
    "cash" | "mada" | "visa"
  >("cash");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [showItemDetails, setShowItemDetails] = useState(false);
  const [itemNote, setItemNote] = useState("");
  const [showCustomization, setShowCustomization] = useState(false);
  const [customizingCartItem, setCustomizingCartItem] =
    useState<CartItem | null>(null);
  const [showLineItemDiscountModal, setShowLineItemDiscountModal] =
    useState(false);
  const [lineItemDiscountType, setLineItemDiscountType] = useState<
    "AMOUNT" | "PERCENTAGE"
  >("AMOUNT");
  const [lineItemDiscountAmount, setLineItemDiscountAmount] = useState("");
  const [showParkOrderModal, setShowParkOrderModal] = useState(false);
  const [selectedTable, setSelectedTable] = useState<string>("");
  const [parkOrderNotes, setParkOrderNotes] = useState("");
  const [showParkedOrdersModal, setShowParkedOrdersModal] = useState(false);
  const [selectedParkedOrder, setSelectedParkedOrder] = useState<any>(null);
  const [showInvoicePrint, setShowInvoicePrint] = useState(false);
  const [invoiceData, setInvoiceData] = useState<any>(null);

  // Filter menu items
  const filteredItems = mockMenuItems.filter((item) => {
    const matchesCategory = selectedCategory
      ? item.category === selectedCategory
      : true;
    const matchesSearch = item.name
      .toLowerCase()
      .includes(searchProduct.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Add to cart function with auto-save
  const addToCart = (item: MenuItem) => {
    const existingItem = cart.find((cartItem) => cartItem.id === item.id);
    let updatedCart;
    if (existingItem) {
      updatedCart = cart.map((cartItem) =>
        cartItem.id === item.id
          ? {
              ...cartItem,
              quantity: cartItem.quantity + 1,
              amount: (cartItem.quantity + 1) * cartItem.price,
            }
          : cartItem,
      );
    } else {
      updatedCart = [...cart, { ...item, quantity: 1, amount: item.price }];
    }
    setCart(updatedCart);

    // Auto-save changes if editing a parked order
    if (selectedParkedOrder) {
      autoSaveParkedOrderChanges(updatedCart);
    }
  };

  // Update cart item quantity with auto-save
  const updateCartItemQuantity = (itemId: string, newQuantity: number) => {
    let updatedCart;
    if (newQuantity <= 0) {
      updatedCart = cart.filter((item) => item.id !== itemId);
    } else {
      updatedCart = cart.map((item) =>
        item.id === itemId
          ? {
              ...item,
              quantity: newQuantity,
              amount: newQuantity * item.price,
            }
          : item,
      );
    }
    setCart(updatedCart);

    // Auto-save changes if editing a parked order
    if (selectedParkedOrder) {
      autoSaveParkedOrderChanges(updatedCart);
    }
  };

  // Show cart item customization
  const showCartItemCustomization = (cartItem: CartItem) => {
    const menuItem = mockMenuItems.find((item) => item.id === cartItem.id);
    if (menuItem) {
      setSelectedItem(menuItem);
      setCustomizingCartItem(cartItem);
      setShowCustomization(true);
    }
  };

  // Go back to main menu
  const goBackToMenu = () => {
    setShowCustomization(false);
    setSelectedItem(null);
    setCustomizingCartItem(null);
    setItemNote("");
  };

  // Show item details
  const showItemDetailsModal = (item: MenuItem) => {
    setSelectedItem(item);
    setShowItemDetails(true);
  };

  // Keypad input handler for discount
  const handleKeypadInput = (value: string) => {
    if (value === "clear") {
      setDiscountAmount("");
    } else if (value === "backspace") {
      setDiscountAmount((prev) => prev.slice(0, -1));
    } else if (value === ".") {
      if (!discountAmount.includes(".")) {
        setDiscountAmount((prev) => prev + value);
      }
    } else {
      setDiscountAmount((prev) => prev + value);
    }
  };

  // Keypad input handler for payment
  const handlePaymentKeypadInput = (value: string) => {
    if (value === "clear") {
      setPaymentAmount("");
    } else if (value === "backspace") {
      setPaymentAmount((prev) => prev.slice(0, -1));
    } else if (value === ".") {
      if (!paymentAmount.includes(".")) {
        setPaymentAmount((prev) => prev + value);
      }
    } else if (["10", "20", "50", "100", "200", "500"].includes(value)) {
      setPaymentAmount(value);
    } else {
      setPaymentAmount((prev) => prev + value);
    }
  };

  // Apply discount
  const applyDiscount = () => {
    console.log(`Applied ${discountType} discount of ${discountAmount}`);
    setShowAdditionalDiscountModal(false);
    setDiscountAmount("");
  };

  // Keypad input handler for line item discount
  const handleLineItemDiscountKeypadInput = (value: string) => {
    if (value === "clear") {
      setLineItemDiscountAmount("");
    } else if (value === "backspace") {
      setLineItemDiscountAmount((prev) => prev.slice(0, -1));
    } else if (value === ".") {
      if (!lineItemDiscountAmount.includes(".")) {
        setLineItemDiscountAmount((prev) => prev + value);
      }
    } else {
      setLineItemDiscountAmount((prev) => prev + value);
    }
  };

  // Apply line item discount
  const applyLineItemDiscount = () => {
    console.log(
      `Applied ${lineItemDiscountType} line item discount of ${lineItemDiscountAmount}`,
    );
    // Here you would update the specific cart item with the discount
    setShowLineItemDiscountModal(false);
    setLineItemDiscountAmount("");
  };

  // Apply payment
  const applyPayment = () => {
    console.log(`Applied ${activePaymentTab} payment of ${paymentAmount}`);

    if (selectedParkedOrder) {
      handleCompleteParkedOrderPayment();
    } else {
      // Regular payment processing
      generateInvoice();
      setShowPaymentModal(false);
    }

    setPaymentAmount("");
  };

  // Create order function (automatically sends to kitchen)
  const handleCreateOrder = () => {
    if (cart.length === 0) {
      alert("Cannot park an empty order");
      return;
    }

    if (
      (orderType === "dinein" || orderType === "driveThru") &&
      !selectedTable
    ) {
      alert(
        `Please select a table for ${orderType === "dinein" ? "dine-in" : "drive-thru"} orders`,
      );
      return;
    }

    // Check if table already has a parked order
    if (
      (orderType === "dinein" || orderType === "driveThru") &&
      selectedTable
    ) {
      const existingOrder = getParkedOrderByTable(selectedTable);
      if (existingOrder) {
        alert(
          `Table ${selectedTable} already has a parked order. Please select a different table or manage the existing order.`,
        );
        return;
      }
    }

    const newOrder = {
      id: `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`,
      orderType,
      tableNumber:
        orderType === "dinein" || orderType === "driveThru"
          ? selectedTable
          : undefined,
      customerName: customerName || undefined,
      customerPhone: customer || undefined,
      items: cart.map((item) => ({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        amount: item.amount,
      })),
      netTotal,
      discount,
      additionalDiscount,
      taxableAmount,
      vatAmount,
      grandTotal,
      timestamp: new Date().toISOString(),
      status: "parked" as const,
      priority: "normal" as const,
      branch: selectedBranch,
      site: selectedSite,
      notes: parkOrderNotes,
      version: 1, // Initialize version
    };

    console.log("Creating order:", newOrder);
    addParkedOrder(newOrder);
    console.log("Order created and sent to kitchen successfully");

    // Clear the current order
    setCart([]);
    setCustomer("");
    setCustomerName("");
    setSelectedTable("");
    setParkOrderNotes("");
    setShowParkOrderModal(false);

    alert(
      `Order parked successfully${orderType === "dinein" || orderType === "driveThru" ? ` at table ${selectedTable}` : ""}`,
    );
  };

  // Load parked order into POS for payment
  const handleLoadParkedOrder = (parkedOrder: any) => {
    // Check if there's already an active order
    if (cart.length > 0 && !selectedParkedOrder) {
      if (
        !confirm(
          "Loading a parked order will replace the current order. Continue?",
        )
      ) {
        return;
      }
    }

    // Load parked order data into POS
    setCart(
      parkedOrder.items.map((item: any) => ({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        amount: item.amount,
      })),
    );

    setOrderType(parkedOrder.orderType);
    setCustomerName(parkedOrder.customerName || "");
    setCustomer(parkedOrder.customerPhone || "");
    setSelectedBranch(parkedOrder.branch || "");
    setSelectedSite(parkedOrder.site || "");

    if (
      (parkedOrder.orderType === "dinein" ||
        parkedOrder.orderType === "driveThru") &&
      parkedOrder.tableNumber
    ) {
      setSelectedTable(parkedOrder.tableNumber);
    }

    setSelectedParkedOrder(parkedOrder);
    setShowParkedOrdersModal(false);

    alert(
      `Order ${parkedOrder.id} loaded. You can now edit items or process payment.`,
    );
  };

  // Auto-save function for parked order changes
  const autoSaveParkedOrderChanges = (updatedCart: CartItem[]) => {
    if (!selectedParkedOrder) return;

    const updatedParkedOrder = {
      ...selectedParkedOrder,
      items: updatedCart.map((item) => {
        // Find the existing item in the parked order to preserve unique ID and completion status
        const existingParkedItem = selectedParkedOrder.items.find(
          (parkedItem) =>
            parkedItem.id === item.id || parkedItem.originalItemId === item.id,
        );

        return {
          id: existingParkedItem?.id || item.id, // Preserve unique ID if exists
          originalItemId: existingParkedItem?.originalItemId || item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          amount: item.amount,
          isCompleted: existingParkedItem?.isCompleted || false, // Preserve completion status
          completedAt: existingParkedItem?.completedAt,
          addedInVersion: existingParkedItem?.addedInVersion || 1,
          isNew: existingParkedItem?.isNew || false,
        };
      }),
      customerName: customerName || undefined,
      customerPhone: customer || undefined,
      orderType,
      tableNumber: (orderType === "dinein" || orderType === "driveThru") ? selectedTable : undefined,
      branch: selectedBranch,
      site: selectedSite,
      netTotal,
      discount,
      additionalDiscount,
      taxableAmount,
      vatAmount,
      grandTotal,
      lastEditedAt: new Date().toISOString(),
    };

    // Update the parked order with changes
    updateParkedOrder(selectedParkedOrder.id, updatedParkedOrder);

    console.log(`Auto-saved changes for order ${selectedParkedOrder.id}`);
  };

  // Save changes to parked order without payment (legacy function)
  const handleSaveParkedOrderChanges = () => {
    if (selectedParkedOrder && cart.length > 0) {
      // Update the parked order with any changes made in POS
      const updatedParkedOrder = {
        ...selectedParkedOrder,
        items: cart.map((item) => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          amount: item.amount,
        })),
        customerName: customerName || undefined,
        customerPhone: customer || undefined,
        orderType,
        tableNumber: (orderType === "dinein" || orderType === "driveThru") ? selectedTable : undefined,
        branch: selectedBranch,
        site: selectedSite,
        netTotal,
        discount,
        additionalDiscount,
        taxableAmount,
        vatAmount,
        grandTotal,
        lastEditedAt: new Date().toISOString(),
      };

      // Update the parked order with changes
      updateParkedOrder(selectedParkedOrder.id, updatedParkedOrder);

      alert(`Changes saved successfully for order ${selectedParkedOrder.id}`);
    }
  };

  // Complete payment for parked order
  const handleCompleteParkedOrderPayment = () => {
    if (selectedParkedOrder) {
      // First update the parked order with any changes made in POS
      const updatedParkedOrder = {
        ...selectedParkedOrder,
        items: cart.map((item) => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          amount: item.amount,
        })),
        customerName: customerName || undefined,
        customerPhone: customer || undefined,
        orderType,
        tableNumber: (orderType === "dinein" || orderType === "driveThru") ? selectedTable : undefined,
        branch: selectedBranch,
        site: selectedSite,
        netTotal,
        discount,
        additionalDiscount,
        taxableAmount,
        vatAmount,
        grandTotal,
        lastEditedAt: new Date().toISOString(),
      };

      // Update the parked order with changes
      updateParkedOrder(selectedParkedOrder.id, updatedParkedOrder);

      // Mark as paid
      markOrderPaid(selectedParkedOrder.id);

      // Generate invoice for parked order
      generateInvoiceForParkedOrder(updatedParkedOrder);

      // Clear the POS and reset state
      setCart([]);
      setCustomer("");
      setCustomerName("");
      setSelectedTable("");
      setSelectedBranch("");
      setSelectedSite("");
      setSelectedParkedOrder(null);

      alert(`Payment completed for order ${selectedParkedOrder.id}`);
      setShowPaymentModal(false);
    }
  };

  // Calculations
  const netTotal = cart.reduce((sum, item) => sum + item.amount, 0);
  const discount = 0;
  const additionalDiscount = 0;
  const taxableAmount = netTotal - discount - additionalDiscount;
  const vatAmount = taxableAmount * 0.15; // 15% VAT
  const grandTotal = taxableAmount + vatAmount;
  const paid = 0;
  const remaining = grandTotal - paid;

  // Handle update parked order - Load into main POS for editing
  const handleUpdateParkedOrder = (parkedOrder: any) => {
    // Check if there's already an active order that's different from the one being edited
    if (
      cart.length > 0 &&
      (!selectedParkedOrder || selectedParkedOrder.id !== parkedOrder.id)
    ) {
      if (
        !confirm(
          "Loading this parked order for editing will replace the current order. Continue?",
        )
      ) {
        return;
      }
    }

    // Load parked order data into POS for editing
    setCart(
      parkedOrder.items.map((item: any) => ({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        amount: item.amount,
      })),
    );

    setOrderType(parkedOrder.orderType);
    setCustomerName(parkedOrder.customerName || "");
    setCustomer(parkedOrder.customerPhone || "");
    setSelectedBranch(parkedOrder.branch || "");
    setSelectedSite(parkedOrder.site || "");

    if (
      (parkedOrder.orderType === "dinein" ||
        parkedOrder.orderType === "driveThru") &&
      parkedOrder.tableNumber
    ) {
      setSelectedTable(parkedOrder.tableNumber);
    }

    // Set this as the selected parked order for editing
    setSelectedParkedOrder(parkedOrder);
    setShowParkedOrdersModal(false);

    // Show a message indicating editing mode
    alert(
      `Parked order ${parkedOrder.id} loaded for editing. Make changes and use Payment to save.`,
    );
  };

  // Generate invoice for current order
  const generateInvoice = () => {
    if (cart.length === 0) {
      alert("Cannot generate invoice for empty cart");
      return;
    }

    const invoiceNumber = `INV-${String(Date.now()).slice(-5)}`;
    const currentDate = new Date();
    const invoiceDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, "0")}-${String(currentDate.getDate()).padStart(2, "0")} - ${String(currentDate.getHours()).padStart(2, "0")}:${String(currentDate.getMinutes()).padStart(2, "0")}`;

    const invoiceItems = cart.map((item) => ({
      id: item.id,
      name: item.name,
      code: `5265643000${item.id.padStart(3, "0")}`,
      unitPrice: item.price,
      quantity: item.quantity,
      subtotal: item.amount,
    }));

    const invoice = {
      invoiceNumber,
      invoiceDate,
      customerName: customerName || undefined,
      items: invoiceItems,
      totalTaxableAmount: taxableAmount,
      totalVAT: vatAmount,
      totalDiscount: discount,
      additionalDiscount,
      totalAmountDue: grandTotal,
      paymentReceived: parseFloat(paymentAmount) || 0,
      amountRemaining: grandTotal - (parseFloat(paymentAmount) || 0),
    };

    setInvoiceData(invoice);
    setShowInvoicePrint(true);
  };

  // Generate invoice for parked order
  const generateInvoiceForParkedOrder = (parkedOrder: any) => {
    const invoiceNumber = `INV-${String(Date.now()).slice(-5)}`;
    const currentDate = new Date();
    const invoiceDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, "0")}-${String(currentDate.getDate()).padStart(2, "0")} - ${String(currentDate.getHours()).padStart(2, "0")}:${String(currentDate.getMinutes()).padStart(2, "0")}`;

    const invoiceItems = parkedOrder.items.map((item: any) => ({
      id: item.id,
      name: item.name,
      code: `5265643000${item.id.padStart(3, "0")}`,
      unitPrice: item.price,
      quantity: item.quantity,
      subtotal: item.amount,
    }));

    const invoice = {
      invoiceNumber,
      invoiceDate,
      customerName: parkedOrder.customerName || undefined,
      items: invoiceItems,
      totalTaxableAmount: parkedOrder.taxableAmount || parkedOrder.netTotal,
      totalVAT: parkedOrder.vatAmount || 0,
      totalDiscount: parkedOrder.discount || 0,
      additionalDiscount: parkedOrder.additionalDiscount || 0,
      totalAmountDue: parkedOrder.grandTotal,
      paymentReceived: parseFloat(paymentAmount) || 0,
      amountRemaining:
        parkedOrder.grandTotal - (parseFloat(paymentAmount) || 0),
    };

    setInvoiceData(invoice);
    setShowInvoicePrint(true);
  };

  // Payment calculations
  const totalAmount = grandTotal;
  const paidAmount = 0; // This would be calculated from actual payments
  const remainingAmount = totalAmount - paidAmount;
  const changeAmount = Math.max(0, paidAmount - totalAmount);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="p-4">
        {/* Customer Information Section */}
        <Card className="mb-4">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
              {/* Customer Phone Input */}
              <div className="md:col-span-5">
                <div className="input-group-container flex">
                  <div className="flex items-center px-3 border border-r-0 rounded-l-md bg-gray-50">
                    <Phone className="h-4 w-4 text-gray-600" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Select Customer"
                    value={customer}
                    onChange={(e) => setCustomer(e.target.value)}
                    className="rounded-l-none border-l-0"
                    autoComplete="off"
                  />
                </div>
              </div>

              {/* Customer Name Input */}
              <div className="md:col-span-6">
                <div className="input-group-container flex">
                  <div className="flex items-center px-3 border border-r-0 rounded-l-md bg-gray-50">
                    <User className="h-4 w-4 text-gray-600 cursor-pointer" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Customer Name"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="rounded-l-none border-l-0"
                  />
                </div>
              </div>

              {/* Show More Button */}
              <div className="md:col-span-1 flex items-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowMoreCustomer(!showMoreCustomer)}
                  title={showMoreCustomer ? "Show Less" : "Show More"}
                >
                  {showMoreCustomer ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {/* Second Row - Branch and Site (Show More Content) */}
            {showMoreCustomer && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end mt-4">
                {/* Branch Selection */}
                <div className="md:col-span-6">
                  <Label>Branch</Label>
                  <Select
                    value={selectedBranch}
                    onValueChange={setSelectedBranch}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Branch" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockBranches.map((branch) => (
                        <SelectItem key={branch.id} value={branch.id}>
                          {branch.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Site Selection */}
                <div className="md:col-span-6">
                  <Label>Site</Label>
                  <Select value={selectedSite} onValueChange={setSelectedSite}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Site" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockSites.map((site) => (
                        <SelectItem key={site.id} value={site.id}>
                          {site.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Category Buttons - Mobile */}
        <div className="block md:hidden mb-4">
          <Card>
            <CardContent className="p-2">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <tbody>
                    <tr>
                      {categories.map((category, index) => (
                        <td
                          key={index}
                          className="p-1"
                          style={{ width: "auto" }}
                        >
                          <Button
                            className={`w-full whitespace-nowrap text-sm ${category.color}`}
                            onClick={() => setSelectedCategory(category.name)}
                          >
                            {category.name}
                          </Button>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left Side - Order Summary */}
          <div className="lg:col-span-3">
            <Card className="p-2">
              <CardContent className="p-2">
                {/* Order Type Button */}
                <div className="mb-4">
                  <Button
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white flex items-center justify-center gap-2"
                    onClick={() => setShowOrderTypeModal(true)}
                  >
                    {orderType === "dinein" && (
                      <>
                        <Home className="h-4 w-4" />
                        <span>Dine In</span>
                      </>
                    )}
                    {orderType === "takeaway" && (
                      <>
                        <ShoppingBag className="h-4 w-4" />
                        <span>Take Away</span>
                      </>
                    )}
                    {orderType === "driveThru" && (
                      <>
                        <Car className="h-4 w-4" />
                        <span>Drive Thru</span>
                      </>
                    )}
                    {orderType === "delivery" && (
                      <>
                        <Truck className="h-4 w-4" />
                        <span>Delivery</span>
                      </>
                    )}
                    <ChevronDown className="ml-auto h-4 w-4" />
                  </Button>
                </div>

                {/* Order Table */}
                <div className="mb-4">
                  <div className="border rounded-md">
                    <Table>
                      <TableHeader className="bg-gray-100">
                        <TableRow>
                          <TableHead className="text-left text-xs p-2">
                            Item
                          </TableHead>
                          <TableHead className="text-center text-xs p-2">
                            Qty
                          </TableHead>
                          <TableHead className="text-right text-xs p-2">
                            Amount
                          </TableHead>
                          <TableHead className="text-center text-xs p-2 w-8"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cart.length === 0 ? (
                          <TableRow>
                            <TableCell
                              colSpan={4}
                              className="text-center py-8 text-gray-500"
                            >
                              No item added yet.
                            </TableCell>
                          </TableRow>
                        ) : (
                          cart.map((item) => (
                            <TableRow
                              key={item.id}
                              className="cursor-pointer hover:bg-gray-50"
                              onClick={() => showCartItemCustomization(item)}
                            >
                              <TableCell className="p-2 text-sm">
                                {item.name}
                              </TableCell>
                              <TableCell className="text-center p-2 text-sm">
                                <div
                                  className="flex items-center justify-center gap-1"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-6 w-6 p-0"
                                    onClick={() =>
                                      updateCartItemQuantity(
                                        item.id,
                                        item.quantity - 1,
                                      )
                                    }
                                  >
                                    <Minus className="h-3 w-3" />
                                  </Button>
                                  <span className="w-8 text-center text-sm">
                                    {item.quantity}
                                  </span>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="h-6 w-6 p-0"
                                    onClick={() =>
                                      updateCartItemQuantity(
                                        item.id,
                                        item.quantity + 1,
                                      )
                                    }
                                  >
                                    <Plus className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                              <TableCell className="text-right p-2 text-sm">
                                {item.amount.toFixed(2)}
                              </TableCell>
                              <TableCell
                                className="text-center p-2"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-6 w-6 p-0"
                                  onClick={() =>
                                    updateCartItemQuantity(item.id, 0)
                                  }
                                >
                                  <X className="h-3 w-3" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>

                {/* Totals Section */}
                <div className="space-y-1 text-sm mx-2 mb-4">
                  <div className="flex justify-between">
                    <span>Net Total</span>
                    <span>{netTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Discount</span>
                    <span>{discount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>
                      <button
                        type="button"
                        className="text-blue-600 hover:underline bg-transparent border-0 p-0 cursor-pointer"
                        onClick={() => setShowAdditionalDiscountModal(true)}
                      >
                        Additional Discount
                      </button>
                    </span>
                    <span>{additionalDiscount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxable Amount</span>
                    <span>{taxableAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Vat Amount</span>
                    <span>{vatAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-300 pb-1 mb-1 font-medium">
                    <span>Grand Total</span>
                    <span>{grandTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Paid</span>
                    <span>{paid.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Remaining</span>
                    <span>{remaining.toFixed(2)}</span>
                  </div>
                </div>

                {/* Parked Order Indicator */}
                {selectedParkedOrder && (
                  <div className="mb-4 p-3 bg-purple-50 border border-purple-200 rounded-lg">
                    <div className="flex items-center gap-2 text-purple-700">
                      <Car className="h-4 w-4" />
                      <span className="text-sm font-medium">
                        Parked Order: {selectedParkedOrder.id}
                      </span>
                    </div>
                    {selectedParkedOrder.tableNumber && (
                      <div className="text-xs text-purple-600 mt-1">
                        {selectedParkedOrder.orderType === "driveThru" ? "Station" : "Table"}: {selectedParkedOrder.tableNumber}
                      </div>
                    )}
                  </div>
                )}

                {/* Payment Button */}
                <div className="mb-4">
                  <Button
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                    onClick={() => setShowPaymentModal(true)}
                    disabled={cart.length === 0}
                  >
                    {selectedParkedOrder ? "Complete Payment" : "Payment"}
                  </Button>
                </div>

                {/* Park Order Button - Only for Dine In and Drive Thru and not for already parked orders */}
                {(orderType === "dinein" || orderType === "driveThru") &&
                  cart.length > 0 &&
                  !selectedParkedOrder && (
                    <div className="mb-4">
                      <Button
                        className="w-full bg-orange-500 hover:bg-orange-600 text-white"
                        onClick={() => setShowParkOrderModal(true)}
                      >
                        <Car className="h-4 w-4 mr-2" />
                        Park Order
                      </Button>
                    </div>
                  )}

                {/* Show info when parked order is loaded */}
                {selectedParkedOrder && (
                  <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="text-sm text-green-700">
                      <strong>✅ Auto-Save Mode:</strong> Editing order{" "}
                      {selectedParkedOrder.id}. Changes are automatically saved
                      to kitchen.
                    </div>
                    <div className="text-xs text-green-600 mt-1">
                      Add items, modify quantities, or process payment when
                      ready.
                    </div>
                  </div>
                )}

                {/* Open Parked Orders Button */}
                <div className="mb-4">
                  <Button
                    className="w-full bg-purple-500 hover:bg-purple-600 text-white"
                    onClick={() => setShowParkedOrdersModal(true)}
                  >
                    <Utensils className="h-4 w-4 mr-2" />
                    View All Orders
                  </Button>
                </div>

                {/* Print Buttons */}
                <div className="flex gap-2">
                  <Button className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white text-sm">
                    Print Order
                  </Button>
                  <Button
                    className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-white text-sm"
                    onClick={() => {
                      if (cart.length > 0) {
                        generateInvoice();
                      } else {
                        alert("No items in cart to print invoice");
                      }
                    }}
                  >
                    <FileText className="h-3 w-3 mr-1" />
                    Print Invoice
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Center - Product Selection Area / Customization View */}
          <div className="lg:col-span-7">
            {showCustomization && selectedItem ? (
              /* Customization View */
              <Card className="shadow-none">
                <div className="card-header p-2 border-b">
                  <div className="grid grid-cols-12 gap-2">
                    <div className="col-span-2 px-2">
                      <img
                        src={selectedItem.image}
                        alt={selectedItem.name}
                        className="img-fluid img-thumbnail p-0 w-full h-auto"
                        onError={(e) => {
                          e.currentTarget.src = "/placeholder.svg";
                        }}
                      />
                    </div>
                    <div className="col-span-6 px-1">
                      <h4 className="text-lg font-medium m-0 truncate">
                        {selectedItem.name}
                      </h4>
                      <p className="text-sm text-gray-600 m-0">5265643000000</p>
                    </div>
                    <div className="col-span-4 px-2">
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>Unit Price</span>
                          <span>{selectedItem.price.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Quantity</span>
                          <span>{customizingCartItem?.quantity || 1}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Net Amount</span>
                          <span>
                            {(
                              selectedItem.price *
                              (customizingCartItem?.quantity || 1)
                            ).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Discount</span>
                          <span>0.00</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Taxable Amount</span>
                          <span>
                            {(
                              selectedItem.price *
                              (customizingCartItem?.quantity || 1)
                            ).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Vat</span>
                          <span>
                            {(
                              selectedItem.price *
                              (customizingCartItem?.quantity || 1) *
                              0.15
                            ).toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Subtotal</span>
                          <span>
                            {(
                              selectedItem.price *
                              (customizingCartItem?.quantity || 1) *
                              1.15
                            ).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <hr className="m-0" />

                <CardContent className="p-2">
                  {/* Add-ons Section */}
                  <div className="grid grid-cols-2 md:grid-cols-6 gap-2 mb-4">
                    {/* Mock add-on items */}
                    <div className="border rounded cursor-pointer hover:bg-gray-50">
                      <div className="pos-img flex justify-center items-center">
                        <img
                          src="https://restaurants.blubooks.me/Upload/ProductImages/_dce2e02f-2c7f-412b-abc4-dda2128e2029.png"
                          alt="Garlic Sauce"
                          className="border-0 img-fluid img-thumbnail p-0 w-full"
                          style={{ height: "120px" }}
                          onError={(e) => {
                            e.currentTarget.src = "/placeholder.svg";
                          }}
                        />
                      </div>
                      <div className="p-1">
                        <p className="text-sm m-0 truncate text-gray-600">
                          #0 Garlic Sauce
                        </p>
                        <p className="text-sm text-right m-0 text-gray-600">
                          4.00
                        </p>
                      </div>
                    </div>

                    <div className="border rounded cursor-pointer hover:bg-gray-50">
                      <div className="pos-img flex justify-center items-center">
                        <img
                          src="https://restaurants.blubooks.me/Upload/ProductImages/_5176fd40-bda7-40d6-bee7-356cba697920.png"
                          alt="Dynamite sauce"
                          className="border-0 img-fluid img-thumbnail p-0 w-full"
                          style={{ height: "120px" }}
                          onError={(e) => {
                            e.currentTarget.src = "/placeholder.svg";
                          }}
                        />
                      </div>
                      <div className="p-1">
                        <p className="text-sm m-0 truncate text-gray-600">
                          #0 Dynamite sauce
                        </p>
                        <p className="text-sm text-right m-0 text-gray-600">
                          4.00
                        </p>
                      </div>
                    </div>

                    <div className="border rounded cursor-pointer hover:bg-gray-50">
                      <div className="pos-img flex justify-center items-center">
                        <img
                          src="https://restaurants.blubooks.me/Upload/ProductImages/_360969f1-50a1-4e74-bf05-6ae5e2e58415.png"
                          alt="Barbecue sauce"
                          className="border-0 img-fluid img-thumbnail p-0 w-full"
                          style={{ height: "120px" }}
                          onError={(e) => {
                            e.currentTarget.src = "/placeholder.svg";
                          }}
                        />
                      </div>
                      <div className="p-1">
                        <p className="text-sm m-0 truncate text-gray-600">
                          #0 Barbecue sauce
                        </p>
                        <p className="text-sm text-right m-0 text-gray-600">
                          9.20
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Discount Section */}
                  <div className="mb-4">
                    <span
                      className="text-blue-600 font-medium cursor-pointer"
                      onClick={() => setShowLineItemDiscountModal(true)}
                    >
                      Discount{" "}
                      <span className="text-sm text-gray-600">0.00</span>
                    </span>
                  </div>

                  {/* Note Section */}
                  <div className="mb-4">
                    <Label htmlFor="notes">Note</Label>
                    <Textarea
                      id="notes"
                      rows={2}
                      placeholder="Item remark"
                      value={itemNote}
                      onChange={(e) => setItemNote(e.target.value)}
                      className="mt-1"
                    />
                  </div>

                  {/* Back Button */}
                  <div className="text-right">
                    <Button
                      type="button"
                      variant="secondary"
                      className="ml-1"
                      onClick={goBackToMenu}
                    >
                      <ArrowLeft className="h-4 w-4 mr-1" />
                      Back
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              /* Product Selection Area */
              <Card className="shadow-none">
                <div className="card-header p-2 border-b">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center">
                      <h4 className="text-lg font-medium m-0">
                        {selectedCategory || "Select Category"}
                      </h4>
                    </div>
                    <div className="px-2">
                      <div className="flex">
                        <div className="flex items-center px-3 border border-r-0 rounded-l-md bg-gray-50">
                          <Search className="h-4 w-4 text-gray-600 cursor-pointer" />
                        </div>
                        <Input
                          type="text"
                          placeholder="Enter item name or code..."
                          value={searchProduct}
                          onChange={(e) => setSearchProduct(e.target.value)}
                          className="rounded-l-none border-l-0"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-2">
                  {!selectedCategory ? (
                    <div className="text-center py-12">
                      <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 text-yellow-800">
                        Select Category.
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2 p-0">
                      {filteredItems.map((item) => (
                        <div
                          key={item.id}
                          className={`card border h-full cursor-pointer hover:shadow-md transition-shadow ${
                            !item.available ? "opacity-50" : ""
                          }`}
                          onClick={() => item.available && addToCart(item)}
                        >
                          <div className="card-content">
                            <div
                              className="pos-img flex justify-center items-center"
                              style={{ height: "163px" }}
                            >
                              <img
                                src={item.image}
                                alt={item.name}
                                className="border-0 img-fluid img-thumbnail"
                                style={{ height: "163px", width: "163px" }}
                                onError={(e) => {
                                  e.currentTarget.src = "/placeholder.svg";
                                }}
                              />
                            </div>
                            <div className="card-body p-2">
                              <p
                                className={`text-sm m-0 truncate font-medium ${
                                  item.available
                                    ? "text-gray-900"
                                    : "text-gray-400"
                                }`}
                              >
                                {item.name}
                              </p>
                              <p
                                className={`text-sm text-right m-0 ${
                                  item.available
                                    ? "text-gray-900"
                                    : "text-gray-400"
                                }`}
                              >
                                {item.price.toFixed(2)}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Side - Category Buttons Desktop */}
          <div className="hidden lg:block lg:col-span-2">
            <Card>
              <CardContent className="p-2">
                <div className="space-y-2">
                  {categories.map((category, index) => (
                    <Button
                      key={index}
                      className={`w-full ${category.color} text-sm`}
                      onClick={() => setSelectedCategory(category.name)}
                    >
                      {category.name}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Additional Discount Modal */}
      <Dialog
        open={showAdditionalDiscountModal}
        onOpenChange={setShowAdditionalDiscountModal}
      >
        <DialogContent className="max-w-sm p-0">
          <DialogHeader className="p-4 border-b">
            <div className="flex justify-between items-center">
              <DialogTitle>Additional Discount</DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowAdditionalDiscountModal(false)}
                className="p-0 h-auto"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="p-0">
            <form className="space-y-0">
              {/* Amount/Percentage Toggle */}
              <div className="p-4">
                <div className="flex gap-0 w-full">
                  <Button
                    type="button"
                    className={`flex-1 rounded-r-none ${
                      discountType === "AMOUNT"
                        ? "bg-blue-500 hover:bg-blue-600 text-white"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700 border"
                    }`}
                    onClick={() => setDiscountType("AMOUNT")}
                  >
                    AMOUNT
                  </Button>
                  <Button
                    type="button"
                    className={`flex-1 rounded-l-none ${
                      discountType === "PERCENTAGE"
                        ? "bg-blue-500 hover:bg-blue-600 text-white"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700 border"
                    }`}
                    onClick={() => setDiscountType("PERCENTAGE")}
                  >
                    PERCENTAGE
                  </Button>
                </div>
              </div>

              {/* Input Row */}
              <div className="bg-gray-100 flex">
                <div className="w-1/6 p-0">
                  <Button
                    type="button"
                    className="w-full h-12 rounded-none bg-gray-200 hover:bg-gray-300 text-gray-600"
                    onClick={() => handleKeypadInput("clear")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="w-4/6">
                  <Input
                    type="text"
                    value={discountAmount}
                    readOnly
                    className="w-full h-12 rounded-none border-0 text-center text-lg font-bold text-gray-800"
                    style={{ textAlign: "right" }}
                  />
                </div>
                <div className="w-1/6 p-0">
                  <Button
                    type="button"
                    className="w-full h-12 rounded-none bg-gray-200 hover:bg-gray-300 text-gray-600"
                    onClick={() => handleKeypadInput("backspace")}
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Keypad */}
              <table className="w-full border-collapse">
                <tbody>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("1")}
                      >
                        1
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("2")}
                      >
                        2
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("3")}
                      >
                        3
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("4")}
                      >
                        4
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("5")}
                      >
                        5
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("6")}
                      >
                        6
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("7")}
                      >
                        7
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("8")}
                      >
                        8
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("9")}
                      >
                        9
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput(".")}
                      >
                        .
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleKeypadInput("0")}
                      >
                        0
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="submit"
                        className="w-full h-12 rounded-none bg-blue-500 hover:bg-blue-600 text-white border-0"
                        onClick={(e) => {
                          e.preventDefault();
                          applyDiscount();
                        }}
                      >
                        ✓
                      </Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Modal */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="max-w-md p-0">
          <DialogHeader className="p-4 border-b">
            <div className="flex justify-between items-center">
              <DialogTitle>Payment</DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowPaymentModal(false)}
                className="p-0 h-auto"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="p-0">
            <form className="space-y-0">
              {/* Payment Method Tabs */}
              <div className="p-4">
                <ul className="nav-pills p-0 d-flex justify-content-center nav flex gap-2 justify-center">
                  <li className="p-0">
                    <Button
                      type="button"
                      className={`m-1 ${
                        activePaymentTab === "cash"
                          ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                          : "bg-gray-100 hover:bg-gray-200 text-gray-700 border border-yellow-500"
                      }`}
                      onClick={() => setActivePaymentTab("cash")}
                    >
                      Cash
                    </Button>
                  </li>
                  <li className="p-0">
                    <Button
                      type="button"
                      className={`m-1 ${
                        activePaymentTab === "mada"
                          ? "bg-cyan-500 hover:bg-cyan-600 text-white"
                          : "bg-gray-100 hover:bg-gray-200 text-gray-700 border border-cyan-500"
                      }`}
                      onClick={() => setActivePaymentTab("mada")}
                    >
                      Mada
                    </Button>
                  </li>
                  <li className="p-0">
                    <Button
                      type="button"
                      className={`m-1 ${
                        activePaymentTab === "visa"
                          ? "bg-red-500 hover:bg-red-600 text-white"
                          : "bg-gray-100 hover:bg-gray-200 text-gray-700 border border-red-500"
                      }`}
                      onClick={() => setActivePaymentTab("visa")}
                    >
                      Visa
                    </Button>
                  </li>
                </ul>
              </div>

              {/* Payment Summary */}
              <div className="px-4 py-2">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between border-b pb-1">
                    <span>Total</span>
                    <span>SAR {totalAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-b pb-1">
                    <span>PAID</span>
                    <span>SAR {paidAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-b pb-1">
                    <span>REMAINING</span>
                    <span>SAR {remainingAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CHANGE</span>
                    <span>SAR {changeAmount.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Input Row */}
              <div className="bg-gray-100 flex">
                <div className="w-1/6 p-0">
                  <Button
                    type="button"
                    className="w-full h-12 rounded-none bg-gray-200 hover:bg-gray-300 text-gray-600"
                    onClick={() => handlePaymentKeypadInput("clear")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="w-4/6">
                  <Input
                    type="text"
                    value={paymentAmount}
                    readOnly
                    className="w-full h-12 rounded-none border-0 text-center text-lg font-bold text-gray-800"
                    style={{ textAlign: "right" }}
                  />
                </div>
                <div className="w-1/6 p-0">
                  <Button
                    type="button"
                    className="w-full h-12 rounded-none bg-gray-200 hover:bg-gray-300 text-gray-600"
                    onClick={() => handlePaymentKeypadInput("backspace")}
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Quick Amount Buttons */}
              {activePaymentTab === "cash" && (
                <table className="w-full">
                  <tbody>
                    <tr>
                      {["10", "20", "50", "100", "200", "500"].map((amount) => (
                        <td key={amount} className="border p-0">
                          <Button
                            type="button"
                            className="w-full h-12 rounded-none bg-cyan-50 hover:bg-cyan-100 text-cyan-700 border-0 font-bold"
                            onClick={() => handlePaymentKeypadInput(amount)}
                          >
                            {amount}
                          </Button>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              )}

              {/* Numeric Keypad */}
              <table className="w-full border-collapse">
                <tbody>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("1")}
                      >
                        1
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("2")}
                      >
                        2
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("3")}
                      >
                        3
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("4")}
                      >
                        4
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("5")}
                      >
                        5
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("6")}
                      >
                        6
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("7")}
                      >
                        7
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("8")}
                      >
                        8
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("9")}
                      >
                        9
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput(".")}
                      >
                        .
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handlePaymentKeypadInput("0")}
                      >
                        0
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="submit"
                        className="w-full h-12 rounded-none bg-blue-500 hover:bg-blue-600 text-white border-0"
                        onClick={(e) => {
                          e.preventDefault();
                          applyPayment();
                        }}
                      >
                        ✓
                      </Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Line Item Discount Modal */}
      <Dialog
        open={showLineItemDiscountModal}
        onOpenChange={setShowLineItemDiscountModal}
      >
        <DialogContent className="max-w-sm p-0">
          <DialogHeader className="p-4 border-b">
            <div className="flex justify-between items-center">
              <DialogTitle>Line Item Discount</DialogTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowLineItemDiscountModal(false)}
                className="p-0 h-auto"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="p-0">
            <form className="space-y-0">
              {/* Amount/Percentage Toggle */}
              <div className="p-4">
                <div className="flex gap-0 w-full">
                  <Button
                    type="button"
                    className={`flex-1 rounded-r-none ${
                      lineItemDiscountType === "AMOUNT"
                        ? "bg-blue-500 hover:bg-blue-600 text-white"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700 border"
                    }`}
                    onClick={() => setLineItemDiscountType("AMOUNT")}
                  >
                    AMOUNT
                  </Button>
                  <Button
                    type="button"
                    className={`flex-1 rounded-l-none ${
                      lineItemDiscountType === "PERCENTAGE"
                        ? "bg-blue-500 hover:bg-blue-600 text-white"
                        : "bg-gray-100 hover:bg-gray-200 text-gray-700 border"
                    }`}
                    onClick={() => setLineItemDiscountType("PERCENTAGE")}
                  >
                    PERCENTAGE
                  </Button>
                </div>
              </div>

              {/* Input Row */}
              <div className="bg-gray-100 flex">
                <div className="w-1/6 p-0">
                  <Button
                    type="button"
                    className="w-full h-12 rounded-none bg-gray-200 hover:bg-gray-300 text-gray-600"
                    onClick={() => handleLineItemDiscountKeypadInput("clear")}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="w-4/6">
                  <Input
                    type="text"
                    value={lineItemDiscountAmount}
                    readOnly
                    className="w-full h-12 rounded-none border-0 text-center text-lg font-bold text-gray-800"
                    style={{ textAlign: "right" }}
                  />
                </div>
                <div className="w-1/6 p-0">
                  <Button
                    type="button"
                    className="w-full h-12 rounded-none bg-gray-200 hover:bg-gray-300 text-gray-600"
                    onClick={() =>
                      handleLineItemDiscountKeypadInput("backspace")
                    }
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Keypad */}
              <table className="w-full border-collapse">
                <tbody>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("1")}
                      >
                        1
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("2")}
                      >
                        2
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("3")}
                      >
                        3
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("4")}
                      >
                        4
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("5")}
                      >
                        5
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("6")}
                      >
                        6
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("7")}
                      >
                        7
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("8")}
                      >
                        8
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("9")}
                      >
                        9
                      </Button>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput(".")}
                      >
                        .
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="button"
                        className="w-full h-12 rounded-none bg-white hover:bg-gray-50 text-gray-800 border-0"
                        onClick={() => handleLineItemDiscountKeypadInput("0")}
                      >
                        0
                      </Button>
                    </td>
                    <td className="border p-0">
                      <Button
                        type="submit"
                        className="w-full h-12 rounded-none bg-blue-500 hover:bg-blue-600 text-white border-0"
                        onClick={(e) => {
                          e.preventDefault();
                          applyLineItemDiscount();
                        }}
                      >
                        ✓
                      </Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Order Modal */}
      <Dialog open={showParkOrderModal} onOpenChange={setShowParkOrderModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Car className="h-5 w-5 text-orange-500" />
              Create Order
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-gray-600">
              Create this order and automatically send it to the kitchen
              stations for preparation.
            </div>

            {/* Table Selection for Dine In and Drive Thru */}
            {(orderType === "dinein" || orderType === "driveThru") && (
              <div>
                <Label htmlFor="table-selection">
                  {orderType === "dinein" ? "Select Table *" : "Select Drive Thru Station *"}
                </Label>
                <Select value={selectedTable} onValueChange={setSelectedTable}>
                  <SelectTrigger>
                    <SelectValue
                      placeholder={orderType === "dinein" ? "Choose a table" : "Choose a drive thru station"}
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {mockTables
                      .filter((table) => table.status === "available")
                      .map((table) => (
                        <SelectItem key={table.id} value={table.number}>
                          <div className="flex items-center gap-2">
                            {orderType === "dinein" ? (
                              <Utensils className="h-4 w-4" />
                            ) : (
                              <Car className="h-4 w-4" />
                            )}
                            {table.number} ({table.seats} {orderType === "dinein" ? "seats" : "lanes"})
                          </div>
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                {selectedTable && (
                  <p className="text-xs text-green-600 mt-1">
                    ✓ {orderType === "dinein" ? "Table" : "Station"} {selectedTable} selected
                  </p>
                )}
              </div>
            )}

            {/* Order Summary */}
            <div className="bg-gray-50 p-3 rounded-lg">
              <h4 className="font-medium text-sm mb-2">Order Summary</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Order Type:</span>
                  <span className="capitalize">
                    {orderType === "dinein" && "Dine In"}
                    {orderType === "takeaway" && "Take Away"}
                    {orderType === "driveThru" && "Drive Thru"}
                    {orderType === "delivery" && "Delivery"}
                  </span>
                </div>
                {customerName && (
                  <div className="flex justify-between">
                    <span>Customer:</span>
                    <span>{customerName}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Items:</span>
                  <span>{cart.length} item(s)</span>
                </div>
                <div className="flex justify-between font-medium border-t pt-1">
                  <span>Total:</span>
                  <span>SAR {grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <Label htmlFor="order-notes">Additional Notes (Optional)</Label>
              <Textarea
                id="order-notes"
                value={parkOrderNotes}
                onChange={(e) => setParkOrderNotes(e.target.value)}
                placeholder="Any special instructions or notes for this order..."
                rows={3}
                className="mt-1"
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => {
                  setShowParkOrderModal(false);
                  setSelectedTable("");
                  setParkOrderNotes("");
                }}
              >
                Cancel
              </Button>
              <Button
                type="button"
                className="flex-1 bg-orange-500 hover:bg-orange-600"
                onClick={handleCreateOrder}
                disabled={orderType === "dinein" && !selectedTable}
              >
                <Car className="h-4 w-4 mr-2" />
                Create & Send to Kitchen
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Parked Orders Modal for Payment */}
      <Dialog
        open={showParkedOrdersModal}
        onOpenChange={setShowParkedOrdersModal}
      >
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Utensils className="h-5 w-5 text-purple-500" />
              Parked Orders - All Active Orders
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {parkedOrders.filter(
              (order) => order.status !== "paid", // Show all orders except paid ones
            ).length === 0 ? (
              <div className="text-center py-8">
                <Car className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No Parked Orders
                </h3>
                <p className="text-gray-500">No active parked orders found.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {parkedOrders
                  .filter((order) => order.status !== "paid")
                  .map((parkedOrder) => (
                    <Card
                      key={parkedOrder.id}
                      className="border-l-4 border-l-purple-500"
                    >
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {/* Order Header */}
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="font-semibold text-lg">
                                {parkedOrder.id}
                              </h3>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {parkedOrder.orderType === "dinein" && "Dine In"}
                                  {parkedOrder.orderType === "takeaway" && "Take Away"}
                                  {parkedOrder.orderType === "driveThru" && "Drive Thru"}
                                  {parkedOrder.orderType === "delivery" && "Delivery"}
                                </Badge>
                                <Badge
                                  className={
                                    parkedOrder.status === "ready"
                                      ? "bg-green-100 text-green-800"
                                      : parkedOrder.status === "in-kitchen"
                                        ? "bg-blue-100 text-blue-800"
                                        : "bg-orange-100 text-orange-800"
                                  }
                                >
                                  {parkedOrder.status === "ready"
                                    ? "Ready"
                                    : parkedOrder.status === "in-kitchen"
                                      ? "In Kitchen"
                                      : "Parked"}
                                </Badge>
                              </div>
                            </div>
                            <div className="text-right text-sm text-gray-500">
                              {parkedOrder.tableNumber && (
                                <div className="font-medium text-gray-700">
                                  {parkedOrder.tableNumber}
                                </div>
                              )}
                              {parkedOrder.customerName && (
                                <div className="mt-1 text-gray-700">
                                  {parkedOrder.customerName}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Order Items Summary */}
                          <div className="bg-gray-50 p-3 rounded">
                            <div className="text-sm font-medium mb-2">
                              Items ({parkedOrder.items.length}):
                            </div>
                            {parkedOrder.items.slice(0, 3).map((item) => (
                              <div
                                key={item.id}
                                className="flex justify-between text-sm"
                              >
                                <span>
                                  {item.name} x{item.quantity}
                                </span>
                                <span>SAR {item.amount.toFixed(2)}</span>
                              </div>
                            ))}
                            {parkedOrder.items.length > 3 && (
                              <div className="text-xs text-gray-500 mt-1">
                                +{parkedOrder.items.length - 3} more items
                              </div>
                            )}
                            <div className="border-t pt-2 mt-2 font-medium">
                              <div className="flex justify-between">
                                <span>Total:</span>
                                <span>
                                  SAR {parkedOrder.grandTotal.toFixed(2)}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Notes */}
                          {parkedOrder.notes && (
                            <div className="text-xs text-gray-600 bg-yellow-50 p-2 rounded">
                              📝 {parkedOrder.notes}
                            </div>
                          )}

                          {/* Status Information */}
                          {parkedOrder.status === "in-kitchen" && (
                            <div className="text-xs text-blue-700 bg-blue-50 border border-blue-200 p-2 rounded">
                              🍳 <strong>Currently Being Prepared</strong> - You
                              can still edit this order to add items or make
                              changes.
                            </div>
                          )}

                          {parkedOrder.status === "ready" && (
                            <div className="text-xs text-green-700 bg-green-50 border border-green-200 p-2 rounded">
                              ✅ <strong>Ready for Pickup</strong> - Order
                              preparation completed.
                            </div>
                          )}

                          {/* Action Button */}
                          <div className="flex">
                            <Button
                              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                              onClick={() => handleLoadParkedOrder(parkedOrder)}
                            >
                              <Receipt className="h-4 w-4 mr-2" />
                              Load
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Order Type Selection Modal */}
      <Dialog open={showOrderTypeModal} onOpenChange={setShowOrderTypeModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">Select Order Type</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 p-4">
            {/* Dine In */}
            <Button
              className="h-24 flex flex-col items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 text-white"
              onClick={() => {
                setOrderType("dinein");
                setShowOrderTypeModal(false);
              }}
            >
              <Home className="h-8 w-8" />
              <span className="text-sm font-medium">Dine In</span>
            </Button>

            {/* Drive Thru */}
            <Button
              className="h-24 flex flex-col items-center justify-center gap-2 bg-green-500 hover:bg-green-600 text-white"
              onClick={() => {
                setOrderType("driveThru");
                setShowOrderTypeModal(false);
              }}
            >
              <Car className="h-8 w-8" />
              <span className="text-sm font-medium">Drive Thru</span>
            </Button>

            {/* Take Away */}
            <Button
              className="h-24 flex flex-col items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white"
              onClick={() => {
                setOrderType("takeaway");
                setShowOrderTypeModal(false);
              }}
            >
              <ShoppingBag className="h-8 w-8" />
              <span className="text-sm font-medium">Take Away</span>
            </Button>

            {/* Delivery */}
            <Button
              className="h-24 flex flex-col items-center justify-center gap-2 bg-purple-500 hover:bg-purple-600 text-white"
              onClick={() => {
                setOrderType("delivery");
                setShowOrderTypeModal(false);
              }}
            >
              <Truck className="h-8 w-8" />
              <span className="text-sm font-medium">Delivery</span>
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Invoice Print Component */}
      {invoiceData && (
        <InvoicePrint
          isOpen={showInvoicePrint}
          onClose={() => {
            setShowInvoicePrint(false);
            setInvoiceData(null);
          }}
          invoiceData={invoiceData}
        />
      )}
    </div>
  );
}
