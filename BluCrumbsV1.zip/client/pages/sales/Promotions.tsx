import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Percent,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  Calendar,
  Clock,
  Tag,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Promotion {
  id: string;
  description: string;
  arabicDescription: string;
  discountType: "percentage" | "sar";
  discountValue: number;
  items: string[];
  category: string;
  branches: string[];
  hasDays: boolean;
  days?: string[];
  fromDate: string;
  toDate: string;
  hasTime: boolean;
  startTime?: string;
  endTime?: string;
  status: "active" | "inactive";
  createdDate: string;
}

const mockPromotions: Promotion[] = [
  {
    id: "PROMO001",
    description: "Weekend Special",
    arabicDescription: "عرض نهاية الأسبوع",
    discountType: "percentage",
    discountValue: 20,
    items: ["Burger Combo", "Pizza Family"],
    category: "Main Courses",
    branches: ["Main Branch", "Downtown Branch"],
    hasDays: true,
    days: ["Friday", "Saturday"],
    fromDate: "2024-01-01",
    toDate: "2024-12-31",
    hasTime: true,
    startTime: "18:00",
    endTime: "23:00",
    status: "active",
    createdDate: "2024-01-10",
  },
  {
    id: "PROMO002",
    description: "Happy Hour Drinks",
    arabicDescription: "سا��ة سعيدة للمشروبات",
    discountType: "sar",
    discountValue: 5,
    items: ["Fresh Juice", "Coffee"],
    category: "Beverages",
    branches: ["Mall Branch"],
    hasDays: false,
    fromDate: "2024-01-15",
    toDate: "2024-02-15",
    hasTime: true,
    startTime: "15:00",
    endTime: "17:00",
    status: "active",
    createdDate: "2024-01-12",
  },
];

const mockMenuItems = [
  "Burger Combo",
  "Pizza Family",
  "Fresh Juice",
  "Coffee",
  "Chicken Sandwich",
  "Caesar Salad",
  "Grilled Fish",
  "Pasta Alfredo",
  "Ice Cream",
  "Chocolate Cake",
];

const mockCategories = [
  "Main Courses",
  "Beverages",
  "Appetizers",
  "Desserts",
  "Sides",
  "Salads",
];

const weekDays = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];

const mockBranches = [
  "Main Branch",
  "Downtown Branch",
  "Mall Branch",
  "Airport Branch",
  "Seaside Branch",
  "City Center Branch",
];

export default function Promotions() {
  const [promotions] = useState<Promotion[]>(mockPromotions);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<Promotion>>({
    status: "active",
    discountType: "percentage",
    hasDays: false,
    hasTime: false,
    items: [],
    days: [],
    branches: [],
  });

  const handleInputChange = (field: keyof Promotion, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleItemSelection = (item: string, checked: boolean) => {
    const currentItems = formData.items || [];
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        items: [...currentItems, item],
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        items: currentItems.filter((i) => i !== item),
      }));
    }
  };

  const handleDaySelection = (day: string, checked: boolean) => {
    const currentDays = formData.days || [];
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        days: [...currentDays, day],
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        days: currentDays.filter((d) => d !== day),
      }));
    }
  };

  const handleBranchSelection = (branch: string, checked: boolean) => {
    const currentBranches = formData.branches || [];
    if (checked) {
      setFormData((prev) => ({
        ...prev,
        branches: [...currentBranches, branch],
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        branches: currentBranches.filter((b) => b !== branch),
      }));
    }
  };

  const resetForm = () => {
    setFormData({
      status: "active",
      discountType: "percentage",
      hasDays: false,
      hasTime: false,
      items: [],
      days: [],
      branches: [],
    });
  };

  const filteredPromotions = promotions.filter(
    (promotion) =>
      promotion.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      promotion.arabicDescription.includes(searchTerm) ||
      promotion.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      promotion.category.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "inactive":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Percent className="h-8 w-8 text-blucrumbs-blue-500" />
            Promotions
          </h1>
          <p className="text-gray-600 mt-1">
            Manage promotional offers and discounts
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add New Promotion
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Promotion</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="promotionId">ID</Label>
                  <Input
                    id="promotionId"
                    value={`PROMO${String(promotions.length + 1).padStart(3, "0")}`}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
                <div></div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter promotion description"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">
                    Arabic Description *
                  </Label>
                  <Input
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="أدخل وصف العرض بالعربية"
                    dir="rtl"
                    required
                  />
                </div>
              </div>

              {/* Discount */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Discount Type *</Label>
                  <div className="flex gap-4 mt-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="discountType"
                        value="percentage"
                        checked={formData.discountType === "percentage"}
                        onChange={(e) =>
                          handleInputChange("discountType", e.target.value)
                        }
                        className="w-4 h-4 text-blucrumbs-blue-600"
                      />
                      <span className="text-sm">Percentage</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="discountType"
                        value="sar"
                        checked={formData.discountType === "sar"}
                        onChange={(e) =>
                          handleInputChange("discountType", e.target.value)
                        }
                        className="w-4 h-4 text-blucrumbs-blue-600"
                      />
                      <span className="text-sm">SAR</span>
                    </label>
                  </div>
                </div>
                <div>
                  <Label htmlFor="discountValue">
                    Discount Value * (
                    {formData.discountType === "percentage" ? "%" : "SAR"})
                  </Label>
                  <Input
                    id="discountValue"
                    type="number"
                    step={formData.discountType === "percentage" ? "1" : "0.01"}
                    min="0"
                    max={
                      formData.discountType === "percentage" ? "100" : undefined
                    }
                    value={formData.discountValue || ""}
                    onChange={(e) =>
                      handleInputChange(
                        "discountValue",
                        parseFloat(e.target.value),
                      )
                    }
                    placeholder="0"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select
                    value={formData.category || ""}
                    onValueChange={(value) =>
                      handleInputChange("category", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Items Selection */}
              <div>
                <Label>Item(s) - Multiple Selection</Label>
                <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto border rounded p-3">
                  {mockMenuItems.map((item) => (
                    <label
                      key={item}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={formData.items?.includes(item) || false}
                        onChange={(e) =>
                          handleItemSelection(item, e.target.checked)
                        }
                        className="w-4 h-4 text-blucrumbs-blue-600"
                      />
                      <span className="text-sm">{item}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Branches Selection */}
              <div>
                <Label>Branch(es) - Multiple Selection</Label>
                <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto border rounded p-3">
                  {mockBranches.map((branch) => (
                    <label
                      key={branch}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={formData.branches?.includes(branch) || false}
                        onChange={(e) =>
                          handleBranchSelection(branch, e.target.checked)
                        }
                        className="w-4 h-4 text-blucrumbs-blue-600"
                      />
                      <span className="text-sm">{branch}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Days Switch */}
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    checked={formData.hasDays || false}
                    onCheckedChange={(checked) =>
                      handleInputChange("hasDays", checked)
                    }
                  />
                  <Label>Days</Label>
                </div>

                {formData.hasDays ? (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Day(s) - Multiple Selection</Label>
                      <div className="mt-2 space-y-2 max-h-32 overflow-y-auto border rounded p-3">
                        {weekDays.map((day) => (
                          <label
                            key={day}
                            className="flex items-center space-x-2 cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              checked={formData.days?.includes(day) || false}
                              onChange={(e) =>
                                handleDaySelection(day, e.target.checked)
                              }
                              className="w-4 h-4 text-blucrumbs-blue-600"
                            />
                            <span className="text-sm">{day}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="fromDate">From Date *</Label>
                        <Input
                          id="fromDate"
                          type="date"
                          value={formData.fromDate || ""}
                          onChange={(e) =>
                            handleInputChange("fromDate", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="toDate">To Date *</Label>
                        <Input
                          id="toDate"
                          type="date"
                          value={formData.toDate || ""}
                          onChange={(e) =>
                            handleInputChange("toDate", e.target.value)
                          }
                          required
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fromDateOnly">From Date *</Label>
                      <Input
                        id="fromDateOnly"
                        type="date"
                        value={formData.fromDate || ""}
                        onChange={(e) =>
                          handleInputChange("fromDate", e.target.value)
                        }
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="toDateOnly">To Date *</Label>
                      <Input
                        id="toDateOnly"
                        type="date"
                        value={formData.toDate || ""}
                        onChange={(e) =>
                          handleInputChange("toDate", e.target.value)
                        }
                        required
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Time Switch */}
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Switch
                    checked={formData.hasTime || false}
                    onCheckedChange={(checked) =>
                      handleInputChange("hasTime", checked)
                    }
                  />
                  <Label>Time</Label>
                </div>

                {formData.hasTime && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="startTime">Start Time</Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={formData.startTime || ""}
                        onChange={(e) =>
                          handleInputChange("startTime", e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="endTime">End Time</Label>
                      <Input
                        id="endTime"
                        type="time"
                        value={formData.endTime || ""}
                        onChange={(e) =>
                          handleInputChange("endTime", e.target.value)
                        }
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Status */}
              <div>
                <Label>Status *</Label>
                <div className="flex gap-6 mt-2">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="active"
                      checked={formData.status === "active"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                      className="w-4 h-4 text-blucrumbs-blue-600"
                    />
                    <span className="text-sm">Active</span>
                  </label>
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="inactive"
                      checked={formData.status === "inactive"}
                      onChange={(e) =>
                        handleInputChange("status", e.target.value)
                      }
                      className="w-4 h-4 text-blucrumbs-blue-600"
                    />
                    <span className="text-sm">Inactive</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Promotion
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blucrumbs-blue-600">
                {promotions.length}
              </div>
              <div className="text-sm text-gray-500">Total Promotions</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {promotions.filter((p) => p.status === "active").length}
              </div>
              <div className="text-sm text-gray-500">Active Promotions</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {
                  promotions.filter((p) => p.discountType === "percentage")
                    .length
                }
              </div>
              <div className="text-sm text-gray-500">Percentage Discounts</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {promotions.filter((p) => p.hasTime).length}
              </div>
              <div className="text-sm text-gray-500">Time-Based Offers</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search promotions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Promotions Table */}
      <Card>
        <CardHeader>
          <CardTitle>Promotions Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredPromotions.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Arabic Description</TableHead>
                    <TableHead>Discount</TableHead>
                    <TableHead>Items</TableHead>
                    <TableHead>Branches</TableHead>
                    <TableHead>From Date</TableHead>
                    <TableHead>To Date</TableHead>
                    <TableHead>Start Time</TableHead>
                    <TableHead>End Time</TableHead>
                    <TableHead>Days</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPromotions.map((promotion) => (
                    <TableRow key={promotion.id}>
                      <TableCell className="font-medium">
                        {promotion.id}
                      </TableCell>
                      <TableCell>{promotion.description}</TableCell>
                      <TableCell dir="rtl">
                        {promotion.arabicDescription}
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-orange-100 text-orange-800">
                          {promotion.discountValue}
                          {promotion.discountType === "percentage"
                            ? "%"
                            : " SAR"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-32">
                          {promotion.items.slice(0, 2).join(", ")}
                          {promotion.items.length > 2 &&
                            ` +${promotion.items.length - 2} more`}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-32">
                          {promotion.branches.slice(0, 2).join(", ")}
                          {promotion.branches.length > 2 &&
                            ` +${promotion.branches.length - 2} more`}
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(promotion.fromDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        {new Date(promotion.toDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{promotion.startTime || "-"}</TableCell>
                      <TableCell>{promotion.endTime || "-"}</TableCell>
                      <TableCell>
                        {promotion.hasDays ? (
                          <div className="max-w-24">
                            {promotion.days?.slice(0, 2).join(", ")}
                            {promotion.days &&
                              promotion.days.length > 2 &&
                              ` +${promotion.days.length - 2}`}
                          </div>
                        ) : (
                          "All Days"
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(promotion.status)}>
                          {promotion.status === "active"
                            ? "Active"
                            : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12">
              <Percent className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Promotions Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No promotions match your search criteria."
                  : "Get started by creating your first promotion."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add New Promotion
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
