import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Calculator,
  Calendar,
  Search,
  FileText,
  DollarSign,
  TrendingUp,
  TrendingDown,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface ClosingEntry {
  id: string;
  date: string;
  documentNo: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
  type: "sale" | "refund" | "expense" | "adjustment";
  status: "pending" | "submitted" | "approved";
}

const mockClosingEntries: ClosingEntry[] = [
  {
    id: "1",
    date: "2024-01-20",
    documentNo: "SAL001",
    description: "Cash Sales",
    debit: 1250.0,
    credit: 0,
    balance: 1250.0,
    type: "sale",
    status: "approved",
  },
  {
    id: "2",
    date: "2024-01-20",
    documentNo: "SAL002",
    description: "Card Payments",
    debit: 2150.5,
    credit: 0,
    balance: 3400.5,
    type: "sale",
    status: "approved",
  },
  {
    id: "3",
    date: "2024-01-20",
    documentNo: "REF001",
    description: "Customer Refund",
    debit: 0,
    credit: 75.0,
    balance: 3325.5,
    type: "refund",
    status: "approved",
  },
  {
    id: "4",
    date: "2024-01-20",
    documentNo: "EXP001",
    description: "Operating Expenses",
    debit: 0,
    credit: 120.0,
    balance: 3205.5,
    type: "expense",
    status: "approved",
  },
  {
    id: "5",
    date: "2024-01-20",
    documentNo: "ADJ001",
    description: "Cash Count Adjustment",
    debit: 0,
    credit: 15.5,
    balance: 3190.0,
    type: "adjustment",
    status: "pending",
  },
];

export default function Closing() {
  const [entries] = useState<ClosingEntry[]>(mockClosingEntries);
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0],
  );
  const [searchTerm, setSearchTerm] = useState("");

  const filteredEntries = entries.filter(
    (entry) =>
      entry.date === selectedDate &&
      (entry.documentNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.description.toLowerCase().includes(searchTerm.toLowerCase())),
  );

  // Calculate totals
  const totalDebit = filteredEntries.reduce(
    (sum, entry) => sum + entry.debit,
    0,
  );
  const totalCredit = filteredEntries.reduce(
    (sum, entry) => sum + entry.credit,
    0,
  );
  const netBalance = totalDebit - totalCredit;
  const pendingEntries = filteredEntries.filter(
    (entry) => entry.status === "pending",
  ).length;

  const getTypeColor = (type: string) => {
    switch (type) {
      case "sale":
        return "bg-green-100 text-green-800";
      case "refund":
        return "bg-red-100 text-red-800";
      case "expense":
        return "bg-orange-100 text-orange-800";
      case "adjustment":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "submitted":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleSubmitClosing = () => {
    alert("Daily closing summary submitted successfully!");
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Calculator className="h-8 w-8 text-blucrumbs-blue-500" />
            Daily Closing Summary
          </h1>
          <p className="text-gray-600 mt-1">
            Review and submit daily financial closing
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gray-500" />
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-40"
            />
          </div>
          <Button
            className="bg-blucrumbs-orange-500 hover:bg-blucrumbs-orange-600"
            onClick={handleSubmitClosing}
            disabled={pendingEntries > 0}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Submit Closing
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                ${totalDebit.toFixed(2)}
              </div>
              <div className="text-sm text-gray-500 flex items-center justify-center gap-1">
                <TrendingUp className="h-3 w-3" />
                Total Debit
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                ${totalCredit.toFixed(2)}
              </div>
              <div className="text-sm text-gray-500 flex items-center justify-center gap-1">
                <TrendingDown className="h-3 w-3" />
                Total Credit
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blucrumbs-blue-600">
                ${netBalance.toFixed(2)}
              </div>
              <div className="text-sm text-gray-500 flex items-center justify-center gap-1">
                <DollarSign className="h-3 w-3" />
                Net Balance
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {filteredEntries.length}
              </div>
              <div className="text-sm text-gray-500 flex items-center justify-center gap-1">
                <FileText className="h-3 w-3" />
                Total Entries
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {pendingEntries}
              </div>
              <div className="text-sm text-gray-500 flex items-center justify-center gap-1">
                <AlertCircle className="h-3 w-3" />
                Pending Items
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Alert */}
      {pendingEntries > 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
              <div>
                <div className="font-medium text-yellow-800">
                  {pendingEntries} Pending Item(s) Require Approval
                </div>
                <div className="text-sm text-yellow-700">
                  All entries must be approved before submitting the daily
                  closing.
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search by document or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Daily Closing Inquiry Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Daily Closing Inquiry -{" "}
            {new Date(selectedDate).toLocaleDateString()}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredEntries.length > 0 ? (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Document No.</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Debit</TableHead>
                    <TableHead className="text-right">Credit</TableHead>
                    <TableHead className="text-right">Balance</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEntries.map((entry) => (
                    <TableRow key={entry.id}>
                      <TableCell>
                        {new Date(entry.date).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="font-medium">
                        {entry.documentNo}
                      </TableCell>
                      <TableCell>{entry.description}</TableCell>
                      <TableCell>
                        <Badge className={getTypeColor(entry.type)}>
                          {entry.type.charAt(0).toUpperCase() +
                            entry.type.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {entry.debit > 0 ? `$${entry.debit.toFixed(2)}` : "-"}
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {entry.credit > 0 ? `$${entry.credit.toFixed(2)}` : "-"}
                      </TableCell>
                      <TableCell className="text-right font-mono font-semibold">
                        ${entry.balance.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(entry.status)}>
                          {entry.status.charAt(0).toUpperCase() +
                            entry.status.slice(1)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Summary Row */}
              <div className="border-t pt-4">
                <div className="grid grid-cols-5 gap-4 text-sm">
                  <div></div>
                  <div></div>
                  <div className="font-semibold">TOTALS:</div>
                  <div className="text-right font-semibold text-green-600">
                    ${totalDebit.toFixed(2)}
                  </div>
                  <div className="text-right font-semibold text-red-600">
                    ${totalCredit.toFixed(2)}
                  </div>
                </div>
                <div className="grid grid-cols-5 gap-4 text-lg font-bold mt-2 pt-2 border-t">
                  <div></div>
                  <div></div>
                  <div>NET BALANCE:</div>
                  <div></div>
                  <div className="text-right text-blucrumbs-blue-600">
                    ${netBalance.toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Calculator className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Entries Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? `No entries match your search criteria for ${new Date(selectedDate).toLocaleDateString()}.`
                  : `No closing entries found for ${new Date(selectedDate).toLocaleDateString()}.`}
              </p>
              <Button variant="outline" onClick={() => setSearchTerm("")}>
                Clear Search
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-end gap-4">
        <Button variant="outline">
          <FileText className="h-4 w-4 mr-2" />
          Export Report
        </Button>
        <Button variant="outline">
          <Calendar className="h-4 w-4 mr-2" />
          View Previous Days
        </Button>
      </div>
    </div>
  );
}
