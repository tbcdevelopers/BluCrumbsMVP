import { useState, useEffect } from "react";
import {
  useParkedOrders,
  type ParkedOrder,
  type ParkedOrderItem,
} from "@/contexts/ParkedOrdersContext";
import ParkedOrderEdit from "@/components/ParkedOrderEdit";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ChefHat,
  Clock,
  CheckCircle,
  Eye,
  RefreshCw,
  Users,
  Package,
  Car,
  Edit,
  MoreHorizontal,
  Plus,
} from "lucide-react";

interface MenuItem {
  id: string;
  name: string;
  quantity: number;
  specialInstructions?: string;
  ingredients: string[];
  estimatedTime: number; // in minutes
}

interface Order {
  id: string;
  orderType: "dine-in" | "take-away";
  timestamp: string;
  tableNumber?: string;
  customerName?: string;
  items: MenuItem[];
  station: string;
  status: "pending" | "preparing" | "ready" | "paid";
  priority: "normal" | "urgent";
  workflow: string[]; // Array of stations this order must go through
  currentStationIndex: number; // Current position in the workflow
}

interface Station {
  id: string;
  name: string;
  color: string;
}

const mockStations: Station[] = [
  { id: "grill", name: "Grill Station", color: "bg-red-500" },
  { id: "salad", name: "Salad Station", color: "bg-green-500" },
  { id: "dessert", name: "Dessert Station", color: "bg-purple-500" },
  { id: "beverages", name: "Beverage Station", color: "bg-blue-500" },
  { id: "fry", name: "Fry Station", color: "bg-yellow-500" },
  { id: "assembly", name: "Assembly Station", color: "bg-orange-500" },
];

// Define common workflows for different order types
const stationWorkflows = {
  "main-course": ["grill", "assembly"], // Grill items go to assembly
  "salad-only": ["salad"], // Salads can go direct to pickup
  "dessert-only": ["dessert"], // Desserts can go direct to pickup
  "beverage-only": ["beverages"], // Beverages can go direct to pickup
  "fried-food": ["fry", "assembly"], // Fried items go to assembly
  "complex-order": ["grill", "fry", "assembly"], // Orders needing multiple stations
};

const mockOrders: Order[] = [
  {
    id: "ORD-001",
    orderType: "dine-in",
    timestamp: "2024-01-20T14:30:00Z",
    tableNumber: "T05",
    items: [
      {
        id: "item1",
        name: "Grilled Chicken Breast",
        quantity: 2,
        ingredients: [
          "Chicken breast",
          "Olive oil",
          "Garlic",
          "Herbs",
          "Salt",
          "Pepper",
        ],
        estimatedTime: 15,
        specialInstructions: "Well done, no garlic",
      },
      {
        id: "item2",
        name: "BBQ Beef Burger",
        quantity: 1,
        ingredients: [
          "Beef patty",
          "BBQ sauce",
          "Onions",
          "Pickles",
          "Lettuce",
        ],
        estimatedTime: 12,
      },
    ],
    station: "grill",
    status: "preparing",
    priority: "normal",
    workflow: ["grill", "assembly"],
    currentStationIndex: 0,
  },
  {
    id: "ORD-002",
    orderType: "take-away",
    timestamp: "2024-01-20T14:35:00Z",
    customerName: "Sarah Johnson",
    items: [
      {
        id: "item3",
        name: "Caesar Salad",
        quantity: 1,
        ingredients: [
          "Romaine lettuce",
          "Caesar dressing",
          "Croutons",
          "Parmesan",
          "Anchovies",
        ],
        estimatedTime: 5,
      },
      {
        id: "item4",
        name: "Greek Salad",
        quantity: 2,
        ingredients: [
          "Lettuce",
          "Tomatoes",
          "Cucumbers",
          "Olives",
          "Feta cheese",
          "Olive oil",
        ],
        estimatedTime: 8,
      },
    ],
    station: "salad",
    status: "pending",
    priority: "urgent",
    workflow: ["salad"],
    currentStationIndex: 0,
  },
  {
    id: "ORD-003",
    orderType: "dine-in",
    timestamp: "2024-01-20T14:25:00Z",
    tableNumber: "T12",
    items: [
      {
        id: "item5",
        name: "Chocolate Cake",
        quantity: 1,
        ingredients: [
          "Chocolate",
          "Flour",
          "Sugar",
          "Eggs",
          "Butter",
          "Vanilla",
        ],
        estimatedTime: 3,
      },
    ],
    station: "dessert",
    status: "ready",
    priority: "normal",
    workflow: ["dessert"],
    currentStationIndex: 0,
  },
  {
    id: "ORD-004",
    orderType: "dine-in",
    timestamp: "2024-01-20T14:40:00Z",
    tableNumber: "T08",
    items: [
      {
        id: "item6",
        name: "French Fries",
        quantity: 2,
        ingredients: ["Potatoes", "Oil", "Salt"],
        estimatedTime: 8,
      },
      {
        id: "item7",
        name: "Onion Rings",
        quantity: 1,
        ingredients: ["Onions", "Flour", "Eggs", "Breadcrumbs", "Oil"],
        estimatedTime: 10,
      },
    ],
    station: "fry",
    status: "pending",
    priority: "normal",
    workflow: ["fry", "assembly"],
    currentStationIndex: 0,
  },
  {
    id: "ORD-005",
    orderType: "dine-in",
    timestamp: "2024-01-20T14:20:00Z",
    tableNumber: "T03",
    items: [
      {
        id: "item8",
        name: "Burger + Fries Combo",
        quantity: 1,
        ingredients: [
          "Beef patty",
          "Bun",
          "Lettuce",
          "Tomato",
          "Potatoes",
          "Oil",
        ],
        estimatedTime: 8,
      },
    ],
    station: "assembly",
    status: "pending",
    priority: "normal",
    workflow: ["grill", "fry", "assembly"],
    currentStationIndex: 2, // Currently at assembly station
  },
];

export default function LiveOrders() {
  const {
    parkedOrders,
    sendOrderToKitchen,
    markOrderReady,
    addParkedOrder,
    markItemCompleted,
    updateParkedOrder,
  } = useParkedOrders();
  const [selectedStation, setSelectedStation] = useState<string>("all");
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [selectedIngredients, setSelectedIngredients] =
    useState<MenuItem | null>(null);
  const [editingParkedOrder, setEditingParkedOrder] =
    useState<ParkedOrder | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);

  // Keep track of parked orders that have been sent to kitchen to maintain persistence
  useEffect(() => {
    // Update live orders when parked orders change
    setOrders((prevOrders) => {
      // Get parked order IDs to filter them out
      const parkedOrderIds = new Set(parkedOrders.map((order) => order.id));
      const nonParkedOrders = prevOrders.filter(
        (order) => !parkedOrderIds.has(order.id),
      );
      const parkedLiveOrders = parkedOrders
        .filter(
          (parkedOrder) => parkedOrder.status === "in-kitchen", // Only show in-kitchen orders in station view
          // Ready orders should never appear in station view - they're done!
          // Note: Orders with new items will still show here, but new items will be sent separately
        )
        .map((parkedOrder) => {
          // Check if this order already exists in live orders
          const existingOrder = prevOrders.find(
            (order) => order.id === parkedOrder.id,
          );
          if (existingOrder) {
            // Update existing order with latest parked order data
            return {
              ...existingOrder,
              items: parkedOrder.items.map((item) => ({
                id: item.id,
                originalItemId: item.originalItemId,
                name: item.name,
                quantity: item.quantity,
                ingredients: item.ingredients || [],
                estimatedTime: item.estimatedTime || 10,
                specialInstructions: item.specialInstructions,
                // Preserve completion status from parked order item
                isCompleted: item.isCompleted || false,
                completedAt: item.completedAt,
                addedInVersion: item.addedInVersion,
                isNew: item.isNew,
              })),
              customerName: parkedOrder.customerName,
              tableNumber: parkedOrder.tableNumber,
              // Update station assignment if order was edited
              station: parkedOrder.recommendedStation || existingOrder.station,
              workflow:
                parkedOrder.recommendedWorkflow || existingOrder.workflow,
              status:
                parkedOrder.status === "ready"
                  ? ("ready" as const)
                  : existingOrder.status,
            };
          } else {
            // Create new live order from parked order
            const { station, workflow } =
              parkedOrder.recommendedStation && parkedOrder.recommendedWorkflow
                ? {
                    station: parkedOrder.recommendedStation,
                    workflow: parkedOrder.recommendedWorkflow,
                  }
                : determineStationAndWorkflow(parkedOrder.items);

            return {
              id: parkedOrder.id,
              orderType:
                parkedOrder.orderType === "dinein"
                  ? ("dine-in" as const)
                  : ("take-away" as const),
              timestamp: parkedOrder.timestamp,
              tableNumber: parkedOrder.tableNumber,
              customerName: parkedOrder.customerName,
              items: parkedOrder.items.map((item) => ({
                id: item.id,
                originalItemId: item.originalItemId,
                name: item.name,
                quantity: item.quantity,
                ingredients: item.ingredients || [],
                estimatedTime: item.estimatedTime || 10,
                specialInstructions: item.specialInstructions,
                // Preserve completion status from parked order item
                isCompleted: item.isCompleted || false,
                completedAt: item.completedAt,
                addedInVersion: item.addedInVersion,
                isNew: item.isNew,
              })),
              station,
              status:
                parkedOrder.status === "ready"
                  ? ("ready" as const)
                  : ("pending" as const),
              priority: parkedOrder.priority,
              workflow,
              currentStationIndex: 0,
            };
          }
        });

      const combinedOrders = [...nonParkedOrders, ...parkedLiveOrders];

      // Deduplicate by order ID to prevent any duplicates
      const uniqueOrders = combinedOrders.filter(
        (order, index, self) =>
          index === self.findIndex((o) => o.id === order.id),
      );

      return uniqueOrders;
    });
  }, [parkedOrders]);

  // Helper function to determine station and workflow
  const determineStationAndWorkflow = (items: any[]) => {
    const hasGrilledItems = items.some(
      (item) =>
        item.name.toLowerCase().includes("chicken") ||
        item.name.toLowerCase().includes("burger") ||
        item.name.toLowerCase().includes("beef") ||
        item.name.toLowerCase().includes("grilled"),
    );
    const hasFriedItems = items.some(
      (item) =>
        item.name.toLowerCase().includes("fries") ||
        item.name.toLowerCase().includes("nuggets") ||
        item.name.toLowerCase().includes("fried"),
    );
    const hasSaladItems = items.some((item) =>
      item.name.toLowerCase().includes("salad"),
    );
    const hasBeverageItems = items.some(
      (item) =>
        item.name.toLowerCase().includes("drink") ||
        item.name.toLowerCase().includes("juice") ||
        item.name.toLowerCase().includes("coffee") ||
        item.name.toLowerCase().includes("tea"),
    );

    if (hasSaladItems && !hasGrilledItems && !hasFriedItems) {
      return { station: "salad", workflow: ["salad"] };
    } else if (
      hasBeverageItems &&
      !hasGrilledItems &&
      !hasFriedItems &&
      !hasSaladItems
    ) {
      return { station: "beverages", workflow: ["beverages"] };
    } else if (hasFriedItems && hasGrilledItems) {
      return { station: "grill", workflow: ["grill", "fry", "assembly"] };
    } else if (hasFriedItems) {
      return { station: "fry", workflow: ["fry", "assembly"] };
    } else if (hasGrilledItems) {
      return { station: "grill", workflow: ["grill", "assembly"] };
    } else {
      return { station: "grill", workflow: ["grill", "assembly"] }; // Default
    }
  };

  const handleStationChange = (stationId: string) => {
    setSelectedStation(stationId);
    console.log(`Station filter changed to: ${stationId}`);
    console.log(`Total orders: ${orders.length}`);
    const filteredCount =
      stationId === "all"
        ? orders.filter((order) => order.status !== "paid").length
        : orders.filter(
            (order) => order.station === stationId && order.status !== "paid",
          ).length;
    console.log(`Filtered orders for ${stationId}: ${filteredCount}`);
  };

  // New items automatically appear in assigned stations - no manual intervention needed

  // Orders are automatically sent to kitchen with new items appearing immediately in assigned stations

  // Handle when a parked order is marked ready in kitchen
  const handleParkedOrderReady = (orderId: string) => {
    markOrderReady(orderId);
  };

  const handleMarkReady = (orderId: string) => {
    setOrders((prevOrders) =>
      prevOrders.map((order) => {
        if (order.id !== orderId) return order;

        const nextStationIndex = order.currentStationIndex + 1;

        // Check if this is the last station in the workflow
        if (nextStationIndex >= order.workflow.length) {
          // Final station - mark as ready for pickup
          handleParkedOrderReady(orderId);
          return { ...order, status: "ready" as const };
        } else {
          // Move to next station in workflow
          const nextStation = order.workflow[nextStationIndex];
          return {
            ...order,
            station: nextStation,
            currentStationIndex: nextStationIndex,
            status: "pending" as const, // Reset status for new station
          };
        }
      }),
    );

    // Remove ready orders after a delay (simulate pickup)
    setTimeout(() => {
      setOrders((prevOrders) =>
        prevOrders.filter(
          (order) => !(order.id === orderId && order.status === "ready"),
        ),
      );
    }, 2000);
  };

  const filteredOrders =
    selectedStation === "all"
      ? orders.filter((order) => order.status !== "paid") // Hide paid orders from all views
      : orders.filter(
          (order) =>
            order.station === selectedStation && order.status !== "paid",
        );

  const getTimeSince = (timestamp: string) => {
    const now = new Date();
    const orderTime = new Date(timestamp);
    const diffMinutes = Math.floor(
      (now.getTime() - orderTime.getTime()) / (1000 * 60),
    );

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes === 1) return "1 min ago";
    return `${diffMinutes} min ago`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "preparing":
        return "bg-blue-100 text-blue-800";
      case "ready":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    return priority === "urgent" ? "border-l-red-500" : "border-l-gray-300";
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ChefHat className="h-8 w-8 text-blucrumbs-blue-500" />
            Live Orders
          </h1>
          <p className="text-gray-600 mt-1">
            Real-time kitchen order management by station
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-yellow-500 text-white hover:bg-yellow-600"
            onClick={() => {
              const testOrder = {
                id: `TEST-${Date.now()}`,
                orderType: "dinein" as const,
                tableNumber: "T99",
                customerName: "Test Customer",
                items: [
                  {
                    id: "test1",
                    name: "Test Item",
                    price: 10,
                    quantity: 1,
                    amount: 10,
                  },
                ],
                netTotal: 10,
                discount: 0,
                additionalDiscount: 0,
                taxableAmount: 10,
                vatAmount: 1.5,
                grandTotal: 11.5,
                timestamp: new Date().toISOString(),
                status: "parked" as const,
                priority: "normal" as const,
                notes: "Test order",
                version: 1,
              };
              addParkedOrder(testOrder);
            }}
          >
            Add Test Order
          </Button>
          <Badge variant="outline" className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            Live
          </Badge>
        </div>
      </div>

      {/* Station Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Station Filter
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Select value={selectedStation} onValueChange={handleStationChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select station" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stations</SelectItem>
                {mockStations.map((station) => (
                  <SelectItem key={station.id} value={station.id}>
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-3 h-3 rounded-full ${station.color}`}
                      ></div>
                      {station.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Station Legend */}
            <div className="flex items-center gap-4 ml-6">
              {mockStations.map((station) => (
                <div key={station.id} className="flex items-center gap-2">
                  <div
                    className={`w-3 h-3 rounded-full ${station.color}`}
                  ></div>
                  <span className="text-sm text-gray-600">{station.name}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Debug Section */}
      <Card className="mb-4 bg-yellow-50 border-yellow-200">
        <CardHeader>
          <CardTitle className="text-yellow-800">
            Debug: Parked Orders ({parkedOrders.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-yellow-700">
            {parkedOrders.length === 0 ? (
              <p>No parked orders found in context</p>
            ) : (
              <div>
                {parkedOrders.map((order) => (
                  <div key={order.id} className="mb-2 p-2 bg-white rounded">
                    <strong>{order.id}</strong> - Status: {order.status} -
                    Items: {order.items.length}
                    {order.tableNumber && ` - Table: ${order.tableNumber}`}
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Parked Orders Section - Always visible when parked orders exist */}
      {parkedOrders.filter(
        (order) => order.status !== "paid" && order.status !== "in-kitchen", // Show parked orders except paid and in-kitchen ones
      ).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Car className="h-5 w-5 text-orange-500" />
              Parked Orders
              <Badge variant="outline" className="ml-2">
                {
                  parkedOrders.filter(
                    (order) =>
                      order.status !== "paid" && order.status !== "in-kitchen",
                  ).length
                }
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {parkedOrders
                .filter(
                  (order) =>
                    order.status !== "paid" && order.status !== "in-kitchen",
                )
                .map((parkedOrder) => (
                  <Card
                    key={`parked-${parkedOrder.id}`}
                    className="border-l-4 border-l-orange-500"
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">
                            {parkedOrder.id}
                          </h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              {parkedOrder.orderType === "dinein" ? (
                                <>
                                  <Users className="h-3 w-3 mr-1" />
                                  Dine In
                                </>
                              ) : (
                                <>
                                  <Package className="h-3 w-3 mr-1" />
                                  Take Away
                                </>
                              )}
                            </Badge>
                            <Badge
                              className={
                                parkedOrder.status === "parked"
                                  ? "bg-orange-100 text-orange-800"
                                  : parkedOrder.status === "in-kitchen"
                                    ? "bg-blue-100 text-blue-800"
                                    : "bg-green-100 text-green-800"
                              }
                            >
                              {parkedOrder.status === "parked"
                                ? "Parked"
                                : parkedOrder.status === "in-kitchen"
                                  ? "In Kitchen"
                                  : "Ready"}
                            </Badge>
                            {/* Version indicator */}
                            {(parkedOrder.version || 1) > 1 && (
                              <Badge
                                variant="outline"
                                className="bg-purple-50 text-purple-700 border-purple-200"
                              >
                                v{parkedOrder.version}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-right text-sm text-gray-500">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {getTimeSince(parkedOrder.timestamp)}
                            </div>
                            {parkedOrder.tableNumber && (
                              <div className="mt-1 font-medium text-gray-700">
                                {parkedOrder.tableNumber}
                              </div>
                            )}
                            {parkedOrder.customerName && (
                              <div className="mt-1 font-medium text-gray-700">
                                {parkedOrder.customerName}
                              </div>
                            )}
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => {
                                  setEditingParkedOrder(parkedOrder);
                                  setShowEditModal(true);
                                }}
                                disabled={parkedOrder.status === "paid"}
                                className={
                                  parkedOrder.status === "paid"
                                    ? "opacity-50 cursor-not-allowed"
                                    : ""
                                }
                              >
                                <Edit className="h-4 w-4 mr-2" />
                                {parkedOrder.status === "paid"
                                  ? "Order Paid"
                                  : "Load"}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="text-sm">
                        <strong>Items ({parkedOrder.items.length}):</strong>
                      </div>
                      {parkedOrder.items.slice(0, 3).map((item) => (
                        <div
                          key={`${parkedOrder.id}-${item.id}`}
                          className={`flex justify-between text-sm p-1 rounded ${
                            item.isCompleted
                              ? "bg-green-50 border border-green-200"
                              : ""
                          }`}
                        >
                          <span className="flex items-center gap-2">
                            <span
                              className={
                                item.isCompleted
                                  ? "line-through text-green-700"
                                  : ""
                              }
                            >
                              {item.name} x{item.quantity}
                            </span>
                            {item.isCompleted && (
                              <Badge className="text-xs bg-green-100 text-green-800">
                                ✓
                              </Badge>
                            )}
                            {(item.addedInVersion || 1) > 1 && !item.isNew && (
                              <Badge
                                variant="outline"
                                className="text-xs bg-gray-100 text-gray-600"
                              >
                                v{item.addedInVersion}
                              </Badge>
                            )}
                          </span>
                          <span
                            className={
                              item.isCompleted
                                ? "line-through text-green-700"
                                : ""
                            }
                          >
                            SAR {item.amount.toFixed(2)}
                          </span>
                        </div>
                      ))}
                      {parkedOrder.items.length > 3 && (
                        <div className="text-xs text-gray-500">
                          +{parkedOrder.items.length - 3} more items
                        </div>
                      )}
                      <div className="border-t pt-2 mt-2 space-y-1">
                        {/* Item Completion Progress */}
                        <div className="text-xs text-gray-600">
                          Items:{" "}
                          {
                            parkedOrder.items.filter((item) => item.isCompleted)
                              .length
                          }{" "}
                          / {parkedOrder.items.length} completed
                          <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                            <div
                              className="bg-green-500 h-1 rounded-full transition-all"
                              style={{
                                width: `${(parkedOrder.items.filter((item) => item.isCompleted).length / parkedOrder.items.length) * 100}%`,
                              }}
                            ></div>
                          </div>
                        </div>
                        <div className="flex justify-between font-medium text-sm">
                          <span>Total:</span>
                          <span>SAR {parkedOrder.grandTotal.toFixed(2)}</span>
                        </div>
                      </div>
                      {parkedOrder.notes && (
                        <div className="text-xs text-gray-600 bg-yellow-50 p-2 rounded">
                          📝 {parkedOrder.notes}
                        </div>
                      )}
                      {parkedOrder.lastEditedAt && (
                        <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                          ✏️ Order edited • Station:{" "}
                          {parkedOrder.recommendedStation || "TBD"}
                        </div>
                      )}

                      {/* Version history */}
                      {(parkedOrder.version || 1) > 1 && (
                        <div className="text-xs bg-purple-50 border border-purple-200 p-2 rounded">
                          <div className="font-semibold text-purple-800 mb-1">
                            Order History (v{parkedOrder.version})
                          </div>
                          <div className="space-y-1">
                            {parkedOrder.originalItems && (
                              <div className="text-purple-700">
                                Original: {parkedOrder.originalItems.length}{" "}
                                items
                              </div>
                            )}
                            <div className="text-purple-700">
                              Current: {parkedOrder.items.length} items
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                    <div className="p-4 border-t space-y-2">
                      {/* Only show status indicators - no action buttons since orders are automatically routed */}
                      {parkedOrder.status === "parked" ? (
                        <div className="w-full bg-orange-100 text-orange-800 px-4 py-2 rounded-lg text-center text-sm font-medium">
                          <ChefHat className="h-4 w-4 mr-2 inline" />
                          Order Created (Auto-routing to Kitchen)
                        </div>
                      ) : parkedOrder.status === "in-kitchen" ? (
                        <div className="space-y-2">
                          <div className="w-full bg-blue-100 text-blue-800 px-4 py-2 rounded-lg text-center text-sm font-medium">
                            <ChefHat className="h-4 w-4 mr-2 inline" />
                            In Kitchen -{" "}
                            {parkedOrder.recommendedStation || "Processing"}
                          </div>
                          {/* New items automatically appear in assigned stations */}
                        </div>
                      ) : (
                        <div className="w-full bg-green-100 text-green-800 px-4 py-2 rounded-lg text-center text-sm font-medium">
                          <CheckCircle className="h-4 w-4 mr-2 inline" />
                          Ready for Pickup
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Edit Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Order</DialogTitle>
          </DialogHeader>
          {editingParkedOrder && (
            <ParkedOrderEdit
              parkedOrder={editingParkedOrder}
              isOpen={showEditModal}
              onClose={() => {
                setShowEditModal(false);
                setEditingParkedOrder(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Orders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOrders.map((order) => (
          <Card
            key={`live-${order.id}`}
            className={`border-l-4 ${getPriorityColor(order.priority)} hover:shadow-lg transition-shadow`}
          >
            {/* Header */}
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg">{order.id}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-xs">
                      {order.orderType === "dine-in" ? (
                        <>
                          <Users className="h-3 w-3 mr-1" />
                          Dine In
                        </>
                      ) : (
                        <>
                          <Package className="h-3 w-3 mr-1" />
                          Take Away
                        </>
                      )}
                    </Badge>
                    <Badge className={getStatusColor(order.status)}>
                      {order.status}
                    </Badge>
                    {order.priority === "urgent" && (
                      <Badge className="bg-red-100 text-red-800">URGENT</Badge>
                    )}
                  </div>

                  {/* Workflow Progress */}
                  <div className="mt-2">
                    <div className="text-xs text-gray-500 mb-1">
                      Station Progress: {order.currentStationIndex + 1} of{" "}
                      {order.workflow.length}
                    </div>
                    <div className="flex items-center gap-1">
                      {order.workflow.map((stationId, index) => {
                        const station = mockStations.find(
                          (s) => s.id === stationId,
                        );
                        const isCompleted = index < order.currentStationIndex;
                        const isCurrent = index === order.currentStationIndex;
                        const isUpcoming = index > order.currentStationIndex;

                        return (
                          <div
                            key={`${order.id}-workflow-${stationId}-${index}`}
                            className="flex items-center"
                          >
                            <div
                              className={`w-3 h-3 rounded-full ${
                                isCompleted
                                  ? "bg-green-500"
                                  : isCurrent
                                    ? station?.color || "bg-gray-400"
                                    : "bg-gray-200"
                              }`}
                              title={station?.name}
                            />
                            {index < order.workflow.length - 1 && (
                              <div
                                className={`w-2 h-0.5 ${
                                  isCompleted ? "bg-green-500" : "bg-gray-200"
                                }`}
                              />
                            )}
                          </div>
                        );
                      })}
                      <span className="ml-2 text-xs text-gray-500">
                        {order.currentStationIndex + 1 === order.workflow.length
                          ? "Final Station"
                          : `Next: ${mockStations.find((s) => s.id === order.workflow[order.currentStationIndex + 1])?.name || "Pickup"}`}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right text-sm text-gray-500">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {getTimeSince(order.timestamp)}
                  </div>
                  {order.tableNumber && (
                    <div className="mt-1 font-medium text-gray-700">
                      {order.tableNumber}
                    </div>
                  )}
                  {order.customerName && (
                    <div className="mt-1 font-medium text-gray-700">
                      {order.customerName}
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>

            {/* Body - Menu Items */}
            <CardContent className="space-y-3">
              {order.items.map((item) => {
                const parkedItem = item as any; // Cast to access ParkedOrderItem properties
                const isCompleted = parkedItem.isCompleted || false;

                return (
                  <div
                    key={`${order.id}-${item.id}`}
                    className={`p-3 rounded-lg transition-all ${isCompleted ? "bg-green-50 border border-green-200" : "bg-gray-50"}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-medium ${isCompleted ? "line-through text-green-700" : ""}`}
                          >
                            {item.name}
                          </span>
                          <span className="text-sm text-gray-500">
                            x{item.quantity}
                          </span>
                          {/* Show completion status */}
                          {isCompleted && (
                            <Badge className="text-xs bg-green-100 text-green-800">
                              ✓ COMPLETED
                            </Badge>
                          )}
                          {/* Show version indicator for parked order items */}
                          {(order.id.startsWith("PKD-") ||
                            order.id.startsWith("ORD-")) &&
                            (item as any).addedInVersion &&
                            (item as any).addedInVersion > 1 && (
                              <Badge
                                variant="outline"
                                className="text-xs bg-purple-50 text-purple-700"
                              >
                                v{(item as any).addedInVersion}
                              </Badge>
                            )}
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="p-1 h-auto"
                                onClick={() => setSelectedIngredients(item)}
                              >
                                <Eye className="h-3 w-3" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>
                                  {item.name} - Ingredients
                                </DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <h4 className="font-medium text-sm text-gray-700 mb-2">
                                    Ingredients:
                                  </h4>
                                  <div className="flex flex-wrap gap-2">
                                    {item.ingredients.map(
                                      (ingredient, index) => (
                                        <Badge
                                          key={`${order.id}-${item.id}-ingredient-${index}`}
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          {ingredient}
                                        </Badge>
                                      ),
                                    )}
                                  </div>
                                </div>
                                {item.specialInstructions && (
                                  <div>
                                    <h4 className="font-medium text-sm text-gray-700 mb-1">
                                      Special Instructions:
                                    </h4>
                                    <p className="text-sm text-gray-600 bg-yellow-50 p-2 rounded">
                                      {item.specialInstructions}
                                    </p>
                                  </div>
                                )}
                                <div>
                                  <h4 className="font-medium text-sm text-gray-700 mb-1">
                                    Estimated Time:
                                  </h4>
                                  <p className="text-sm text-gray-600">
                                    {item.estimatedTime} minutes
                                  </p>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                        {item.specialInstructions && (
                          <p className="text-xs text-orange-600 mt-1">
                            ⚠️ {item.specialInstructions}
                          </p>
                        )}
                        <div className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                          <Clock className="h-3 w-3" />~{item.estimatedTime} min
                          {isCompleted && parkedItem.completedAt && (
                            <span className="text-green-600 ml-2">
                              • Completed at{" "}
                              {new Date(
                                parkedItem.completedAt,
                              ).toLocaleTimeString()}
                            </span>
                          )}
                        </div>
                      </div>
                      {/* Mark Complete Button for incomplete items at this station */}
                      {(order.id.startsWith("PKD-") ||
                        order.id.startsWith("ORD-")) &&
                        !isCompleted && (
                          <Button
                            size="sm"
                            onClick={() => markItemCompleted(order.id, item.id)}
                            className="ml-2 bg-green-500 hover:bg-green-600 text-white text-xs py-1 px-2"
                          >
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Complete
                          </Button>
                        )}
                    </div>
                  </div>
                );
              })}
            </CardContent>

            {/* Footer - Station Progress and Actions */}
            <div className="p-4 border-t">
              {/* Item Completion Progress for Parked Orders */}
              {(order.id.startsWith("PKD-") || order.id.startsWith("ORD-")) && (
                <div className="mb-3 p-2 bg-blue-50 rounded-lg">
                  <div className="text-xs text-blue-700 mb-1 font-medium">
                    Item Progress:{" "}
                    {order.items.filter((item: any) => item.isCompleted).length}{" "}
                    / {order.items.length} completed
                  </div>
                  <div className="w-full bg-blue-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all"
                      style={{
                        width: `${(order.items.filter((item: any) => item.isCompleted).length / order.items.length) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              )}

              {order.status === "ready" ? (
                <Button
                  className="w-full bg-green-500 hover:bg-green-600"
                  disabled
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Ready for Pickup
                </Button>
              ) : (
                <Button
                  className="w-full bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                  onClick={() => handleMarkReady(order.id)}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  {order.currentStationIndex + 1 >= order.workflow.length
                    ? "Mark Ready for Pickup"
                    : `Send to ${mockStations.find((s) => s.id === order.workflow[order.currentStationIndex + 1])?.name || "Next Station"}`}
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {filteredOrders.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <ChefHat className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No Orders for{" "}
              {selectedStation === "all"
                ? "All Stations"
                : mockStations.find((s) => s.id === selectedStation)?.name}
            </h3>
            <p className="text-gray-500">
              Orders will appear here as they are assigned to this station.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
