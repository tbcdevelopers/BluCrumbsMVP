import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  InternalReceivingLineItem,
  mockInventoryItemsWithExpiry,
  ReceivingSubAllocation,
} from "@shared/inventory";
import {
  ArrowLeftRight,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  X,
  Package,
  FileText,
  Copy,
  Calendar,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Storage {
  id: string;
  name: string;
  code: string;
  branchId: string;
}

interface GoodsReceivingItem extends InternalReceivingLineItem {}

interface GoodsReceiving {
  id: string;
  purchaseOrderNumber: string;
  transferNumber: string;
  transferDate: string;
  fromBranch: string;
  toBranch: string;
  toStorage?: string;
  orderDate: string;
  items: GoodsReceivingItem[];
  remarks?: string;
  totalQuantity: number;
  totalReceived: number;
  totalShort: number;
  totalExcess: number;
  status: "pending" | "completed" | "cancelled";
  receivedBy: string;
}

const mockStorages: Storage[] = [
  { id: "ST001", name: "Main Storage", code: "MAIN", branchId: "Main Kitchen" },
  { id: "ST002", name: "Cold Storage", code: "COLD", branchId: "Main Kitchen" },
  { id: "ST003", name: "Dry Storage", code: "DRY", branchId: "Main Kitchen" },
  {
    id: "ST004",
    name: "Central Storage A",
    code: "CSA",
    branchId: "Central Store",
  },
  {
    id: "ST005",
    name: "Central Storage B",
    code: "CSB",
    branchId: "Central Store",
  },
  {
    id: "ST006",
    name: "Branch A - Main Storage",
    code: "BRA-MAIN",
    branchId: "Branch A",
  },
  {
    id: "ST007",
    name: "Branch A - Cold Storage",
    code: "BRA-COLD",
    branchId: "Branch A",
  },
  {
    id: "ST008",
    name: "Branch B - Main Storage",
    code: "BRB-MAIN",
    branchId: "Branch B",
  },
  {
    id: "ST009",
    name: "Branch B - Freezer",
    code: "BRB-FREEZE",
    branchId: "Branch B",
  },
];

const mockReceivings: GoodsReceiving[] = [
  {
    id: "REC001",
    purchaseOrderNumber: "PO001",
    transferNumber: "TRF001",
    transferDate: "2024-01-15",
    fromBranch: "Main Kitchen",
    toBranch: "Branch A",
    orderDate: "2024-01-14",
    status: "completed",
    items: [
      {
        id: "1",
        code: "CHK001",
        description: "Chicken Breast",
        quantityAvailable: 50,
        quantityAllocated: 10,
        transferQuantity: 15,
        quantityReceived: 15,
        quantityShort: 0,
        quantityExcess: 0,
        unit: "kg",
        hasExpiry: true,
        subAllocations: [
          {
            id: "sub1",
            quantity: 8,
            expiryDate: "2024-02-10",
            lotNumber: "CHK001-LOT-A",
          },
          {
            id: "sub2",
            quantity: 7,
            expiryDate: "2024-02-15",
            lotNumber: "CHK001-LOT-B",
          },
        ],
      },
      {
        id: "2",
        code: "RIC001",
        description: "Basmati Rice",
        quantityAvailable: 100,
        quantityAllocated: 20,
        transferQuantity: 25,
        quantityReceived: 23,
        quantityShort: 2,
        quantityExcess: 0,
        unit: "kg",
        hasExpiry: false,
      },
    ],
    remarks: "Partial shortage in rice delivery",
    totalQuantity: 40,
    totalReceived: 38,
    totalShort: 2,
    totalExcess: 0,
    receivedBy: "Mike Johnson",
  },
  {
    id: "REC002",
    purchaseOrderNumber: "PO002",
    transferNumber: "TRF002",
    transferDate: "2024-01-16",
    fromBranch: "Central Store",
    toBranch: "Branch B",
    orderDate: "2024-01-15",
    status: "pending",
    items: [
      {
        id: "3",
        code: "TOM001",
        description: "Fresh Tomatoes",
        quantityAvailable: 30,
        quantityAllocated: 5,
        transferQuantity: 10,
        quantityReceived: 0,
        quantityShort: 0,
        quantityExcess: 0,
        unit: "kg",
        hasExpiry: true,
        subAllocations: [],
      },
    ],
    remarks: "Awaiting delivery",
    totalQuantity: 10,
    totalReceived: 0,
    totalShort: 0,
    totalExcess: 0,
    receivedBy: "Lisa Wilson",
  },
];

// Using shared inventory items with expiry support
const mockInventoryForTransfers = mockInventoryItemsWithExpiry.map((item) => ({
  code: item.code,
  description: item.description,
  available: 50, // Mock available quantity
  allocated: 10, // Mock allocated quantity
  unit: item.unit,
  hasExpiry: item.hasExpiry,
}));

export default function GoodsReceiving() {
  const [receivings] = useState<GoodsReceiving[]>(mockReceivings);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemSearchTerm, setItemSearchTerm] = useState("");
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());
  const [formData, setFormData] = useState<Partial<GoodsReceiving>>({
    items: [],
    status: "pending",
    transferDate: new Date().toISOString().split("T")[0],
    orderDate: new Date().toISOString().split("T")[0],
    totalQuantity: 0,
    totalReceived: 0,
    totalShort: 0,
    totalExcess: 0,
  });

  // Helper function to get storages by branch
  const getStoragesByBranch = (branchId: string): Storage[] => {
    return mockStorages.filter((storage) => storage.branchId === branchId);
  };

  const handleInputChange = (field: keyof GoodsReceiving, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleItemExpansion = (itemId: string) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(itemId)) {
      newExpanded.delete(itemId);
    } else {
      newExpanded.add(itemId);
    }
    setExpandedItems(newExpanded);
  };

  const addSubAllocation = (itemId: string) => {
    const item = formData.items?.find((i) => i.id === itemId);
    if (!item || !item.hasExpiry) return;

    const totalAllocated =
      item.subAllocations?.reduce((sum, sub) => sum + sub.quantity, 0) || 0;
    const remaining = item.transferQuantity - totalAllocated;

    if (remaining <= 0) {
      alert("No remaining quantity to allocate");
      return;
    }

    const newSubAllocation: ReceivingSubAllocation = {
      id: `sub-${Date.now()}`,
      quantity: Math.min(remaining, 1), // Default to 1 or remaining quantity
      expiryDate: "",
      lotNumber: "",
    };

    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations: [...(i.subAllocations || []), newSubAllocation],
              }
            : i,
        ) || [],
    }));

    // Auto-expand the item
    setExpandedItems((prev) => new Set(prev).add(itemId));
  };

  const removeSubAllocation = (itemId: string, subId: string) => {
    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations:
                  i.subAllocations?.filter((sub) => sub.id !== subId) || [],
              }
            : i,
        ) || [],
    }));
    updateQuantityReceived(itemId);
  };

  const updateSubAllocation = (
    itemId: string,
    subId: string,
    field: keyof ReceivingSubAllocation,
    value: any,
  ) => {
    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations:
                  i.subAllocations?.map((sub) =>
                    sub.id === subId ? { ...sub, [field]: value } : sub,
                  ) || [],
              }
            : i,
        ) || [],
    }));

    if (field === "quantity") {
      updateQuantityReceived(itemId);
    }
  };

  const updateQuantityReceived = (itemId: string) => {
    setFormData((prev) => {
      const updatedItems =
        prev.items?.map((item) => {
          if (item.id === itemId) {
            const totalSubAllocation =
              item.subAllocations?.reduce(
                (sum, sub) => sum + sub.quantity,
                0,
              ) || 0;
            const updatedItem = {
              ...item,
              quantityReceived: totalSubAllocation,
            };

            // Auto-calculate short and excess
            if (totalSubAllocation < item.transferQuantity) {
              updatedItem.quantityShort =
                item.transferQuantity - totalSubAllocation;
              updatedItem.quantityExcess = 0;
            } else if (totalSubAllocation > item.transferQuantity) {
              updatedItem.quantityShort = 0;
              updatedItem.quantityExcess =
                totalSubAllocation - item.transferQuantity;
            } else {
              updatedItem.quantityShort = 0;
              updatedItem.quantityExcess = 0;
            }

            return updatedItem;
          }
          return item;
        }) || [];

      const totals = calculateTotals(updatedItems);
      return {
        ...prev,
        items: updatedItems,
        ...totals,
      };
    });
  };

  const copyExpiryToAll = (itemId: string, expiryDate: string) => {
    setFormData((prev) => ({
      ...prev,
      items:
        prev.items?.map((i) =>
          i.id === itemId
            ? {
                ...i,
                subAllocations:
                  i.subAllocations?.map((sub) => ({
                    ...sub,
                    expiryDate,
                  })) || [],
              }
            : i,
        ) || [],
    }));
  };

  const isNearExpiry = (expiryDate: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const today = new Date();
    const diffTime = expiry.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7 && diffDays >= 0; // Within 7 days
  };

  const getRemainingQuantity = (item: GoodsReceivingItem) => {
    const totalAllocated =
      item.subAllocations?.reduce((sum, sub) => sum + sub.quantity, 0) || 0;
    return item.transferQuantity - totalAllocated;
  };

  const handleAddItem = (
    inventoryItem: (typeof mockInventoryForTransfers)[0],
  ) => {
    const existingItem = formData.items?.find(
      (item) => item.code === inventoryItem.code,
    );
    if (existingItem) {
      alert("Item already added to the receiving list");
      return;
    }

    const newItem: GoodsReceivingItem = {
      id: `${Date.now()}`,
      code: inventoryItem.code,
      description: inventoryItem.description,
      quantityAvailable: inventoryItem.available,
      quantityAllocated: inventoryItem.allocated,
      transferQuantity: 0,
      quantityReceived: 0,
      quantityShort: 0,
      quantityExcess: 0,
      unit: inventoryItem.unit,
      hasExpiry: inventoryItem.hasExpiry,
      subAllocations: inventoryItem.hasExpiry ? [] : undefined,
      expiryDate: inventoryItem.hasExpiry ? "" : undefined,
      lotNumber: inventoryItem.hasExpiry ? "" : undefined,
    };

    setFormData((prev) => ({
      ...prev,
      items: [...(prev.items || []), newItem],
    }));
    setItemSearchTerm("");
  };

  const handleRemoveItem = (itemId: string) => {
    setFormData((prev) => {
      const updatedItems =
        prev.items?.filter((item) => item.id !== itemId) || [];
      const totals = calculateTotals(updatedItems);
      return {
        ...prev,
        items: updatedItems,
        ...totals,
      };
    });
  };

  const calculateTotals = (items: GoodsReceivingItem[]) => {
    const totalQuantity = items.reduce(
      (sum, item) => sum + item.transferQuantity,
      0,
    );
    const totalReceived = items.reduce(
      (sum, item) => sum + item.quantityReceived,
      0,
    );
    const totalShort = items.reduce((sum, item) => sum + item.quantityShort, 0);
    const totalExcess = items.reduce(
      (sum, item) => sum + item.quantityExcess,
      0,
    );
    return { totalQuantity, totalReceived, totalShort, totalExcess };
  };

  const handleQuantityChange = (
    itemId: string,
    field: string,
    value: number,
  ) => {
    setFormData((prev) => {
      const updatedItems =
        prev.items?.map((item) => {
          if (item.id === itemId) {
            const updatedItem = { ...item, [field]: value };

            // Auto-calculate short and excess when received quantity changes
            if (field === "quantityReceived" || field === "transferQuantity") {
              const received =
                field === "quantityReceived"
                  ? value
                  : updatedItem.quantityReceived;
              const transfer =
                field === "transferQuantity"
                  ? value
                  : updatedItem.transferQuantity;

              if (received < transfer) {
                updatedItem.quantityShort = transfer - received;
                updatedItem.quantityExcess = 0;
              } else if (received > transfer) {
                updatedItem.quantityShort = 0;
                updatedItem.quantityExcess = received - transfer;
              } else {
                updatedItem.quantityShort = 0;
                updatedItem.quantityExcess = 0;
              }
            }

            return updatedItem;
          }
          return item;
        }) || [];

      const totals = calculateTotals(updatedItems);
      return {
        ...prev,
        items: updatedItems,
        ...totals,
      };
    });
  };

  const resetForm = () => {
    setFormData({
      items: [],
      status: "pending",
      transferDate: new Date().toISOString().split("T")[0],
      orderDate: new Date().toISOString().split("T")[0],
      totalQuantity: 0,
      totalReceived: 0,
      totalShort: 0,
      totalExcess: 0,
      toStorage: "",
    });
    setItemSearchTerm("");
    setExpandedItems(new Set());
  };

  const filteredReceivings = receivings.filter(
    (receiving) =>
      receiving.transferNumber
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      receiving.purchaseOrderNumber
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      receiving.fromBranch.toLowerCase().includes(searchTerm.toLowerCase()) ||
      receiving.toBranch.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredInventoryItems = mockInventoryForTransfers.filter(
    (item) =>
      item.code.toLowerCase().includes(itemSearchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(itemSearchTerm.toLowerCase()),
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ArrowLeftRight className="h-8 w-8 text-blucrumbs-blue-500" />
            Receive Internal Goods
          </h1>
          <p className="text-gray-600 mt-1">
            Manage internal goods receiving and track quantities with
            sub-allocations
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Receiving
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Goods Receiving</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="purchaseOrderNumber">PO Number *</Label>
                  <Select
                    value={formData.purchaseOrderNumber || ""}
                    onValueChange={(value) =>
                      handleInputChange("purchaseOrderNumber", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select purchase order" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PO001">PO001</SelectItem>
                      <SelectItem value="PO002">PO002</SelectItem>
                      <SelectItem value="PO003">PO003</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="transferNumber">Transfer Number</Label>
                  <Input
                    id="transferNumber"
                    value={`TRF${String(receivings.length + 1).padStart(3, "0")}`}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="transferDate">Transfer Date</Label>
                  <Input
                    id="transferDate"
                    value={formData.transferDate || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="fromBranch">From Branch *</Label>
                  <Select
                    value={formData.fromBranch || ""}
                    onValueChange={(value) =>
                      handleInputChange("fromBranch", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select from branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Main Kitchen">Main Kitchen</SelectItem>
                      <SelectItem value="Central Store">
                        Central Store
                      </SelectItem>
                      <SelectItem value="Branch A">Branch A</SelectItem>
                      <SelectItem value="Branch B">Branch B</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toBranch">To Branch *</Label>
                  <Select
                    value={formData.toBranch || ""}
                    onValueChange={(value) => {
                      handleInputChange("toBranch", value);
                      handleInputChange("toStorage", ""); // Clear storage when branch changes
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select to branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Main Kitchen">Main Kitchen</SelectItem>
                      <SelectItem value="Central Store">
                        Central Store
                      </SelectItem>
                      <SelectItem value="Branch A">Branch A</SelectItem>
                      <SelectItem value="Branch B">Branch B</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toStorage">To Branch Storage *</Label>
                  <Select
                    value={formData.toStorage || ""}
                    onValueChange={(value) =>
                      handleInputChange("toStorage", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select to storage" />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.toBranch ? (
                        getStoragesByBranch(formData.toBranch).map(
                          (storage) => (
                            <SelectItem key={storage.id} value={storage.id}>
                              {storage.name} ({storage.code})
                            </SelectItem>
                          ),
                        )
                      ) : (
                        <SelectItem value="no-branch-selected" disabled>
                          Please select to branch first
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">
                    Select the storage location in{" "}
                    {formData.toBranch || "the to branch"} for goods receiving
                  </p>
                </div>
                <div>
                  <Label htmlFor="orderDate">Order Date</Label>
                  <Input
                    id="orderDate"
                    value={formData.orderDate || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
              </div>

              {/* Item Search */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Items</h3>
                <div>
                  <Label htmlFor="itemSearch">Item Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="itemSearch"
                      placeholder="Search items by code or description..."
                      value={itemSearchTerm}
                      onChange={(e) => setItemSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  {/* Search Results */}
                  {itemSearchTerm && filteredInventoryItems.length > 0 && (
                    <Card className="mt-2">
                      <CardContent className="p-2">
                        <div className="max-h-40 overflow-y-auto">
                          {filteredInventoryItems.map((item) => (
                            <div
                              key={item.code}
                              className="flex items-center justify-between p-2 hover:bg-gray-50 cursor-pointer rounded"
                              onClick={() => handleAddItem(item)}
                            >
                              <div>
                                <span className="font-medium">{item.code}</span>{" "}
                                - {item.description}
                                <div className="text-sm text-gray-500">
                                  Available: {item.available} {item.unit} |
                                  Allocated: {item.allocated} {item.unit}
                                  {item.hasExpiry && (
                                    <span className="ml-2 text-orange-600 font-medium">
                                      (Has Expiry)
                                    </span>
                                  )}
                                </div>
                              </div>
                              <Button size="sm" variant="outline">
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Items Table */}
                {formData.items && formData.items.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">
                        Receiving Items
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead>Qty Available</TableHead>
                              <TableHead>Qty Allocated</TableHead>
                              <TableHead>Transfer Qty *</TableHead>
                              <TableHead>Qty Received</TableHead>
                              <TableHead>Expiry/Lot Info</TableHead>
                              <TableHead>Qty Short</TableHead>
                              <TableHead>Qty Excess</TableHead>
                              <TableHead>Unit</TableHead>
                              <TableHead>Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {formData.items.map((item) => (
                              <React.Fragment key={item.id}>
                                {/* Main Item Row */}
                                <TableRow
                                  className={
                                    item.hasExpiry &&
                                    item.subAllocations &&
                                    item.subAllocations.length > 0
                                      ? "bg-blue-50"
                                      : ""
                                  }
                                >
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      {item.hasExpiry && (
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          onClick={() =>
                                            toggleItemExpansion(item.id)
                                          }
                                          className="p-1 h-6 w-6"
                                        >
                                          {expandedItems.has(item.id) ? (
                                            <ChevronDown className="h-4 w-4" />
                                          ) : (
                                            <ChevronRight className="h-4 w-4" />
                                          )}
                                        </Button>
                                      )}
                                      <div>
                                        <div className="font-medium">
                                          {item.code}
                                        </div>
                                        <div className="text-sm text-gray-600">
                                          {item.description}
                                        </div>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    {item.quantityAvailable}
                                  </TableCell>
                                  <TableCell>
                                    {item.quantityAllocated}
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      type="number"
                                      min="0"
                                      step="0.1"
                                      value={item.transferQuantity}
                                      onChange={(e) =>
                                        handleQuantityChange(
                                          item.id,
                                          "transferQuantity",
                                          parseFloat(e.target.value) || 0,
                                        )
                                      }
                                      className="w-20"
                                      required
                                    />
                                  </TableCell>
                                  <TableCell>
                                    {item.hasExpiry ? (
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium">
                                          {item.quantityReceived}
                                        </span>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() =>
                                            addSubAllocation(item.id)
                                          }
                                          className="h-6 px-2 text-xs"
                                          disabled={
                                            getRemainingQuantity(item) <= 0
                                          }
                                        >
                                          <Plus className="h-3 w-3 mr-1" />
                                          Sub
                                        </Button>
                                      </div>
                                    ) : (
                                      <Input
                                        type="number"
                                        min="0"
                                        step="0.1"
                                        value={item.quantityReceived}
                                        onChange={(e) =>
                                          handleQuantityChange(
                                            item.id,
                                            "quantityReceived",
                                            parseFloat(e.target.value) || 0,
                                          )
                                        }
                                        className="w-20"
                                        required
                                      />
                                    )}
                                  </TableCell>
                                  <TableCell>
                                    {item.hasExpiry ? (
                                      <div className="text-sm">
                                        {item.subAllocations &&
                                        item.subAllocations.length > 0 ? (
                                          <span className="text-blue-600">
                                            {item.subAllocations.length}{" "}
                                            sub-allocations
                                          </span>
                                        ) : (
                                          <span className="text-gray-400">
                                            No sub-allocations
                                          </span>
                                        )}
                                      </div>
                                    ) : (
                                      <span className="text-gray-400 text-sm">
                                        N/A
                                      </span>
                                    )}
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      value={item.quantityShort}
                                      readOnly
                                      className="w-20 bg-red-50 text-red-700 font-medium"
                                    />
                                  </TableCell>
                                  <TableCell>
                                    <Input
                                      value={item.quantityExcess}
                                      readOnly
                                      className="w-20 bg-green-50 text-green-700 font-medium"
                                    />
                                  </TableCell>
                                  <TableCell>{item.unit}</TableCell>
                                  <TableCell>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleRemoveItem(item.id)}
                                      className="text-red-600 hover:text-red-800"
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </TableCell>
                                </TableRow>

                                {/* Sub-allocation Rows */}
                                {item.hasExpiry &&
                                  expandedItems.has(item.id) && (
                                    <>
                                      {/* Sub-allocation header */}
                                      <TableRow className="bg-gray-50">
                                        <TableCell
                                          colSpan={2}
                                          className="pl-12 text-sm font-medium"
                                        >
                                          Sub-allocations
                                          {item.subAllocations &&
                                            item.subAllocations.length > 0 && (
                                              <span className="ml-2 text-xs text-gray-500">
                                                (Remaining:{" "}
                                                {getRemainingQuantity(item)}{" "}
                                                {item.unit})
                                              </span>
                                            )}
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          Quantity
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          Expiry Date
                                        </TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          <div className="flex items-center gap-2">
                                            Lot Number
                                            {item.subAllocations &&
                                              item.subAllocations.length >
                                                1 && (
                                                <Button
                                                  variant="ghost"
                                                  size="sm"
                                                  onClick={() => {
                                                    const firstExpiry =
                                                      item.subAllocations![0]
                                                        ?.expiryDate;
                                                    if (firstExpiry) {
                                                      copyExpiryToAll(
                                                        item.id,
                                                        firstExpiry,
                                                      );
                                                    }
                                                  }}
                                                  className="h-5 px-1 text-xs"
                                                  title="Copy first expiry date to all"
                                                >
                                                  <Copy className="h-3 w-3" />
                                                </Button>
                                              )}
                                          </div>
                                        </TableCell>
                                        <TableCell colSpan={3}></TableCell>
                                        <TableCell className="text-sm text-gray-600">
                                          Actions
                                        </TableCell>
                                      </TableRow>

                                      {/* Sub-allocation data rows */}
                                      {item.subAllocations?.map(
                                        (subAllocation, index) => (
                                          <TableRow
                                            key={subAllocation.id}
                                            className="bg-gray-25"
                                          >
                                            <TableCell
                                              colSpan={2}
                                              className="pl-16 text-sm"
                                            >
                                              Sub #{index + 1}
                                            </TableCell>
                                            <TableCell>
                                              <Input
                                                type="number"
                                                min="0"
                                                max={
                                                  getRemainingQuantity(item) +
                                                  subAllocation.quantity
                                                }
                                                step="0.1"
                                                value={subAllocation.quantity}
                                                onChange={(e) =>
                                                  updateSubAllocation(
                                                    item.id,
                                                    subAllocation.id,
                                                    "quantity",
                                                    parseFloat(
                                                      e.target.value,
                                                    ) || 0,
                                                  )
                                                }
                                                className="w-20"
                                                required
                                              />
                                            </TableCell>
                                            <TableCell>
                                              <div className="flex items-center gap-1">
                                                <Input
                                                  type="date"
                                                  value={
                                                    subAllocation.expiryDate
                                                  }
                                                  onChange={(e) =>
                                                    updateSubAllocation(
                                                      item.id,
                                                      subAllocation.id,
                                                      "expiryDate",
                                                      e.target.value,
                                                    )
                                                  }
                                                  className={`w-32 ${
                                                    isNearExpiry(
                                                      subAllocation.expiryDate,
                                                    )
                                                      ? "border-orange-500 bg-orange-50"
                                                      : ""
                                                  }`}
                                                  required
                                                />
                                                {isNearExpiry(
                                                  subAllocation.expiryDate,
                                                ) && (
                                                  <AlertTriangle
                                                    className="h-4 w-4 text-orange-500"
                                                    aria-label="Expires within 7 days"
                                                  />
                                                )}
                                              </div>
                                            </TableCell>
                                            <TableCell>
                                              <Input
                                                type="text"
                                                placeholder="Lot #"
                                                value={subAllocation.lotNumber}
                                                onChange={(e) =>
                                                  updateSubAllocation(
                                                    item.id,
                                                    subAllocation.id,
                                                    "lotNumber",
                                                    e.target.value,
                                                  )
                                                }
                                                className="w-24"
                                                required
                                              />
                                            </TableCell>
                                            <TableCell colSpan={3}></TableCell>
                                            <TableCell>
                                              <Button
                                                variant="outline"
                                                size="sm"
                                                onClick={() =>
                                                  removeSubAllocation(
                                                    item.id,
                                                    subAllocation.id,
                                                  )
                                                }
                                                className="text-red-600 hover:text-red-800 h-6 w-6 p-0"
                                              >
                                                <X className="h-3 w-3" />
                                              </Button>
                                            </TableCell>
                                          </TableRow>
                                        ),
                                      )}
                                    </>
                                  )}
                              </React.Fragment>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Summary and Remarks */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="remarks">Remarks</Label>
                  <Textarea
                    id="remarks"
                    value={formData.remarks || ""}
                    onChange={(e) =>
                      handleInputChange("remarks", e.target.value)
                    }
                    placeholder="Enter any remarks about this receiving"
                    rows={4}
                  />
                </div>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="totalQuantity">
                      Total Transfer Quantity
                    </Label>
                    <Input
                      id="totalQuantity"
                      value={formData.totalQuantity || 0}
                      readOnly
                      className="bg-gray-50 font-semibold"
                    />
                  </div>
                  <div>
                    <Label htmlFor="totalReceived">Total Received</Label>
                    <Input
                      id="totalReceived"
                      value={formData.totalReceived || 0}
                      readOnly
                      className="bg-blue-50 text-blue-700 font-semibold"
                    />
                  </div>
                  <div>
                    <Label htmlFor="totalShort">Total Short</Label>
                    <Input
                      id="totalShort"
                      value={formData.totalShort || 0}
                      readOnly
                      className="bg-red-50 text-red-700 font-semibold"
                    />
                  </div>
                  <div>
                    <Label htmlFor="totalExcess">Total Excess</Label>
                    <Input
                      id="totalExcess"
                      value={formData.totalExcess || 0}
                      readOnly
                      className="bg-green-50 text-green-700 font-semibold"
                    />
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  className="bg-blucrumbs-orange-500 hover:bg-blucrumbs-orange-600"
                  onClick={() => {
                    // Handle Save, Print and Post
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Save Print And Post
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by transfer number, purchase order number, branch..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Goods Receiving Table */}
      <Card>
        <CardHeader>
          <CardTitle>Goods Receiving Records</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredReceivings.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Receivings Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No receivings match your search criteria."
                  : "No goods receivings have been created yet."}
              </p>
              {!searchTerm && (
                <Button
                  onClick={() => setIsAddDialogOpen(true)}
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create First Receiving
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Transfer Number</TableHead>
                    <TableHead>PO Number</TableHead>
                    <TableHead>Transfer Date</TableHead>
                    <TableHead>From Branch</TableHead>
                    <TableHead>To Branch</TableHead>
                    <TableHead>Items</TableHead>
                    <TableHead>Total Qty</TableHead>
                    <TableHead>Received</TableHead>
                    <TableHead>Short</TableHead>
                    <TableHead>Excess</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReceivings.map((receiving) => (
                    <TableRow key={receiving.id}>
                      <TableCell className="font-medium">
                        {receiving.transferNumber}
                      </TableCell>
                      <TableCell>{receiving.purchaseOrderNumber}</TableCell>
                      <TableCell>
                        {new Date(receiving.transferDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{receiving.fromBranch}</TableCell>
                      <TableCell>{receiving.toBranch}</TableCell>
                      <TableCell>{receiving.items.length} items</TableCell>
                      <TableCell>{receiving.totalQuantity}</TableCell>
                      <TableCell>
                        <Badge className="bg-blue-100 text-blue-800">
                          {receiving.totalReceived}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            receiving.totalShort > 0
                              ? "bg-red-100 text-red-800"
                              : "bg-gray-100 text-gray-800"
                          }
                        >
                          {receiving.totalShort}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            receiving.totalExcess > 0
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                          }
                        >
                          {receiving.totalExcess}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(receiving.status)}>
                          {receiving.status.charAt(0).toUpperCase() +
                            receiving.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <FileText className="mr-2 h-4 w-4" />
                              Inquiry
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
