import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeftRight,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Trash2,
  X,
  Package,
  FileText,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface GoodsIssuanceItem {
  id: string;
  code: string;
  description: string;
  quantityAvailable: number;
  quantityAllocated: number;
  transferQuantity: number;
  unit: string;
}

interface Storage {
  id: string;
  name: string;
  code: string;
  branchId: string;
}

interface GoodsIssuance {
  id: string;
  requestNumber: string;
  transferNumber: string;
  transferDate: string;
  fromBranch: string;
  toBranch: string;
  fromStorage?: string;
  requestDate: string;
  items: GoodsIssuanceItem[];
  remarks?: string;
  totalQuantity: number;
  status: "pending" | "completed" | "cancelled";
  issuedBy: string;
}

const mockStorages: Storage[] = [
  { id: "ST001", name: "Main Storage", code: "MAIN", branchId: "Main Kitchen" },
  { id: "ST002", name: "Cold Storage", code: "COLD", branchId: "Main Kitchen" },
  { id: "ST003", name: "Dry Storage", code: "DRY", branchId: "Main Kitchen" },
  {
    id: "ST004",
    name: "Central Storage A",
    code: "CSA",
    branchId: "Central Store",
  },
  {
    id: "ST005",
    name: "Central Storage B",
    code: "CSB",
    branchId: "Central Store",
  },
  {
    id: "ST006",
    name: "Branch A - Main Storage",
    code: "BRA-MAIN",
    branchId: "Branch A",
  },
  {
    id: "ST007",
    name: "Branch A - Cold Storage",
    code: "BRA-COLD",
    branchId: "Branch A",
  },
  {
    id: "ST008",
    name: "Branch B - Main Storage",
    code: "BRB-MAIN",
    branchId: "Branch B",
  },
  {
    id: "ST009",
    name: "Branch B - Freezer",
    code: "BRB-FREEZE",
    branchId: "Branch B",
  },
];

const mockIssuances: GoodsIssuance[] = [
  {
    id: "ISS001",
    requestNumber: "REQ001",
    transferNumber: "TRF001",
    transferDate: "2024-01-15",
    fromBranch: "Main Kitchen",
    toBranch: "Branch A",
    requestDate: "2024-01-14",
    status: "completed",
    items: [
      {
        id: "1",
        code: "CHK001",
        description: "Chicken Breast",
        quantityAvailable: 50,
        quantityAllocated: 10,
        transferQuantity: 15,
        unit: "kg",
      },
      {
        id: "2",
        code: "RIC001",
        description: "Basmati Rice",
        quantityAvailable: 100,
        quantityAllocated: 20,
        transferQuantity: 25,
        unit: "kg",
      },
    ],
    remarks: "Regular transfer completed",
    totalQuantity: 40,
    issuedBy: "John Smith",
  },
  {
    id: "ISS002",
    requestNumber: "REQ002",
    transferNumber: "TRF002",
    transferDate: "2024-01-16",
    fromBranch: "Central Store",
    toBranch: "Branch B",
    requestDate: "2024-01-15",
    status: "pending",
    items: [
      {
        id: "3",
        code: "TOM001",
        description: "Fresh Tomatoes",
        quantityAvailable: 30,
        quantityAllocated: 5,
        transferQuantity: 10,
        unit: "kg",
      },
    ],
    remarks: "Pending issuance",
    totalQuantity: 10,
    issuedBy: "Sarah Johnson",
  },
];

const mockInventoryItems = [
  {
    code: "CHK001",
    description: "Chicken Breast",
    available: 50,
    allocated: 10,
    unit: "kg",
  },
  {
    code: "RIC001",
    description: "Basmati Rice",
    available: 100,
    allocated: 20,
    unit: "kg",
  },
  {
    code: "TOM001",
    description: "Fresh Tomatoes",
    available: 30,
    allocated: 5,
    unit: "kg",
  },
  {
    code: "ONI001",
    description: "White Onions",
    available: 40,
    allocated: 8,
    unit: "kg",
  },
  {
    code: "OIL001",
    description: "Cooking Oil",
    available: 25,
    allocated: 3,
    unit: "ltr",
  },
];

export default function GoodsIssuance() {
  const [issuances] = useState<GoodsIssuance[]>(mockIssuances);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemSearchTerm, setItemSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<GoodsIssuance>>({
    items: [],
    status: "pending",
    transferDate: new Date().toISOString().split("T")[0],
    requestDate: new Date().toISOString().split("T")[0],
    totalQuantity: 0,
  });

  // Helper function to get storages by branch
  const getStoragesByBranch = (branchId: string): Storage[] => {
    return mockStorages.filter((storage) => storage.branchId === branchId);
  };

  const handleInputChange = (field: keyof GoodsIssuance, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddItem = (inventoryItem: (typeof mockInventoryItems)[0]) => {
    const existingItem = formData.items?.find(
      (item) => item.code === inventoryItem.code,
    );
    if (existingItem) {
      alert("Item already added to the issuance");
      return;
    }

    const newItem: GoodsIssuanceItem = {
      id: `${Date.now()}`,
      code: inventoryItem.code,
      description: inventoryItem.description,
      quantityAvailable: inventoryItem.available,
      quantityAllocated: inventoryItem.allocated,
      transferQuantity: 0,
      unit: inventoryItem.unit,
    };

    setFormData((prev) => ({
      ...prev,
      items: [...(prev.items || []), newItem],
    }));
    setItemSearchTerm("");
  };

  const handleRemoveItem = (itemId: string) => {
    setFormData((prev) => {
      const updatedItems =
        prev.items?.filter((item) => item.id !== itemId) || [];
      const totalQuantity = updatedItems.reduce(
        (sum, item) => sum + item.transferQuantity,
        0,
      );
      return {
        ...prev,
        items: updatedItems,
        totalQuantity,
      };
    });
  };

  const handleQuantityChange = (itemId: string, quantity: number) => {
    setFormData((prev) => {
      const updatedItems =
        prev.items?.map((item) =>
          item.id === itemId ? { ...item, transferQuantity: quantity } : item,
        ) || [];
      const totalQuantity = updatedItems.reduce(
        (sum, item) => sum + item.transferQuantity,
        0,
      );
      return {
        ...prev,
        items: updatedItems,
        totalQuantity,
      };
    });
  };

  const resetForm = () => {
    setFormData({
      items: [],
      status: "pending",
      transferDate: new Date().toISOString().split("T")[0],
      requestDate: new Date().toISOString().split("T")[0],
      totalQuantity: 0,
      fromStorage: "",
    });
    setItemSearchTerm("");
  };

  const filteredIssuances = issuances.filter(
    (issuance) =>
      issuance.transferNumber
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      issuance.requestNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      issuance.fromBranch.toLowerCase().includes(searchTerm.toLowerCase()) ||
      issuance.toBranch.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const filteredInventoryItems = mockInventoryItems.filter(
    (item) =>
      item.code.toLowerCase().includes(itemSearchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(itemSearchTerm.toLowerCase()),
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ArrowLeftRight className="h-8 w-8 text-blucrumbs-blue-500" />
            Issue Internal Goods
          </h1>
          <p className="text-gray-600 mt-1">
            Manage internal goods issuance and transfers
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Issuance
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Goods Issuance</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Basic Information */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="requestNumber">Request Number *</Label>
                  <Select
                    value={formData.requestNumber || ""}
                    onValueChange={(value) =>
                      handleInputChange("requestNumber", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select request" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="REQ001">REQ001</SelectItem>
                      <SelectItem value="REQ002">REQ002</SelectItem>
                      <SelectItem value="REQ003">REQ003</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="transferNumber">Transfer Number</Label>
                  <Input
                    id="transferNumber"
                    value={`TRF${String(issuances.length + 1).padStart(3, "0")}`}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="transferDate">Transfer Date</Label>
                  <Input
                    id="transferDate"
                    value={formData.transferDate || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="fromBranch">From Branch *</Label>
                  <Select
                    value={formData.fromBranch || ""}
                    onValueChange={(value) => {
                      handleInputChange("fromBranch", value);
                      handleInputChange("fromStorage", ""); // Clear storage when branch changes
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select from branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Main Kitchen">Main Kitchen</SelectItem>
                      <SelectItem value="Central Store">
                        Central Store
                      </SelectItem>
                      <SelectItem value="Branch A">Branch A</SelectItem>
                      <SelectItem value="Branch B">Branch B</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toBranch">To Branch *</Label>
                  <Select
                    value={formData.toBranch || ""}
                    onValueChange={(value) =>
                      handleInputChange("toBranch", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select to branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Main Kitchen">Main Kitchen</SelectItem>
                      <SelectItem value="Central Store">
                        Central Store
                      </SelectItem>
                      <SelectItem value="Branch A">Branch A</SelectItem>
                      <SelectItem value="Branch B">Branch B</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fromStorage">From Branch Storage *</Label>
                  <Select
                    value={formData.fromStorage || ""}
                    onValueChange={(value) =>
                      handleInputChange("fromStorage", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select from storage" />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.fromBranch ? (
                        getStoragesByBranch(formData.fromBranch).map(
                          (storage) => (
                            <SelectItem key={storage.id} value={storage.id}>
                              {storage.name} ({storage.code})
                            </SelectItem>
                          ),
                        )
                      ) : (
                        <SelectItem value="no-branch-selected" disabled>
                          Please select from branch first
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">
                    Select the storage location in{" "}
                    {formData.fromBranch || "the from branch"} for goods
                    issuance
                  </p>
                </div>
                <div>
                  <Label htmlFor="requestDate">Request Date</Label>
                  <Input
                    id="requestDate"
                    value={formData.requestDate || ""}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
              </div>

              {/* Item Search */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Items</h3>
                <div>
                  <Label htmlFor="itemSearch">Item Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      id="itemSearch"
                      placeholder="Search items by code or description..."
                      value={itemSearchTerm}
                      onChange={(e) => setItemSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>

                  {/* Search Results */}
                  {itemSearchTerm && filteredInventoryItems.length > 0 && (
                    <Card className="mt-2">
                      <CardContent className="p-2">
                        <div className="max-h-40 overflow-y-auto">
                          {filteredInventoryItems.map((item) => (
                            <div
                              key={item.code}
                              className="flex items-center justify-between p-2 hover:bg-gray-50 cursor-pointer rounded"
                              onClick={() => handleAddItem(item)}
                            >
                              <div>
                                <span className="font-medium">{item.code}</span>{" "}
                                - {item.description}
                                <div className="text-sm text-gray-500">
                                  Available: {item.available} {item.unit} |
                                  Allocated: {item.allocated} {item.unit}
                                </div>
                              </div>
                              <Button size="sm" variant="outline">
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {/* Items Table */}
                {formData.items && formData.items.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">
                        Issuance Items
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Code</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Qty Available</TableHead>
                            <TableHead>Qty Allocated</TableHead>
                            <TableHead>Transfer Qty *</TableHead>
                            <TableHead>Unit</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formData.items.map((item) => (
                            <TableRow key={item.id}>
                              <TableCell className="font-medium">
                                {item.code}
                              </TableCell>
                              <TableCell>{item.description}</TableCell>
                              <TableCell>{item.quantityAvailable}</TableCell>
                              <TableCell>{item.quantityAllocated}</TableCell>
                              <TableCell>
                                <Input
                                  type="number"
                                  min="0"
                                  step="0.1"
                                  value={item.transferQuantity}
                                  onChange={(e) =>
                                    handleQuantityChange(
                                      item.id,
                                      parseFloat(e.target.value) || 0,
                                    )
                                  }
                                  className="w-24"
                                  required
                                />
                              </TableCell>
                              <TableCell>{item.unit}</TableCell>
                              <TableCell>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleRemoveItem(item.id)}
                                  className="text-red-600 hover:text-red-800"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Remarks and Total */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="remarks">Remarks</Label>
                  <Textarea
                    id="remarks"
                    value={formData.remarks || ""}
                    onChange={(e) =>
                      handleInputChange("remarks", e.target.value)
                    }
                    placeholder="Enter any remarks about this issuance"
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="totalQuantity">Total Quantity</Label>
                  <Input
                    id="totalQuantity"
                    value={formData.totalQuantity || 0}
                    readOnly
                    className="bg-gray-50 text-lg font-semibold"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  className="bg-blubites-orange-500 hover:bg-blubites-orange-600"
                  onClick={() => {
                    // Handle Save, Print and Post
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Save Print And Post
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by ID, branch, or request..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Goods Issuance Table */}
      <Card>
        <CardHeader>
          <CardTitle>Goods Issuance Records</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredIssuances.length === 0 ? (
            <div className="text-center py-12">
              <Package className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Issuances Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No issuances match your search criteria."
                  : "No goods issuances have been created yet."}
              </p>
              {!searchTerm && (
                <Button
                  onClick={() => setIsAddDialogOpen(true)}
                  className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create First Issuance
                </Button>
              )}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transfer Number</TableHead>
                  <TableHead>Request Number</TableHead>
                  <TableHead>Transfer Date</TableHead>
                  <TableHead>From Branch</TableHead>
                  <TableHead>To Branch</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total Qty</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredIssuances.map((issuance) => (
                  <TableRow key={issuance.id}>
                    <TableCell className="font-medium">
                      {issuance.transferNumber}
                    </TableCell>
                    <TableCell>{issuance.requestNumber}</TableCell>
                    <TableCell>
                      {new Date(issuance.transferDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{issuance.fromBranch}</TableCell>
                    <TableCell>{issuance.toBranch}</TableCell>
                    <TableCell>{issuance.items.length} items</TableCell>
                    <TableCell>{issuance.totalQuantity}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(issuance.status)}>
                        {issuance.status.charAt(0).toUpperCase() +
                          issuance.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            Inquiry
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
