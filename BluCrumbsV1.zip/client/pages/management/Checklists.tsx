import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  ClipboardList,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  History,
  Trash2,
  UserPlus,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Task {
  id: string;
  name: string;
}

interface Checklist {
  id: string;
  description: string;
  arabicDescription: string;
  frequency: "Daily" | "Weekly" | "Monthly" | "Quarterly" | "Yearly";
  status: "active" | "inactive";
  tasks: Task[];
}

const mockChecklists: Checklist[] = [
  {
    id: "CHK001",
    description: "Opening Restaurant Checklist",
    arabicDescription: "قائمة مراجعة فتح المطعم",
    frequency: "Daily",
    status: "active",
    tasks: [
      { id: "T1", name: "Check kitchen equipment" },
      { id: "T2", name: "Verify cash register" },
      { id: "T3", name: "Review inventory levels" },
    ],
  },
  {
    id: "CHK002",
    description: "Weekly Cleaning Checklist",
    arabicDescription: "قائمة مراجعة التنظيف الأسبوعي",
    frequency: "Weekly",
    status: "active",
    tasks: [
      { id: "T4", name: "Deep clean kitchen" },
      { id: "T5", name: "Sanitize dining area" },
    ],
  },
];

export default function Checklists() {
  const [checklists] = useState<Checklist[]>(mockChecklists);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<Checklist>>({
    tasks: [],
    status: "active",
  });
  const [newTaskName, setNewTaskName] = useState("");

  const handleInputChange = (field: keyof Checklist, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddTask = () => {
    if (newTaskName.trim()) {
      const newTask: Task = {
        id: `T${Date.now()}`,
        name: newTaskName.trim(),
      };
      setFormData((prev) => ({
        ...prev,
        tasks: [...(prev.tasks || []), newTask],
      }));
      setNewTaskName("");
    }
  };

  const handleRemoveTask = (taskId: string) => {
    setFormData((prev) => ({
      ...prev,
      tasks: prev.tasks?.filter((task) => task.id !== taskId) || [],
    }));
  };

  const resetForm = () => {
    setFormData({
      tasks: [],
      status: "active",
    });
    setNewTaskName("");
  };

  const filteredChecklists = checklists.filter(
    (checklist) =>
      checklist.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      checklist.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      checklist.frequency.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ClipboardList className="h-8 w-8 text-blucrumbs-blue-500" />
            Task Checklists
          </h1>
          <p className="text-gray-600 mt-1">
            Manage operational checklists and tasks
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Checklist
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Checklist</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label htmlFor="checklistId">ID</Label>
                  <Input
                    id="checklistId"
                    value={`CHK${String(checklists.length + 1).padStart(3, "0")}`}
                    readOnly
                    className="bg-gray-50"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Checklist Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                    placeholder="Enter the description of the checklist item in English"
                    rows={3}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="arabicDescription">
                    Arabic Description *
                  </Label>
                  <Textarea
                    id="arabicDescription"
                    value={formData.arabicDescription || ""}
                    onChange={(e) =>
                      handleInputChange("arabicDescription", e.target.value)
                    }
                    placeholder="Enter the description of the checklist item in Arabic"
                    dir="rtl"
                    rows={3}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="frequency">Frequency *</Label>
                  <Select
                    value={formData.frequency || ""}
                    onValueChange={(value) =>
                      handleInputChange("frequency", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Daily">Daily</SelectItem>
                      <SelectItem value="Weekly">Weekly</SelectItem>
                      <SelectItem value="Monthly">Monthly</SelectItem>
                      <SelectItem value="Quarterly">Quarterly</SelectItem>
                      <SelectItem value="Yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Status</Label>
                  <div className="flex items-center space-x-4 mt-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="status"
                        value="active"
                        checked={formData.status === "active"}
                        onChange={(e) =>
                          handleInputChange("status", e.target.value)
                        }
                      />
                      <span className="text-sm">Active</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="status"
                        value="inactive"
                        checked={formData.status === "inactive"}
                        onChange={(e) =>
                          handleInputChange("status", e.target.value)
                        }
                      />
                      <span className="text-sm">Inactive</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* Task Management */}
              <Card>
                <CardHeader>
                  <CardTitle>Tasks</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter a task related to the checklist item"
                      value={newTaskName}
                      onChange={(e) => setNewTaskName(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleAddTask()}
                    />
                    <Button
                      type="button"
                      onClick={handleAddTask}
                      disabled={!newTaskName.trim()}
                    >
                      Add Task
                    </Button>
                  </div>

                  {formData.tasks && formData.tasks.length > 0 && (
                    <div>
                      <Label>Tasks Table</Label>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Task ID</TableHead>
                            <TableHead>Task Name</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formData.tasks.map((task) => (
                            <TableRow key={task.id}>
                              <TableCell className="font-medium">
                                {task.id}
                              </TableCell>
                              <TableCell>{task.name}</TableCell>
                              <TableCell>
                                <div className="flex gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                      setNewTaskName(task.name);
                                      handleRemoveTask(task.id);
                                    }}
                                  >
                                    <Edit className="h-3 w-3" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleRemoveTask(task.id)}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Checklist
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search checklists..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Checklists Table */}
      <Card>
        <CardHeader>
          <CardTitle>Checklists Inquiry</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredChecklists.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Arabic Description</TableHead>
                  <TableHead>Frequency</TableHead>
                  <TableHead>No. of Tasks</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredChecklists.map((checklist) => (
                  <TableRow key={checklist.id}>
                    <TableCell className="font-medium">
                      {checklist.id}
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <div className="truncate" title={checklist.description}>
                        {checklist.description}
                      </div>
                    </TableCell>
                    <TableCell className="max-w-xs" dir="rtl">
                      <div
                        className="truncate"
                        title={checklist.arabicDescription}
                      >
                        {checklist.arabicDescription}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{checklist.frequency}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{checklist.tasks.length}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          checklist.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {checklist.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <History className="h-4 w-4 mr-2" />
                            History
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <UserPlus className="h-4 w-4 mr-2" />
                            Assign
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <ClipboardList className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Checklists Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No checklists match your search criteria."
                  : "Get started by creating your first checklist."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Checklist
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
