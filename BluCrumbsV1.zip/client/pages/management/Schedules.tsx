import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Plus,
  Search,
  Edit,
  Eye,
  MoreHorizontal,
  Clock,
  Trash2,
  Copy,
  Users,
  Building2,
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Shift {
  id: string;
  startTime: string;
  endTime: string;
}

interface DayShift {
  day: string;
  shifts: Shift[];
}

interface Schedule {
  id: string;
  type: "staff" | "team";
  branchId?: string;
  branchName?: string;
  staffId?: string;
  staffName?: string;
  teamId?: string;
  teamName?: string;
  isDaysMode: boolean;
  startDate?: string;
  endDate?: string;
  shifts?: Shift[]; // For date-based schedules
  selectedDays?: string[];
  dayShifts?: DayShift[]; // For day-based schedules with multiple shifts per day
  status: "active" | "inactive";
}

const mockBranches = [
  { id: "BR001", name: "Main Branch - Downtown" },
  { id: "BR002", name: "Branch A - Mall Location" },
  { id: "BR003", name: "Branch B - Airport" },
  { id: "BR004", name: "Central Kitchen" },
];

const mockStaffByBranch: {
  [key: string]: Array<{ id: string; name: string }>;
} = {
  BR001: [
    { id: "EMP001", name: "Ahmed Al-Saud" },
    { id: "EMP002", name: "Sarah Wilson" },
    { id: "EMP003", name: "Mike Johnson" },
    { id: "EMP004", name: "Fatima Khan" },
  ],
  BR002: [
    { id: "EMP005", name: "John Davis" },
    { id: "EMP006", name: "Maria Garcia" },
    { id: "EMP007", name: "Ali Hassan" },
  ],
  BR003: [
    { id: "EMP008", name: "Lisa Chen" },
    { id: "EMP009", name: "Omar Abdullah" },
    { id: "EMP010", name: "Emma Thompson" },
  ],
  BR004: [
    { id: "EMP011", name: "Chef Mohammed" },
    { id: "EMP012", name: "Sous Chef Anna" },
    { id: "EMP013", name: "Prep Cook Sam" },
  ],
};

const mockSchedules: Schedule[] = [
  {
    id: "SCH001",
    type: "staff",
    branchId: "BR001",
    branchName: "Main Branch - Downtown",
    staffId: "EMP001",
    staffName: "Ahmed Al-Saud",
    isDaysMode: false,
    startDate: "2024-01-15",
    endDate: "2024-01-31",
    shifts: [
      { id: "SH1", startTime: "09:00", endTime: "13:00" },
      { id: "SH2", startTime: "18:00", endTime: "22:00" },
    ],
    status: "active",
  },
  {
    id: "SCH002",
    type: "team",
    branchId: "BR002",
    branchName: "Branch A - Mall Location",
    teamId: "KITCHEN",
    teamName: "Kitchen Team",
    isDaysMode: true,
    selectedDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    dayShifts: [
      {
        day: "Monday",
        shifts: [{ id: "SH3", startTime: "08:00", endTime: "16:00" }],
      },
      {
        day: "Tuesday",
        shifts: [
          { id: "SH4", startTime: "06:00", endTime: "14:00" },
          { id: "SH5", startTime: "14:00", endTime: "22:00" },
        ],
      },
      {
        day: "Wednesday",
        shifts: [{ id: "SH6", startTime: "08:00", endTime: "16:00" }],
      },
      {
        day: "Thursday",
        shifts: [{ id: "SH7", startTime: "08:00", endTime: "16:00" }],
      },
      {
        day: "Friday",
        shifts: [{ id: "SH8", startTime: "08:00", endTime: "16:00" }],
      },
    ],
    status: "active",
  },
];

const daysOfWeek = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];

export default function Schedules() {
  const [schedules] = useState<Schedule[]>(mockSchedules);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState<Partial<Schedule>>({
    type: "staff",
    isDaysMode: false,
    selectedDays: [],
    shifts: [{ id: "shift1", startTime: "", endTime: "" }],
    dayShifts: [],
    status: "active",
  });

  const handleInputChange = (field: keyof Schedule, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleBranchSelection = (branchId: string) => {
    const branch = mockBranches.find((b) => b.id === branchId);
    setFormData((prev) => ({
      ...prev,
      branchId,
      branchName: branch?.name,
      staffId: undefined, // Reset staff selection when branch changes
      staffName: undefined,
      teamId: undefined,
      teamName: undefined,
    }));
  };

  const handleStaffSelection = (staffId: string) => {
    const branchStaff = mockStaffByBranch[formData.branchId || ""] || [];
    const staff = branchStaff.find((s) => s.id === staffId);
    setFormData((prev) => ({
      ...prev,
      staffId,
      staffName: staff?.name,
    }));
  };

  const handleTeamSelection = (teamId: string) => {
    const teamNames: { [key: string]: string } = {
      KITCHEN: "Kitchen Team",
      SERVICE: "Service Team",
      MANAGEMENT: "Management Team",
      CLEANING: "Cleaning Team",
    };
    setFormData((prev) => ({
      ...prev,
      teamId,
      teamName: teamNames[teamId],
    }));
  };

  // Handle shifts for date-based schedules
  const addDateShift = () => {
    const newShift: Shift = {
      id: `shift${Date.now()}`,
      startTime: "",
      endTime: "",
    };
    setFormData((prev) => ({
      ...prev,
      shifts: [...(prev.shifts || []), newShift],
    }));
  };

  const removeDateShift = (shiftId: string) => {
    setFormData((prev) => ({
      ...prev,
      shifts: prev.shifts?.filter((shift) => shift.id !== shiftId) || [],
    }));
  };

  const updateDateShift = (
    shiftId: string,
    field: "startTime" | "endTime",
    value: string,
  ) => {
    setFormData((prev) => ({
      ...prev,
      shifts:
        prev.shifts?.map((shift) =>
          shift.id === shiftId ? { ...shift, [field]: value } : shift,
        ) || [],
    }));
  };

  // Handle day selection and day-specific shifts
  const handleDaySelection = (day: string) => {
    const currentDays = formData.selectedDays || [];
    const currentDayShifts = formData.dayShifts || [];

    if (currentDays.includes(day)) {
      // Remove day and its shifts
      setFormData((prev) => ({
        ...prev,
        selectedDays: currentDays.filter((d) => d !== day),
        dayShifts: currentDayShifts.filter((ds) => ds.day !== day),
      }));
    } else {
      // Add day with default shift
      const newDayShift: DayShift = {
        day,
        shifts: [{ id: `${day}_shift1`, startTime: "", endTime: "" }],
      };
      setFormData((prev) => ({
        ...prev,
        selectedDays: [...currentDays, day],
        dayShifts: [...currentDayShifts, newDayShift],
      }));
    }
  };

  const addShiftToDay = (day: string) => {
    const newShift: Shift = {
      id: `${day}_shift${Date.now()}`,
      startTime: "",
      endTime: "",
    };
    setFormData((prev) => ({
      ...prev,
      dayShifts:
        prev.dayShifts?.map((dayShift) =>
          dayShift.day === day
            ? { ...dayShift, shifts: [...dayShift.shifts, newShift] }
            : dayShift,
        ) || [],
    }));
  };

  const removeShiftFromDay = (day: string, shiftId: string) => {
    setFormData((prev) => ({
      ...prev,
      dayShifts:
        prev.dayShifts?.map((dayShift) =>
          dayShift.day === day
            ? {
                ...dayShift,
                shifts: dayShift.shifts.filter((shift) => shift.id !== shiftId),
              }
            : dayShift,
        ) || [],
    }));
  };

  const updateDayShift = (
    day: string,
    shiftId: string,
    field: "startTime" | "endTime",
    value: string,
  ) => {
    setFormData((prev) => ({
      ...prev,
      dayShifts:
        prev.dayShifts?.map((dayShift) =>
          dayShift.day === day
            ? {
                ...dayShift,
                shifts: dayShift.shifts.map((shift) =>
                  shift.id === shiftId ? { ...shift, [field]: value } : shift,
                ),
              }
            : dayShift,
        ) || [],
    }));
  };

  const copyShiftsToAllDays = (sourceDayShifts: Shift[]) => {
    setFormData((prev) => ({
      ...prev,
      dayShifts:
        prev.dayShifts?.map((dayShift) => ({
          ...dayShift,
          shifts: sourceDayShifts.map((shift) => ({
            ...shift,
            id: `${dayShift.day}_${shift.id}_copy`,
          })),
        })) || [],
    }));
  };

  const filteredSchedules = schedules.filter(
    (schedule) =>
      (schedule.staffName &&
        schedule.staffName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (schedule.teamName &&
        schedule.teamName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (schedule.branchName &&
        schedule.branchName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      schedule.id.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  const getAvailableStaff = () => {
    return mockStaffByBranch[formData.branchId || ""] || [];
  };

  const formatScheduleDisplay = (schedule: Schedule) => {
    if (schedule.isDaysMode) {
      if (schedule.dayShifts && schedule.dayShifts.length > 0) {
        return schedule.dayShifts
          .map((dayShift) => {
            const shiftsText = dayShift.shifts
              .map((shift) => `${shift.startTime}-${shift.endTime}`)
              .join(", ");
            return `${dayShift.day}: ${shiftsText}`;
          })
          .join(" | ");
      } else {
        return schedule.selectedDays?.join(", ") || "";
      }
    } else {
      if (schedule.shifts && schedule.shifts.length > 0) {
        const shiftsText = schedule.shifts
          .map((shift) => `${shift.startTime}-${shift.endTime}`)
          .join(", ");
        return `${schedule.startDate} to ${schedule.endDate} | ${shiftsText}`;
      } else {
        return `${schedule.startDate} to ${schedule.endDate}`;
      }
    }
  };

  const resetForm = () => {
    setFormData({
      type: "staff",
      isDaysMode: false,
      selectedDays: [],
      shifts: [{ id: "shift1", startTime: "", endTime: "" }],
      dayShifts: [],
      status: "active",
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Calendar className="h-8 w-8 text-blucrumbs-blue-500" />
            Schedule Setup
          </h1>
          <p className="text-gray-600 mt-1">
            Manage staff and team work schedules with multiple shifts support
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open);
            if (!open) resetForm();
          }}
        >
          <DialogTrigger asChild>
            <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
              <Plus className="h-4 w-4 mr-2" />
              Add Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Staff Schedule</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              {/* Branch Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5" />
                    Branch Selection
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div>
                    <Label htmlFor="branch">Branch *</Label>
                    <Select
                      value={formData.branchId || ""}
                      onValueChange={handleBranchSelection}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select branch first" />
                      </SelectTrigger>
                      <SelectContent>
                        {mockBranches.map((branch) => (
                          <SelectItem key={branch.id} value={branch.id}>
                            {branch.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Staff/Team Selection */}
              {formData.branchId && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Staff / Team Selection
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Staff / Team Member *</Label>
                      <div className="flex items-center space-x-4 mt-2">
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="radio"
                            name="type"
                            value="staff"
                            checked={formData.type === "staff"}
                            onChange={(e) =>
                              handleInputChange("type", e.target.value)
                            }
                          />
                          <span className="text-sm">Staff</span>
                        </label>
                        <label className="flex items-center space-x-2 cursor-pointer">
                          <input
                            type="radio"
                            name="type"
                            value="team"
                            checked={formData.type === "team"}
                            onChange={(e) =>
                              handleInputChange("type", e.target.value)
                            }
                          />
                          <span className="text-sm">Team</span>
                        </label>
                      </div>
                    </div>

                    {/* Staff/Team Dropdown */}
                    {formData.type === "staff" ? (
                      <div>
                        <Label htmlFor="staff">Staff *</Label>
                        <Select
                          value={formData.staffId || ""}
                          onValueChange={handleStaffSelection}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select staff member" />
                          </SelectTrigger>
                          <SelectContent>
                            {getAvailableStaff().map((staff) => (
                              <SelectItem key={staff.id} value={staff.id}>
                                {staff.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    ) : (
                      <div>
                        <Label htmlFor="team">Team *</Label>
                        <Select
                          value={formData.teamId || ""}
                          onValueChange={handleTeamSelection}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select team" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="KITCHEN">
                              Kitchen Team
                            </SelectItem>
                            <SelectItem value="SERVICE">
                              Service Team
                            </SelectItem>
                            <SelectItem value="MANAGEMENT">
                              Management Team
                            </SelectItem>
                            <SelectItem value="CLEANING">
                              Cleaning Team
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Schedule Configuration */}
              {(formData.staffId || formData.teamId) && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Schedule Configuration
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Days Switch */}
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="daysMode"
                        checked={formData.isDaysMode || false}
                        onCheckedChange={(checked) =>
                          handleInputChange("isDaysMode", checked)
                        }
                      />
                      <Label htmlFor="daysMode">
                        {formData.isDaysMode ? "Select Days" : "Date Range"}
                      </Label>
                    </div>

                    {/* Conditional Fields based on Days Switch */}
                    {!formData.isDaysMode ? (
                      /* Date Range Mode with Multiple Shifts */
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="startDate">Start Date *</Label>
                            <Input
                              id="startDate"
                              type="date"
                              value={formData.startDate || ""}
                              onChange={(e) =>
                                handleInputChange("startDate", e.target.value)
                              }
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="endDate">End Date *</Label>
                            <Input
                              id="endDate"
                              type="date"
                              value={formData.endDate || ""}
                              onChange={(e) =>
                                handleInputChange("endDate", e.target.value)
                              }
                              required
                            />
                          </div>
                        </div>

                        {/* Multiple Shifts for Date Range */}
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <Label>Shifts *</Label>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={addDateShift}
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Add Shift
                            </Button>
                          </div>
                          <div className="space-y-2">
                            {formData.shifts?.map((shift, index) => (
                              <div
                                key={shift.id}
                                className="flex items-center gap-2 p-3 border rounded-lg"
                              >
                                <div className="grid grid-cols-2 gap-2 flex-1">
                                  <div>
                                    <Label className="text-xs">
                                      Start Time
                                    </Label>
                                    <Input
                                      type="time"
                                      value={shift.startTime}
                                      onChange={(e) =>
                                        updateDateShift(
                                          shift.id,
                                          "startTime",
                                          e.target.value,
                                        )
                                      }
                                      required
                                    />
                                  </div>
                                  <div>
                                    <Label className="text-xs">End Time</Label>
                                    <Input
                                      type="time"
                                      value={shift.endTime}
                                      onChange={(e) =>
                                        updateDateShift(
                                          shift.id,
                                          "endTime",
                                          e.target.value,
                                        )
                                      }
                                      required
                                    />
                                  </div>
                                </div>
                                {formData.shifts &&
                                  formData.shifts.length > 1 && (
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => removeDateShift(shift.id)}
                                      className="text-red-600 hover:text-red-800"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Days Selection Mode with Day-specific Multiple Shifts */
                      <div className="space-y-4">
                        <div>
                          <Label>Select Days</Label>
                          <div className="grid grid-cols-2 gap-3 mt-2">
                            {daysOfWeek.map((day) => (
                              <label
                                key={day}
                                className="flex items-center space-x-2 cursor-pointer"
                              >
                                <input
                                  type="checkbox"
                                  checked={
                                    formData.selectedDays?.includes(day) ||
                                    false
                                  }
                                  onChange={() => handleDaySelection(day)}
                                  className="rounded border-gray-300"
                                />
                                <span className="text-sm">{day}</span>
                              </label>
                            ))}
                          </div>
                        </div>

                        {/* Day-specific Shifts */}
                        {formData.selectedDays &&
                          formData.selectedDays.length > 0 && (
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <Label>Shifts per Day</Label>
                                {formData.dayShifts &&
                                  formData.dayShifts.length > 0 && (
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        const firstDayShifts =
                                          formData.dayShifts?.[0]?.shifts || [];
                                        copyShiftsToAllDays(firstDayShifts);
                                      }}
                                    >
                                      <Copy className="h-4 w-4 mr-1" />
                                      Copy First Day to All
                                    </Button>
                                  )}
                              </div>
                              {formData.dayShifts?.map((dayShift) => (
                                <Card key={dayShift.day} className="border-2">
                                  <CardHeader className="pb-3">
                                    <div className="flex items-center justify-between">
                                      <CardTitle className="text-base">
                                        {dayShift.day}
                                      </CardTitle>
                                      <Button
                                        type="button"
                                        variant="outline"
                                        size="sm"
                                        onClick={() =>
                                          addShiftToDay(dayShift.day)
                                        }
                                      >
                                        <Plus className="h-4 w-4 mr-1" />
                                        Add Shift
                                      </Button>
                                    </div>
                                  </CardHeader>
                                  <CardContent className="pt-0">
                                    <div className="space-y-2">
                                      {dayShift.shifts.map(
                                        (shift, shiftIndex) => (
                                          <div
                                            key={shift.id}
                                            className="flex items-center gap-2 p-2 bg-gray-50 rounded"
                                          >
                                            <Badge
                                              variant="outline"
                                              className="text-xs"
                                            >
                                              Shift {shiftIndex + 1}
                                            </Badge>
                                            <div className="grid grid-cols-2 gap-2 flex-1">
                                              <Input
                                                type="time"
                                                value={shift.startTime}
                                                onChange={(e) =>
                                                  updateDayShift(
                                                    dayShift.day,
                                                    shift.id,
                                                    "startTime",
                                                    e.target.value,
                                                  )
                                                }
                                                required
                                              />
                                              <Input
                                                type="time"
                                                value={shift.endTime}
                                                onChange={(e) =>
                                                  updateDayShift(
                                                    dayShift.day,
                                                    shift.id,
                                                    "endTime",
                                                    e.target.value,
                                                  )
                                                }
                                                required
                                              />
                                            </div>
                                            {dayShift.shifts.length > 1 && (
                                              <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={() =>
                                                  removeShiftFromDay(
                                                    dayShift.day,
                                                    shift.id,
                                                  )
                                                }
                                                className="text-red-600 hover:text-red-800"
                                              >
                                                <Trash2 className="h-4 w-4" />
                                              </Button>
                                            )}
                                          </div>
                                        ),
                                      )}
                                    </div>
                                  </CardContent>
                                </Card>
                              ))}
                            </div>
                          )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              <div className="flex justify-end gap-3 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
                  Save Schedule
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search schedules..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Calendar View */}
      <Card>
        <CardHeader>
          <CardTitle>Schedule Calendar</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {daysOfWeek.map((day) => (
              <div
                key={day}
                className="p-3 text-center font-medium bg-blucrumbs-blue-50 rounded-lg"
              >
                {day.substring(0, 3)}
              </div>
            ))}
          </div>
          <div className="space-y-2">
            {filteredSchedules.map((schedule) => (
              <div
                key={schedule.id}
                className="p-3 border rounded-lg flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="h-3 w-3 rounded-full bg-blucrumbs-blue-500"></div>
                  <div>
                    <div className="font-medium">
                      {schedule.type === "staff"
                        ? schedule.staffName
                        : schedule.teamName}
                    </div>
                    <div className="text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Building2 className="h-3 w-3" />
                        {schedule.branchName}
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 flex items-center gap-2">
                      <Clock className="h-3 w-3" />
                      {formatScheduleDisplay(schedule)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    className={
                      schedule.status === "active"
                        ? "bg-green-100 text-green-800"
                        : "bg-red-100 text-red-800"
                    }
                  >
                    {schedule.status === "active" ? "Active" : "Inactive"}
                  </Badge>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        View
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Schedules Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Schedules</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredSchedules.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Branch</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Schedule</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSchedules.map((schedule) => (
                  <TableRow key={schedule.id}>
                    <TableCell className="font-medium">{schedule.id}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Building2 className="h-3 w-3 text-gray-400" />
                        <span className="text-sm">{schedule.branchName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {schedule.type === "staff" ? "Staff" : "Team"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {schedule.type === "staff"
                        ? schedule.staffName
                        : schedule.teamName}
                    </TableCell>
                    <TableCell>
                      <div className="max-w-xs text-sm">
                        {formatScheduleDisplay(schedule)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          schedule.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }
                      >
                        {schedule.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No Schedules Found
              </h3>
              <p className="text-gray-500 mb-6">
                {searchTerm
                  ? "No schedules match your search criteria."
                  : "Get started by adding your first schedule."}
              </p>
              <Button
                className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Schedule
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
