import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { UserPlus, Plus, Trash2 } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Assignment {
  id: string;
  branch: string;
  role: string;
  employee: string;
}

const mockChecklists = [
  {
    id: "CHK001",
    description: "Opening Restaurant Checklist",
    frequency: "Daily",
    taskCount: 3,
    tasks: [
      { id: "T1", name: "Check kitchen equipment" },
      { id: "T2", name: "Verify cash register" },
      { id: "T3", name: "Review inventory levels" },
    ],
  },
  {
    id: "CHK002",
    description: "Weekly Cleaning Checklist",
    frequency: "Weekly",
    taskCount: 2,
    tasks: [
      { id: "T4", name: "Deep clean kitchen" },
      { id: "T5", name: "Sanitize dining area" },
    ],
  },
  {
    id: "CHK003",
    description: "Monthly Inventory Check",
    frequency: "Monthly",
    taskCount: 4,
    tasks: [
      { id: "T6", name: "Count all inventory" },
      { id: "T7", name: "Update stock levels" },
      { id: "T8", name: "Order new supplies" },
      { id: "T9", name: "Review supplier contracts" },
    ],
  },
];

export default function AssignChecklist() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [newAssignment, setNewAssignment] = useState<Partial<Assignment>>({});
  const [selectedChecklistId, setSelectedChecklistId] = useState<string>("");
  const [selectedChecklist, setSelectedChecklist] = useState(mockChecklists[0]);

  const handleAssignmentChange = (field: keyof Assignment, value: string) => {
    setNewAssignment((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddAssignment = () => {
    if (newAssignment.branch && newAssignment.role && newAssignment.employee) {
      const assignment: Assignment = {
        id: Date.now().toString(),
        branch: newAssignment.branch,
        role: newAssignment.role,
        employee: newAssignment.employee,
      };
      setAssignments((prev) => [...prev, assignment]);
      setNewAssignment({});
    }
  };

  const handleRemoveAssignment = (assignmentId: string) => {
    setAssignments((prev) =>
      prev.filter((assignment) => assignment.id !== assignmentId),
    );
  };

  const handleChecklistChange = (checklistId: string) => {
    setSelectedChecklistId(checklistId);
    const checklist = mockChecklists.find((c) => c.id === checklistId);
    if (checklist) {
      setSelectedChecklist(checklist);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <UserPlus className="h-8 w-8 text-blucrumbs-blue-500" />
            Assign Checklist
          </h1>
          <p className="text-gray-600 mt-1">
            Assign checklist to staff members and roles
          </p>
        </div>
      </div>

      {/* Checklist Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Checklist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="checklistSelect">Checklist *</Label>
              <Select
                value={selectedChecklistId}
                onValueChange={handleChecklistChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a checklist to assign" />
                </SelectTrigger>
                <SelectContent>
                  {mockChecklists.map((checklist) => (
                    <SelectItem key={checklist.id} value={checklist.id}>
                      {checklist.description} ({checklist.id})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Checklist Information */}
      {selectedChecklistId && (
        <Card>
          <CardHeader>
            <CardTitle>Checklist Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Description</Label>
                <Input
                  value={`${selectedChecklist.description} - ${selectedChecklist.id}`}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
              <div>
                <Label>Frequency</Label>
                <Input
                  value={selectedChecklist.frequency}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
              <div>
                <Label>No. of Tasks</Label>
                <Input
                  value={selectedChecklist.taskCount.toString()}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
            </div>

            {/* Tasks Table */}
            <div>
              <Label>Tasks</Label>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Task ID</TableHead>
                    <TableHead>Task Name</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedChecklist.tasks.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell className="font-medium">{task.id}</TableCell>
                      <TableCell>{task.name}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Assignment Section */}
      {selectedChecklistId && (
        <Card>
          <CardHeader>
            <CardTitle>Assign Checklist</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="branch">Branch</Label>
                <Select
                  value={newAssignment.branch || ""}
                  onValueChange={(value) =>
                    handleAssignmentChange("branch", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select branch" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="main-riyadh">
                      Main Branch - Riyadh
                    </SelectItem>
                    <SelectItem value="branch-jeddah">
                      Branch - Jeddah
                    </SelectItem>
                    <SelectItem value="branch-dammam">
                      Branch - Dammam
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="role">Role</Label>
                <Select
                  value={newAssignment.role || ""}
                  onValueChange={(value) =>
                    handleAssignmentChange("role", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="chef">Chef</SelectItem>
                    <SelectItem value="cashier">Cashier</SelectItem>
                    <SelectItem value="waiter">Waiter</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="employee">Employee</Label>
                <Select
                  value={newAssignment.employee || ""}
                  onValueChange={(value) =>
                    handleAssignmentChange("employee", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ahmed-alsaud">Ahmed Al-Saud</SelectItem>
                    <SelectItem value="sarah-wilson">Sarah Wilson</SelectItem>
                    <SelectItem value="mike-johnson">Mike Johnson</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button
                  onClick={handleAddAssignment}
                  disabled={
                    !newAssignment.branch ||
                    !newAssignment.role ||
                    !newAssignment.employee
                  }
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Assigned Table */}
      {selectedChecklistId && (
        <Card>
          <CardHeader>
            <CardTitle>Assigned Personnel</CardTitle>
          </CardHeader>
          <CardContent>
            {assignments.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Branch</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Employee</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {assignments.map((assignment) => (
                    <TableRow key={assignment.id}>
                      <TableCell>{assignment.branch}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{assignment.role}</Badge>
                      </TableCell>
                      <TableCell>{assignment.employee}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveAssignment(assignment.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <UserPlus className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                <p>No assignments yet</p>
                <p className="text-sm">Add assignments using the form above</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      {selectedChecklistId && (
        <div className="flex justify-end gap-3">
          <Button variant="outline">Cancel</Button>
          <Button className="bg-blucrumbs-blue-500 hover:bg-blucrumbs-blue-600">
            Save Assignments
          </Button>
        </div>
      )}
    </div>
  );
}
