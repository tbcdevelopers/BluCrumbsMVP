import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  ClipboardCheck,
  Calendar,
  Clock,
  ArrowLeft,
  UserPlus,
  History,
  CheckCircle,
  XCircle,
  Users,
  Eye,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Task {
  id: string;
  description: string;
  assignedTo?: string;
  assignedBy?: string;
  assignedDate?: string;
  completedDate?: string;
  status: "pending" | "assigned" | "completed" | "verified";
  notes?: string;
  verifiedBy?: string;
  verifiedDate?: string;
}

interface TaskHistory {
  id: string;
  taskId: string;
  taskDescription: string;
  assignedTo: string;
  assignedBy: string;
  assignedDate: string;
  completedDate?: string;
  verifiedBy?: string;
  verifiedDate?: string;
  status: "completed" | "verified";
  notes?: string;
}

interface ChecklistItem {
  id: string;
  description: string;
  date: string;
  status: "pending" | "completed" | "overdue";
  completed?: boolean;
  tasks: Task[];
}

const mockDailyItems: ChecklistItem[] = [
  {
    id: "D1",
    description: "Check kitchen equipment functionality",
    date: "2024-01-15",
    status: "completed",
    completed: true,
    tasks: [
      {
        id: "T1",
        description: "Test all ovens and stoves",
        assignedTo: "John Smith",
        assignedBy: "Manager",
        assignedDate: "2024-01-15",
        completedDate: "2024-01-15",
        status: "completed",
        notes: "All equipment working properly",
      },
      {
        id: "T2",
        description: "Check refrigeration units",
        assignedTo: "Sarah Johnson",
        assignedBy: "Manager",
        assignedDate: "2024-01-15",
        completedDate: "2024-01-15",
        status: "verified",
        verifiedBy: "Supervisor",
        verifiedDate: "2024-01-15",
        notes: "Temperature logs verified",
      },
    ],
  },
  {
    id: "D2",
    description: "Verify cash register and POS systems",
    date: "2024-01-15",
    status: "completed",
    completed: true,
    tasks: [
      {
        id: "T3",
        description: "Test POS system connectivity",
        assignedTo: "Mike Wilson",
        assignedBy: "Manager",
        assignedDate: "2024-01-15",
        completedDate: "2024-01-15",
        status: "completed",
        notes: "All systems online",
      },
    ],
  },
  {
    id: "D3",
    description: "Review inventory levels for key items",
    date: "2024-01-15",
    status: "pending",
    completed: false,
    tasks: [
      {
        id: "T4",
        description: "Count meat inventory",
        status: "pending",
      },
      {
        id: "T5",
        description: "Check vegetable stock",
        assignedTo: "Lisa Davis",
        assignedBy: "Manager",
        assignedDate: "2024-01-15",
        status: "assigned",
      },
    ],
  },
  {
    id: "D4",
    description: "Clean and sanitize prep areas",
    date: "2024-01-15",
    status: "pending",
    completed: false,
    tasks: [
      {
        id: "T6",
        description: "Sanitize cutting boards",
        status: "pending",
      },
      {
        id: "T7",
        description: "Clean prep tables",
        status: "pending",
      },
    ],
  },
];

const mockWeeklyItems: ChecklistItem[] = [
  {
    id: "W1",
    description: "Deep clean kitchen exhaust system",
    date: "2024-01-15",
    status: "pending",
    completed: false,
    tasks: [
      {
        id: "T8",
        description: "Clean exhaust filters",
        status: "pending",
      },
      {
        id: "T9",
        description: "Inspect duct work",
        assignedTo: "Tom Brown",
        assignedBy: "Manager",
        assignedDate: "2024-01-15",
        status: "assigned",
      },
    ],
  },
];

const mockMonthlyItems: ChecklistItem[] = [
  {
    id: "M1",
    description: "Equipment maintenance check",
    date: "2024-01-15",
    status: "pending",
    completed: false,
    tasks: [
      {
        id: "T10",
        description: "Service commercial dishwasher",
        status: "pending",
      },
      {
        id: "T11",
        description: "Check fire suppression system",
        assignedTo: "Maintenance Team",
        assignedBy: "Manager",
        assignedDate: "2024-01-15",
        status: "assigned",
      },
    ],
  },
];

const mockTaskHistory: TaskHistory[] = [
  {
    id: "H1",
    taskId: "T1",
    taskDescription: "Test all ovens and stoves",
    assignedTo: "John Smith",
    assignedBy: "Manager",
    assignedDate: "2024-01-15",
    completedDate: "2024-01-15",
    verifiedBy: "Supervisor",
    verifiedDate: "2024-01-15",
    status: "verified",
    notes: "All equipment working properly",
  },
  {
    id: "H2",
    taskId: "T2",
    taskDescription: "Check refrigeration units",
    assignedTo: "Sarah Johnson",
    assignedBy: "Manager",
    assignedDate: "2024-01-14",
    completedDate: "2024-01-14",
    status: "completed",
    notes: "Temperature logs verified",
  },
  {
    id: "H3",
    taskId: "T3",
    taskDescription: "Test POS system connectivity",
    assignedTo: "Mike Wilson",
    assignedBy: "Manager",
    assignedDate: "2024-01-13",
    completedDate: "2024-01-13",
    verifiedBy: "Supervisor",
    verifiedDate: "2024-01-13",
    status: "verified",
    notes: "All systems online",
  },
];

const mockStaff = [
  { id: "1", name: "John Smith", role: "Kitchen Staff" },
  { id: "2", name: "Sarah Johnson", role: "Kitchen Staff" },
  { id: "3", name: "Mike Wilson", role: "Cashier" },
  { id: "4", name: "Lisa Davis", role: "Prep Cook" },
  { id: "5", name: "Tom Brown", role: "Maintenance" },
];

export default function MyChecklist() {
  const [selectedPeriod, setSelectedPeriod] = useState("daily");
  const [selectedChecklist, setSelectedChecklist] =
    useState<ChecklistItem | null>(null);
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [assignFormData, setAssignFormData] = useState({
    assignedTo: "",
    notes: "",
  });

  const getItemsByPeriod = () => {
    switch (selectedPeriod) {
      case "daily":
        return mockDailyItems;
      case "weekly":
        return mockWeeklyItems;
      case "monthly":
        return mockMonthlyItems;
      default:
        return mockDailyItems;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "verified":
        return "bg-blue-100 text-blue-800";
      case "assigned":
        return "bg-orange-100 text-orange-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const handleChecklistClick = (checklist: ChecklistItem) => {
    setSelectedChecklist(checklist);
  };

  const handleBackToList = () => {
    setSelectedChecklist(null);
  };

  const handleAssignTask = (task: Task) => {
    setSelectedTask(task);
    setAssignFormData({
      assignedTo: task.assignedTo || "",
      notes: task.notes || "",
    });
    setIsAssignDialogOpen(true);
  };

  const handleSaveAssignment = () => {
    // Handle task assignment logic here
    setIsAssignDialogOpen(false);
    setSelectedTask(null);
    setAssignFormData({ assignedTo: "", notes: "" });
  };

  const handleVerifyTask = (taskId: string) => {
    // Handle task verification logic here
    console.log("Verifying task:", taskId);
  };

  const handleCompleteTask = (taskId: string) => {
    // Handle task completion logic here
    console.log("Completing task:", taskId);
  };

  if (selectedChecklist) {
    return (
      <div className="p-6 space-y-6">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={handleBackToList}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Checklists
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <ClipboardCheck className="h-8 w-8 text-blucrumbs-blue-500" />
                {selectedChecklist.description}
              </h1>
              <p className="text-gray-600 mt-1">
                {new Date(selectedChecklist.date).toLocaleDateString()} - Tasks
                and Assignments
              </p>
            </div>
          </div>
        </div>

        {/* Tasks Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Tasks List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Tasks ({selectedChecklist.tasks.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {selectedChecklist.tasks.map((task) => (
                  <div
                    key={task.id}
                    className="border rounded-lg p-4 space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">
                          {task.description}
                        </h4>
                        {task.assignedTo && (
                          <p className="text-sm text-gray-600 mt-1">
                            Assigned to:{" "}
                            <span className="font-medium">
                              {task.assignedTo}
                            </span>
                          </p>
                        )}
                        {task.assignedDate && (
                          <p className="text-sm text-gray-500">
                            Assigned:{" "}
                            {new Date(task.assignedDate).toLocaleDateString()}
                          </p>
                        )}
                        {task.notes && (
                          <p className="text-sm text-gray-600 mt-2 italic">
                            Notes: {task.notes}
                          </p>
                        )}
                      </div>
                      <Badge className={getStatusColor(task.status)}>
                        {task.status.charAt(0).toUpperCase() +
                          task.status.slice(1)}
                      </Badge>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleAssignTask(task)}
                      >
                        <UserPlus className="h-4 w-4 mr-1" />
                        {task.assignedTo ? "Reassign" : "Assign"}
                      </Button>

                      {task.status === "assigned" && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleCompleteTask(task.id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Complete
                        </Button>
                      )}

                      {task.status === "completed" && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleVerifyTask(task.id)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          Verify
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* History Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Task History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Task</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Completed</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockTaskHistory.map((history) => (
                    <TableRow key={history.id}>
                      <TableCell className="font-medium">
                        <div>
                          <div className="text-sm">
                            {history.taskDescription}
                          </div>
                          {history.notes && (
                            <div className="text-xs text-gray-500 mt-1">
                              {history.notes}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{history.assignedTo}</TableCell>
                      <TableCell>
                        {history.completedDate
                          ? new Date(history.completedDate).toLocaleDateString()
                          : "-"}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(history.status)}>
                          {history.status.charAt(0).toUpperCase() +
                            history.status.slice(1)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Assignment Dialog */}
        <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Assign Task</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="taskDescription">Task Description</Label>
                <Input
                  id="taskDescription"
                  value={selectedTask?.description || ""}
                  readOnly
                  className="bg-gray-50"
                />
              </div>
              <div>
                <Label htmlFor="assignTo">Assign to *</Label>
                <Select
                  value={assignFormData.assignedTo}
                  onValueChange={(value) =>
                    setAssignFormData((prev) => ({
                      ...prev,
                      assignedTo: value,
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select staff member" />
                  </SelectTrigger>
                  <SelectContent>
                    {mockStaff.map((staff) => (
                      <SelectItem key={staff.id} value={staff.name}>
                        {staff.name} - {staff.role}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={assignFormData.notes}
                  onChange={(e) =>
                    setAssignFormData((prev) => ({
                      ...prev,
                      notes: e.target.value,
                    }))
                  }
                  placeholder="Add any notes or instructions..."
                  rows={3}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsAssignDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button onClick={handleSaveAssignment}>
                  {selectedTask?.assignedTo
                    ? "Update Assignment"
                    : "Assign Task"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <ClipboardCheck className="h-8 w-8 text-blucrumbs-blue-500" />
            My Checklist
          </h1>
          <p className="text-gray-600 mt-1">
            Track and manage your assigned checklist items
          </p>
        </div>
      </div>

      {/* Period Tabs */}
      <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod}>
        <TabsList>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedPeriod} className="mt-6">
          <div className="grid gap-4">
            {getItemsByPeriod().map((item) => (
              <Card
                key={item.id}
                className={`transition-colors cursor-pointer ${
                  item.status === "completed"
                    ? "border-green-200 bg-green-50"
                    : item.status === "overdue"
                      ? "border-red-200 bg-red-50"
                      : "border-gray-200 hover:border-gray-300"
                }`}
                onClick={() => handleChecklistClick(item)}
              >
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {item.description}
                        </h3>
                        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>
                              {new Date(item.date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>Due Today</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users className="h-4 w-4" />
                            <span>{item.tasks.length} tasks</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={getStatusColor(item.status)}>
                        {item.status.charAt(0).toUpperCase() +
                          item.status.slice(1)}
                      </Badge>
                      <div className="text-sm text-gray-500">
                        Click to view tasks →
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
