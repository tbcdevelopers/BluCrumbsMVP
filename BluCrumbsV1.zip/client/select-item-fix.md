# SelectItem Empty Value Error Fix

## Problem

Radix UI Select components don't allow SelectItem components to have empty string (`""`) values. This was causing runtime errors in the GoodsIssuance and GoodsReceiving pages.

Error message:

```
Error: A <Select.Item /> must have a value prop that is not an empty string. This is because the Select value can be set to an empty string to clear the selection and show the placeholder.
```

## Root Cause

In both GoodsIssuance.tsx and GoodsReceiving.tsx, I had added conditional SelectItems with empty string values:

```tsx
{
  !formData.fromBranch && (
    <SelectItem value="" disabled>
      Please select from branch first
    </SelectItem>
  );
}
```

## Solution

Fixed by using non-empty placeholder values instead of empty strings:

**Before:**

```tsx
<SelectContent>
  {formData.fromBranch && getStoragesByBranch(formData.fromBranch).map(...)}
  {!formData.fromBranch && (
    <SelectItem value="" disabled>
      Please select from branch first
    </SelectItem>
  )}
</SelectContent>
```

**After:**

```tsx
<SelectContent>
  {formData.fromBranch ? (
    getStoragesByBranch(formData.fromBranch).map(...)
  ) : (
    <SelectItem value="no-branch-selected" disabled>
      Please select from branch first
    </SelectItem>
  )}
</SelectContent>
```

## Files Fixed

1. `client/pages/transfers/GoodsIssuance.tsx` - Line 444
2. `client/pages/transfers/GoodsReceiving.tsx` - Line 669

## Result

- ✅ No more SelectItem empty value errors
- ✅ Build completes successfully
- ✅ Storage selection functionality works as expected
- ✅ Proper user guidance when no branch is selected
