import { ReactNode, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Building2,
  Users,
  Settings,
  Package,
  ShoppingCart,
  Receipt,
  ArrowLeftRight,
  ChefHat,
  ClipboardList,
  UserCheck,
  Menu,
  X,
  Bell,
  Search,
  User,
  LayoutGrid,
  Monitor,
  FileText,
  Terminal,
  Calendar,
  UserPlus,
  ClipboardCheck,
  Tags,
} from "lucide-react";

interface NavItem {
  title: string;
  href: string;
  icon: any;
  children?: NavItem[];
}

const navigationItems: NavItem[] = [
  {
    title: "Dashboard",
    href: "/",
    icon: Building2,
  },
  {
    title: "Management",
    href: "/management",
    icon: UserCheck,
    children: [
      { title: "Schedules", href: "/management/schedules", icon: Calendar },
      {
        title: "Checklists",
        href: "/management/checklists",
        icon: ClipboardList,
      },
      {
        title: "Assign Checklist",
        href: "/management/assign-checklist",
        icon: UserPlus,
      },
      {
        title: "My Checklist",
        href: "/management/my-checklist",
        icon: ClipboardCheck,
      },
    ],
  },
  {
    title: "Inventory",
    href: "/inventory",
    icon: Package,
    children: [
      {
        title: "Kitchen Items",
        href: "/inventory/kitchen-items",
        icon: ChefHat,
      },
      { title: "Menu Items", href: "/inventory/menu", icon: Receipt },
    ],
  },
  {
    title: "Internal Transfers",
    href: "/transfers",
    icon: ArrowLeftRight,
    children: [
      {
        title: "Pantry Requests",
        href: "/transfers/requests",
        icon: ArrowLeftRight,
      },
      {
        title: "Goods Issuance",
        href: "/transfers/issuance",
        icon: ArrowLeftRight,
      },
      {
        title: "Goods Receiving",
        href: "/transfers/receiving",
        icon: ArrowLeftRight,
      },
    ],
  },
  {
    title: "Purchases",
    href: "/purchases",
    icon: ShoppingCart,
    children: [
      {
        title: "Purchase Request",
        href: "/purchases/request",
        icon: ShoppingCart,
      },
      { title: "Purchase Order", href: "/purchases/order", icon: ShoppingCart },
      {
        title: "Goods Receiving",
        href: "/purchases/receiving",
        icon: ShoppingCart,
      },
    ],
  },
  {
    title: "Sales",
    href: "/sales",
    icon: Receipt,
    children: [
      { title: "Customers", href: "/sales/customers", icon: Users },
      { title: "Promotions", href: "/sales/promotions", icon: Receipt },
      {
        title: "Reservations",
        href: "/sales/reservations",
        icon: ClipboardList,
      },
      { title: "Live Orders", href: "/sales/live-orders", icon: ChefHat },
      { title: "POS", href: "/sales/pos", icon: Receipt },
      { title: "Closing", href: "/sales/closing", icon: Receipt },
      { title: "Register Log", href: "/sales/register-log", icon: FileText },
    ],
  },
  {
    title: "Configuration",
    href: "/configuration",
    icon: Settings,
    children: [
      { title: "Company", href: "/configuration/company", icon: Building2 },
      { title: "Branches", href: "/configuration/branches", icon: Building2 },
      { title: "Floors", href: "/configuration/floors", icon: Building2 },
      { title: "Sections", href: "/configuration/sections", icon: LayoutGrid },
      { title: "Storage", href: "/configuration/storage", icon: Package },
      { title: "Stations", href: "/configuration/stations", icon: ChefHat },
      {
        title: "Cash Registers",
        href: "/configuration/cash-registers",
        icon: Monitor,
      },
      {
        title: "Span Terminals",
        href: "/configuration/span-terminals",
        icon: Terminal,
      },
      {
        title: "Staff Details",
        href: "/configuration/staff-details",
        icon: Users,
      },
      { title: "Teams", href: "/configuration/teams", icon: Users },
      { title: "Categories", href: "/configuration/categories", icon: Tags },
      { title: "Layout", href: "/configuration/layout", icon: Settings },
    ],
  },
];

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const location = useLocation();

  const toggleExpanded = (href: string) => {
    setExpandedItems((prev) =>
      prev.includes(href)
        ? prev.filter((item) => item !== href)
        : [...prev, href],
    );
  };

  const isActive = (href: string) => {
    if (href === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(href);
  };

  const isExpanded = (href: string) => {
    return expandedItems.includes(href) || location.pathname.startsWith(href);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-72 bg-sidebar transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blucrumbs-blue-500">
              <ChefHat className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-sidebar-foreground">
                BluCrumbs
              </h1>
              <p className="text-xs text-sidebar-foreground/70">
                Restaurant Management
              </p>
            </div>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="space-y-1">
              {navigationItems.map((item) => (
                <div key={item.href}>
                  {item.children ? (
                    <div>
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                          isActive(item.href) &&
                            "bg-sidebar-accent text-sidebar-accent-foreground",
                        )}
                        onClick={() => toggleExpanded(item.href)}
                      >
                        <item.icon className="mr-3 h-4 w-4" />
                        {item.title}
                        <div
                          className={cn(
                            "ml-auto transition-transform",
                            isExpanded(item.href) && "rotate-90",
                          )}
                        >
                          ▶
                        </div>
                      </Button>
                      {isExpanded(item.href) && (
                        <div className="ml-4 mt-1 space-y-1">
                          {item.children.map((child) => (
                            <Link
                              key={child.href}
                              to={child.href}
                              className={cn(
                                "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                                isActive(child.href)
                                  ? "bg-blucrumbs-blue-500 text-white"
                                  : "text-sidebar-foreground/70",
                              )}
                            >
                              <child.icon className="mr-3 h-4 w-4" />
                              {child.title}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link
                      to={item.href}
                      className={cn(
                        "flex items-center rounded-md px-3 py-2 text-sm transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                        isActive(item.href)
                          ? "bg-blucrumbs-blue-500 text-white"
                          : "text-sidebar-foreground",
                      )}
                    >
                      <item.icon className="mr-3 h-4 w-4" />
                      {item.title}
                    </Link>
                  )}
                </div>
              ))}
            </nav>
          </ScrollArea>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-1 flex-col lg:ml-0">
        {/* Header */}
        <header className="flex h-16 items-center justify-between border-b border-gray-200 bg-white px-6 shadow-sm">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
            <div className="flex items-center gap-2">
              <Search className="h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search..."
                className="border-none bg-transparent text-sm outline-none placeholder:text-gray-400"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm">
              <User className="h-5 w-5" />
            </Button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto">{children}</main>
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
