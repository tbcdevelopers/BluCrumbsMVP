import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Minus,
  X,
  Edit,
  Save,
  Trash2,
  Utensils,
  ShoppingCart,
} from "lucide-react";
import {
  useParkedOrders,
  type ParkedOrder,
  type ParkedOrderItem,
} from "@/contexts/ParkedOrdersContext";

interface ParkedOrderEditProps {
  parkedOrder: ParkedOrder | null;
  isOpen: boolean;
  onClose: () => void;
  availableMenuItems?: any[]; // Would use the same menu items from POS
}

// Mock menu items for adding to order
const mockMenuItems = [
  // Starters
  { id: "1", name: "Chicken Spring Rolls", price: 12.0, category: "Starters" },
  { id: "2", name: "Cheesy Nuggets", price: 8.0, category: "Starters" },
  { id: "3", name: "French Fries", price: 7.0, category: "Starters" },
  { id: "4", name: "Chicken Fries", price: 5.0, category: "Starters" },
  { id: "5", name: "Corn", price: 6.0, category: "Starters" },
  { id: "6", name: "Cheesy Fries", price: 7.0, category: "Starters" },
  { id: "7", name: "Fattoush Salad", price: 5.0, category: "Starters" },
  { id: "8", name: "Coleslaw", price: 5.0, category: "Starters" },
  { id: "9", name: "Green Salad", price: 5.0, category: "Starters" },
  { id: "10", name: "Hummus", price: 8.0, category: "Starters" },

  // Main Meals
  {
    id: "11",
    name: "Grilled Chicken Breast",
    price: 25.0,
    category: "Main Meals",
  },
  { id: "12", name: "BBQ Beef Burger", price: 22.0, category: "Main Meals" },
  { id: "13", name: "Fish & Chips", price: 20.0, category: "Main Meals" },
  { id: "14", name: "Chicken Shawarma", price: 18.0, category: "Main Meals" },
  { id: "15", name: "Beef Steak", price: 35.0, category: "Main Meals" },
  {
    id: "16",
    name: "Chicken Alfredo Pasta",
    price: 24.0,
    category: "Main Meals",
  },

  // Burger Meals
  {
    id: "17",
    name: "Classic Burger Meal",
    price: 20.0,
    category: "Burger Meals",
  },
  {
    id: "18",
    name: "Cheese Burger Meal",
    price: 22.0,
    category: "Burger Meals",
  },
  {
    id: "19",
    name: "Chicken Burger Meal",
    price: 21.0,
    category: "Burger Meals",
  },
  {
    id: "20",
    name: "Double Burger Meal",
    price: 28.0,
    category: "Burger Meals",
  },

  // Beverages
  { id: "21", name: "Fresh Orange Juice", price: 8.0, category: "Beverages" },
  { id: "22", name: "Coffee", price: 6.0, category: "Beverages" },
  { id: "23", name: "Tea", price: 5.0, category: "Beverages" },
  { id: "24", name: "Soft Drink", price: 4.0, category: "Beverages" },
  { id: "25", name: "Lemonade", price: 7.0, category: "Beverages" },

  // Desserts
  { id: "26", name: "Chocolate Cake", price: 12.0, category: "Desserts" },
  { id: "27", name: "Cheesecake", price: 14.0, category: "Desserts" },
  { id: "28", name: "Ice Cream", price: 8.0, category: "Desserts" },
  { id: "29", name: "Fruit Salad", price: 10.0, category: "Desserts" },
];

// Mock tables for changing table assignment
const mockTables = [
  { id: "t1", number: "T01", seats: 4, status: "available" },
  { id: "t2", number: "T02", seats: 2, status: "available" },
  { id: "t4", number: "T04", seats: 4, status: "available" },
  { id: "t6", number: "T06", seats: 8, status: "available" },
  { id: "t7", number: "T07", seats: 4, status: "available" },
  { id: "t8", number: "T08", seats: 2, status: "available" },
  { id: "t9", number: "T09", seats: 6, status: "available" },
  { id: "t10", number: "T10", seats: 4, status: "available" },
];

export default function ParkedOrderEdit({
  parkedOrder,
  isOpen,
  onClose,
  availableMenuItems = mockMenuItems,
}: ParkedOrderEditProps) {
  const { updateParkedOrder, removeParkedOrder, getStationAssignment } =
    useParkedOrders();
  const [editedOrder, setEditedOrder] = useState<ParkedOrder | null>(null);
  const [showAddItemDialog, setShowAddItemDialog] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (parkedOrder) {
      setEditedOrder({ ...parkedOrder });
    }
  }, [parkedOrder]);

  if (!editedOrder) return null;

  const updateOrderItem = (
    itemId: string,
    field: keyof ParkedOrderItem,
    value: any,
  ) => {
    setEditedOrder((prev) => {
      if (!prev) return null;

      const updatedItems = prev.items.map((item) => {
        if (item.id === itemId) {
          const updatedItem = { ...item, [field]: value };
          // Recalculate amount if quantity or price changed
          if (field === "quantity" || field === "price") {
            updatedItem.amount = updatedItem.quantity * updatedItem.price;
          }
          return updatedItem;
        }
        return item;
      });

      const updatedOrder = {
        ...prev,
        items: updatedItems,
        ...recalculateTotals(updatedItems),
      };

      // Auto-save changes immediately
      autoSaveChanges(updatedOrder);

      return updatedOrder;
    });
  };

  const removeOrderItem = (itemId: string) => {
    setEditedOrder((prev) => {
      if (!prev) return null;

      const updatedItems = prev.items.filter((item) => item.id !== itemId);
      const updatedOrder = {
        ...prev,
        items: updatedItems,
        ...recalculateTotals(updatedItems),
      };

      // Auto-save changes immediately
      autoSaveChanges(updatedOrder);

      return updatedOrder;
    });
  };

  // Helper function to generate unique item ID
  const generateUniqueItemId = (
    originalItemId: string,
    orderId: string,
    itemIndex: number,
  ) => {
    const orderNumber = orderId.split("-").pop()?.slice(-3) || "000";
    return `${originalItemId}O${orderNumber}I${itemIndex + 1}`;
  };

  const addMenuItem = (menuItem: any) => {
    // Check for existing item based on original menu item ID
    const existingItem = editedOrder.items.find(
      (item) => item.originalItemId === menuItem.id || item.id === menuItem.id,
    );

    if (existingItem) {
      updateOrderItem(existingItem.id, "quantity", existingItem.quantity + 1);
    } else {
      // Generate unique item ID for this order
      const uniqueItemId = generateUniqueItemId(
        menuItem.id,
        editedOrder!.id,
        editedOrder!.items.length,
      );

      const newItem: ParkedOrderItem = {
        id: uniqueItemId,
        originalItemId: menuItem.id, // Store original menu item ID
        name: menuItem.name,
        price: menuItem.price,
        quantity: 1,
        amount: menuItem.price,
        isCompleted: false, // New items start as incomplete
      };

      setEditedOrder((prev) => {
        if (!prev) return null;

        const updatedItems = [...prev.items, newItem];
        const updatedOrder = {
          ...prev,
          items: updatedItems,
          ...recalculateTotals(updatedItems),
          version: (prev.version || 1) + 1, // Increment version when adding items
        };

        // Auto-save changes immediately
        autoSaveChanges(updatedOrder);

        return updatedOrder;
      });
    }
    setShowAddItemDialog(false);

    // Visual feedback
    console.log(`Added ${menuItem.name} to order ${editedOrder?.id}`);
  };

  const recalculateTotals = (items: ParkedOrderItem[]) => {
    const netTotal = items.reduce((sum, item) => sum + item.amount, 0);
    const discount = 0; // Keep existing discount logic
    const additionalDiscount = 0;
    const taxableAmount = netTotal - discount - additionalDiscount;
    const vatAmount = taxableAmount * 0.15; // 15% VAT
    const grandTotal = taxableAmount + vatAmount;

    return {
      netTotal,
      discount,
      additionalDiscount,
      taxableAmount,
      vatAmount,
      grandTotal,
    };
  };

  // Auto-save function that immediately updates the order
  const autoSaveChanges = (updatedOrder: ParkedOrder) => {
    if (!updatedOrder || updatedOrder.items.length === 0) {
      return; // Don't save empty orders
    }

    // Use the context's getStationAssignment for automatic routing
    const { station, workflow } = getStationAssignment(updatedOrder.items);

    // Prepare updated order - automatic routing and status handling is done by context
    const finalOrder = {
      ...updatedOrder,
      lastEditedAt: new Date().toISOString(),
    };

    updateParkedOrder(updatedOrder.id, finalOrder);

    // Show brief success feedback
    console.log(
      `Order ${updatedOrder.id} updated and auto-routed to ${station} station`,
    );
  };

  const handleSave = () => {
    if (editedOrder) {
      if (editedOrder.items.length === 0) {
        alert(
          "Cannot save order with no items. Please add at least one item or delete the order.",
        );
        return;
      }

      // If order is already in kitchen or ready, warn about potential impact
      if (editedOrder.status === "in-kitchen") {
        if (
          !confirm(
            "This order is currently being prepared in the kitchen. Editing may cause delays. Continue?",
          )
        ) {
          return;
        }
      } else if (editedOrder.status === "ready") {
        if (
          !confirm(
            "This order is ready for pickup. Editing will require re-preparation. Continue?",
          )
        ) {
          return;
        }
      }

      // Use the context's getStationAssignment for automatic routing
      const { station, workflow } = getStationAssignment(editedOrder.items);

      // Prepare updated order - automatic routing and status handling is done by context
      const updatedOrder = {
        ...editedOrder,
        lastEditedAt: new Date().toISOString(),
      };

      updateParkedOrder(editedOrder.id, updatedOrder);

      // Show success message
      alert(
        `Order ${editedOrder.id} has been updated and automatically routed to ${station} station!`,
      );

      onClose();
    }
  };

  const handleDelete = () => {
    if (editedOrder) {
      removeParkedOrder(editedOrder.id);
      onClose();
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5 text-blue-500" />
              Edit Parked Order - {editedOrder.id}
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Side - Order Details */}
            <div className="space-y-4">
              {/* Order Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Order Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Order Type</Label>
                    <div className="mt-1">
                      <Badge variant="outline">
                        {editedOrder.orderType === "dinein"
                          ? "Dine In"
                          : "Take Away"}
                      </Badge>
                    </div>
                  </div>

                  {editedOrder.orderType === "dinein" && (
                    <div>
                      <Label htmlFor="table-select">Table Assignment</Label>
                      <Select
                        value={editedOrder.tableNumber || ""}
                        onValueChange={(value) =>
                          setEditedOrder((prev) =>
                            prev ? { ...prev, tableNumber: value } : null,
                          )
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select table" />
                        </SelectTrigger>
                        <SelectContent>
                          {mockTables.map((table) => (
                            <SelectItem key={table.id} value={table.number}>
                              <div className="flex items-center gap-2">
                                <Utensils className="h-4 w-4" />
                                {table.number} ({table.seats} seats)
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div>
                    <Label htmlFor="customer-name">Customer Name</Label>
                    <Input
                      id="customer-name"
                      value={editedOrder.customerName || ""}
                      onChange={(e) =>
                        setEditedOrder((prev) =>
                          prev
                            ? { ...prev, customerName: e.target.value }
                            : null,
                        )
                      }
                      placeholder="Enter customer name"
                    />
                  </div>

                  <div>
                    <Label htmlFor="customer-phone">Customer Phone</Label>
                    <Input
                      id="customer-phone"
                      value={editedOrder.customerPhone || ""}
                      onChange={(e) =>
                        setEditedOrder((prev) =>
                          prev
                            ? { ...prev, customerPhone: e.target.value }
                            : null,
                        )
                      }
                      placeholder="Enter phone number"
                    />
                  </div>

                  <div>
                    <Label htmlFor="order-notes">Order Notes</Label>
                    <Textarea
                      id="order-notes"
                      value={editedOrder.notes || ""}
                      onChange={(e) =>
                        setEditedOrder((prev) =>
                          prev ? { ...prev, notes: e.target.value } : null,
                        )
                      }
                      placeholder="Special instructions or notes..."
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Side - Order Items */}
            <div className="space-y-4">
              {/* Items Management */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Order Items</CardTitle>
                    <Button
                      size="sm"
                      onClick={() => setShowAddItemDialog(true)}
                      className="bg-green-500 hover:bg-green-600"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Item
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {editedOrder.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg"
                      >
                        <div className="flex-1">
                          <div className="font-medium">{item.name}</div>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <span>SAR</span>
                            <Input
                              type="number"
                              step="0.01"
                              min="0"
                              value={item.price}
                              onChange={(e) =>
                                updateOrderItem(
                                  item.id,
                                  "price",
                                  parseFloat(e.target.value) || 0,
                                )
                              }
                              className="w-16 h-6 text-xs"
                            />
                            <span>each</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 w-8 p-0"
                            onClick={() =>
                              updateOrderItem(
                                item.id,
                                "quantity",
                                Math.max(1, item.quantity - 1),
                              )
                            }
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm">
                            {item.quantity}
                          </span>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 w-8 p-0"
                            onClick={() =>
                              updateOrderItem(
                                item.id,
                                "quantity",
                                item.quantity + 1,
                              )
                            }
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>

                        <div className="text-right">
                          <div className="font-medium">
                            SAR {item.amount.toFixed(2)}
                          </div>
                        </div>

                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 w-8 p-0 text-red-600 hover:bg-red-50"
                          onClick={() => removeOrderItem(item.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>

                  {/* Order Changes Summary */}
                  {parkedOrder && editedOrder && (
                    <div className="mt-4 pt-4 border-t">
                      <div className="text-sm font-medium text-gray-700 mb-2">
                        Order Changes:
                      </div>
                      <div className="space-y-1 text-xs">
                        {editedOrder.items.length !==
                          parkedOrder.items.length && (
                          <div className="text-blue-600">
                            • Items count: {parkedOrder.items.length} →{" "}
                            {editedOrder.items.length}
                          </div>
                        )}
                        {editedOrder.grandTotal !== parkedOrder.grandTotal && (
                          <div className="text-green-600">
                            • Total: SAR {parkedOrder.grandTotal.toFixed(2)} →
                            SAR {editedOrder.grandTotal.toFixed(2)}
                          </div>
                        )}
                        {editedOrder.items.length ===
                          parkedOrder.items.length &&
                          editedOrder.grandTotal === parkedOrder.grandTotal && (
                            <div className="text-gray-500">
                              • No changes made
                            </div>
                          )}
                      </div>
                    </div>
                  )}

                  {/* Order Totals */}
                  <div className="mt-4 pt-4 border-t space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Net Total:</span>
                      <span>SAR {editedOrder.netTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>VAT (15%):</span>
                      <span>SAR {editedOrder.vatAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-medium text-base border-t pt-1">
                      <span>Grand Total:</span>
                      <span>SAR {editedOrder.grandTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Auto-Save Info */}
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="text-sm text-green-700 text-center">
                  <strong>✅ Auto-Save Active:</strong> Changes are
                  automatically saved and routed to kitchen stations.
                </div>
              </div>

              {/* Close Button */}
              <div className="flex justify-center">
                <Button
                  className="bg-blue-500 hover:bg-blue-600 text-white px-8"
                  onClick={onClose}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Item Dialog */}
      <Dialog open={showAddItemDialog} onOpenChange={setShowAddItemDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5 text-green-500" />
              Add Menu Item
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Search and Filter */}
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search menu items..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
              </div>
              <div className="w-48">
                <Select
                  value={selectedCategory}
                  onValueChange={setSelectedCategory}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Categories</SelectItem>
                    <SelectItem value="Starters">Starters</SelectItem>
                    <SelectItem value="Main Meals">Main Meals</SelectItem>
                    <SelectItem value="Burger Meals">Burger Meals</SelectItem>
                    <SelectItem value="Beverages">Beverages</SelectItem>
                    <SelectItem value="Desserts">Desserts</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Menu Items Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-h-96 overflow-y-auto">
              {availableMenuItems
                .filter((item) => {
                  const matchesCategory =
                    selectedCategory === "All" ||
                    item.category === selectedCategory;
                  const matchesSearch = item.name
                    .toLowerCase()
                    .includes(searchTerm.toLowerCase());
                  return matchesCategory && matchesSearch;
                })
                .map((item) => (
                  <div
                    key={item.id}
                    className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 hover:border-blue-300 transition-all"
                    onClick={() => addMenuItem(item)}
                  >
                    <div className="font-medium text-sm">{item.name}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {item.category}
                    </div>
                    <div className="text-sm font-medium text-blue-600 mt-2">
                      SAR {item.price.toFixed(2)}
                    </div>
                    <Button
                      size="sm"
                      className="w-full mt-2 bg-green-500 hover:bg-green-600 text-xs py-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        addMenuItem(item);
                      }}
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add
                    </Button>
                  </div>
                ))}
            </div>

            {/* Footer */}
            <div className="flex justify-end pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddItemDialog(false);
                  setSearchTerm("");
                  setSelectedCategory("All");
                }}
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-600">
              Delete Parked Order
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>
              Are you sure you want to delete the parked order{" "}
              <strong>{editedOrder.id}</strong>? This action cannot be undone.
            </p>
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowDeleteConfirm(false)}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 bg-red-600 hover:bg-red-700"
                onClick={handleDelete}
              >
                Delete Order
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
