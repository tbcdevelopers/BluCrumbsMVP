import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Printer, X } from "lucide-react";

interface InvoiceItem {
  id: string;
  name: string;
  nameArabic?: string;
  code: string;
  unitPrice: number;
  quantity: number;
  subtotal: number;
}

interface InvoiceData {
  invoiceNumber: string;
  invoiceDate: string;
  customerName?: string;
  customerNameArabic?: string;
  items: InvoiceItem[];
  totalTaxableAmount: number;
  totalVAT: number;
  totalDiscount: number;
  additionalDiscount: number;
  totalAmountDue: number;
  paymentReceived: number;
  amountRemaining: number;
  remarks?: string;
}

interface InvoicePrintProps {
  isOpen: boolean;
  onClose: () => void;
  invoiceData: InvoiceData;
  companyInfo?: {
    name: string;
    nameArabic: string;
    address: string;
    addressArabic: string;
    vatNumber: string;
    logo?: string;
  };
}

export default function InvoicePrint({
  isOpen,
  onClose,
  invoiceData,
  companyInfo = {
    name: "Alhandasa Stationary",
    nameArabic: "مكتبة الهندسة",
    address: "6456, Airport Road, Jazan, 82724",
    addressArabic: "6456,طريق المطار, جازان,82724",
    vatNumber: "302282048700003",
    logo: "https://restaurants.blubooks.me/Upload/CompanyLogo/_231b3565-d69a-43c0-a17e-3d2c219cf28c.png",
  },
}: InvoicePrintProps) {
  const handlePrint = () => {
    // Add print styles
    const printStyles = `
      <style>
        @media print {
          body * { visibility: hidden; }
          #invoice-content, #invoice-content * { visibility: visible; }
          #invoice-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            background: white;
          }
          .no-print { display: none !important; }
        }
      </style>
    `;

    // Add the styles to head
    const head = document.getElementsByTagName("head")[0];
    const style = document.createElement("style");
    style.innerHTML = printStyles;
    head.appendChild(style);

    // Print
    window.print();

    // Clean up
    setTimeout(() => {
      head.removeChild(style);
    }, 1000);
  };

  const generateQRCode = () => {
    // QR code data would be generated based on Saudi e-invoicing standards
    const qrData = `${companyInfo.name}|${companyInfo.vatNumber}|${invoiceData.invoiceDate}|${invoiceData.totalAmountDue}|${invoiceData.totalVAT}`;
    // For demo purposes, using a placeholder QR code
    return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAAD6CAIAAAAHjs1qAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABs6SURBVHhe7dJBjiS7jgDBuf+l/2zMgd6wQQihzMbLsKWDlFJV8X//e71+xvu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I+7m/fsj7ub9+yPu5v37I9c/9/z7FfVF37ETdsRM16sBQ1AtcEDVq1Kj3ue+m63d4yn3ui7pjJ+qOnahRB4aiXuCCqFGjRr3PfTddv8NT7nNf1B07UXfsRI06MBT1AhdEjRo16n3uu+n6HZ5yn/ui7tiJumMnatSBoagXuCBq1KhR73PfTdfv8JT73Bd1x07UHTtRow4MRb3ABVGjRo16n/tuun6Hp0R9ghOjRt2xMzA0MDQwFDXqwNCOnYGhI46I+gQnRr3p+h2eEvUJTowadcfOwNDA0MBQ1KgDQzt2BoaOOCLqE5wY9abrd3hK1Cc4MWrUHTsDQwNDA0NRow4M7dgZGDriiKhPcGLUm67f4SlRn+DEqFF37AwMDQwNDEWNOjC0Y2dg6Igjoj7BiVFvun6Hp0R9ghOjRt2xMzA0MDQwFDXqwNCOnYGhI46I+gQnRr3p+h2eEjXqjp2oUaNGjTowNDAUNerA0I6dqFEHhqLu2IkaNeqOnahRb7p+h6dEjbpjJ2rUqFGjDgwNDEWNOjC0Yydq1IGhqDt2okaNumMnatSbrt/hKVGj7tiJGjVq1KgDQwNDUaMODO3YiRp1YCjqjp2oUaPu2Ika9abrd3hK1Kg7dqJGjRo16sDQwFDUqANDO3aiRh0YirpjJ2rUqDt2oka96fodnhI16o6dqFGjRo06MDQwFDXqwNCOnahRB4ai7tiJGjXqjp2oUW+6foenRI26Yydq1KgDQ1GjRh0YirpjJ2rUgaGoUXfsDAxFjbpjJ2rUm67f4SlRo+7YiRo16sBQ1KhRB4ai7tiJGnVgKGrUHTsDQ1Gj7tiJGvWm63d4StSoO3aiRo06MBQ1atSBoag7dqJGHRiKGnXHzsBQ1Kg7dqJGven6HZ4SNeqOnahrow4MRY0adWAo6o6dqFEHhqJG3bEzMBQ16o6dqFFvun6Hp0SNumMnatSoA0NRo0YdGIq6Yydq1IGhqFF37AwMRY26Yydq1Juu3+EpUaPu2Ika9QIXRI06MBQ1atQdO09wYtSoUaPu2Ika9abrd3hK1Kg7dqJGvcAFUaMODEWNGnXHzhOcGDVq1Kg7dqJGven6HZ4SNeqOnahRL3BB1KgDQ1GjRt2x8wQnRo0aNeqOnahRb7p+h6dEjbpjJ2rUC1wQNerAUNSoUXfsPMGJUaNGjbpjJ2rUm67f4SlRo+7YiRr1AhdEjTowFDVq1B07T3Bi1KhRo+7YiRr1put3eErUJzgxatSoA0MDQxe4IGrUqEccETVq1KhRn+DEqDddv8NToj7BiVGjRh0YGhi6wAVRo0Y94oioUaNGjfoEJ0a96fodnhL1CU6MGjXqwNDA0AUuiBo16hFHRI0aNWrUJzgx6k3X7/CUqE9wYtSoUQeGBoYucEHUqFGPOCJq1KhRoz7BiVFvun6Hp0R9ghOjRo06MDQwdIELokaNesQRUaNGjRr1CU6MetP1OzzlPvdFjRo1atSoUaNGjRo1atSoUaNGjRo1atSoUe9z303X7/CU+9wXNWrUqFGjRo0aNWrUqFGjRo0aNWrUqFGjRr3PfTddv8NT7nNf1KhRo0aNGjVq1KhRo0aNGjVq1KhRo0aNGvU+9910/Q5Puc99UaNGjRo1atSoUaNGjRo1atSoUaNGjRo1atT73HfT9Ts85T73RY0aNWrUqFGjRo0aNWrUqFGjRo0aNWrUqFHvc99Nn7jjX+AvGnVgKGrUgaGoUXfsHHHEwNDA0H/Rf/ltf/KfjDowFDXqwFDUqDt2jjhiYGhg6L/ov/y2P/lPRh0Yihp1YChq1B07RxwxMDQw9F/0X37bn/wnow4MRY06MBQ16o6dI44YGBoY+i/6L7/tT/6TUQeGokYdGIoadcfOEUcMDA0M/Rddf5s/4cDQwNCOnSOOiBo1atSoO3YGhqIecUTUqDt2okY94oibrt/hKQNDA0M7do44ImrUqFGj7tgZGIp6xBFRo+7YiRr1iCNuun6HpwwMDQzt2DniiKhRo0aNumNnYCjqEUdEjbpjJ2rUI4646fodnjIwNDC0Y+eII6JGjRo16o6dgaGoRxwRNeqOnahRjzjiput3eMrA0MDQjp0jjogaNWrUqDt2BoaiHnFE1Kg7dqJGPeKIm67f4SlRB4ai7tiJOjAUNeqOnahRow4MPcGJA0NRd+xEHRgaGIp60/U7PCXqwFDUHTtRB4aiRt2xEzVq1IGhJzhxYCjqjp2oA0MDQ1Fvun6Hp0QdGIq6YyfqwFDUqDt2okaNOjD0BCcODEXdsRN1YGhgKOpN1+/wlKgDQ1F37EQdGIoadcdO1KhRB4ae4MSBoag7dqIODA0MRb3p+h2eEnVgKOqOnagDQ1Gj7tiJGjXqwNATnDgwFHXHTtSBoYGhqDddv8NT7nPfEUfs2Il6xBEDQ0ccMTAUNWrUqAND/6rrv8+f4T73HXHEjp2oRxwxMHTEEQNDUaNGjTow9K+6/vv8Ge5z3xFH7NiJesQRA0NHHDEwFDVq1KgDQ/+q67/Pn+E+9x1xxI6dqEccMTB0xBEDQ1GjRo06MPSvuv77/Bnuc98RR+zYiXrEEQNDRxwxMBQ1atSoA0P/qk//Pn+VqFF37AwMDQxFjbpj54gjog4MDQxFjfoEJ+7Y2bFz0yfu+JOXRY26Y2dgaGAoatQdO0ccEXVgaGAoatQnOHHHzo6dmz5xx5+8LGrUHTsDQwNDUaPu2DniiKgDQwNDUaM+wYk7dnbs3PSJO/7kZVGj7tgZGBoYihp1x84RR0QdGBoYihr1CU7csbNj56ZP3PEnL4sadcfOwNDAUNSoO3aOOCLqwNDAUNSoT3Dijp0dOzd94o4/edmOnYGhHTs7dgaGoj7BiVEHhp7gxB07O3aiRo160yfu+JOX7dgZGNqxs2NnYCjqE5wYdWDoCU7csbNjJ2rUqDd94o4/edmOnYGhHTs7dgaGoj7BiVEHhp7gxB07O3aiRo160yfu+JOX7dgZGNqxs2NnYCjqE5wYdWDoCU7csbNjJ2rUqDd94o4/edmOnYGhHTs7dgaGoj7BiVEHhp7gxB07O3aiRo160yfu+JOXRY26Yydq1KhRd+xEjTowNDAUNeqOnSOOiDowNDAUNer3fPoXeHfUqDt2okaNGnXHTtSoA0MDQ1Gj7tg54oioA0MDQ1Gjfs+nf4F3R426Yydq1KhRd+xEjTowNDAUNeqOnSOOiDowNDAUNer3fPoXeHfUqDt2okaNGnXHTtSoA0MDQ1Gj7tg54oioA0MDQ1Gjfs+nf4F3R426Yydq1KhRd+xEjTowNDAUNeqOnSOOiDowNDAUNer3fPoXeHfUqEccsWMn6hFHRI0adcfOEUcMDEWNumMn6sDQ93z6F3h31KhHHLFjJ+oRR0SNGnXHzhFHDAxFjbpjJ+rA0Pd8+hd4d9SoRxyxYyfqEUdEjRp1x84RRwwMRY26YyfqwND3fPoXeHfUqEccsWMn6hFHRI0adcfOEUcMDEWNumMn6sDQ93z6F3h31KhHHLFjJ+oRR0SNGnXHzhFHDAxFjbpjJ+rA0Pd8/xfs+ZtFjbpjZ2AoatQnODHqEUcMDA0MRY0aNerA0I6dmz5xx1P8VaJG3bEzMBQ16hOcGPWIIwaGBoaiRo0adWBox85Nn7jjKf4qUaPu2BkYihr1CU6MesQRA0MDQ1GjRo06MLRj56ZP3PEUf5WoUXfsDAxFjfoEJ0Y94oiBoYGhqFGjRh0Y2rFz0yfueIq/StSoO3YGhqJGfYITox5xxMDQwFDUqFGjDgzt2LnpE3f8yct27AwMXeCCqFEHhqLu2IkaNWrUgaEdOwNDUaNGjRo16k2fuONPXrZjZ2DoAhdEjTowFHXHTtSoUaMODO3YGRiKGjVq1KhRb/rEHX/ysh07A0MXuCBq1IGhqDt2okaNGnVgaMfOwFDUqFGjRo160yfu+JOX7dgZGLrABVGjDgxF3bETNWrUqANDO3YGhqJGjRo1atSbPnHHn7xsx87A0AUuiBp1YCjqjp2oUaNGHRjasTMwFDVq1KhRo970iTv+5GUDQwNDUY84ImrUgaGBoSOOiBr1iCN27OzYiRo1atSoN33ijj952cDQwFDUI46IGnVgaGDoiCOiRj3iiB07O3aiRo0aNepNn7jjT142MDQwFPWII6JGHRgaGDriiKhRjzhix86OnahRo0aNetMn7viTlw0MDQxFPeKIqFEHhgaGjjgiatQjjtixs2MnatSoUaPe9Ik7/uRlA0MDQ1GPOCJq1IGhgaEjjoga9Ygjduzs2IkaNWrUqDd94o4/edkFLhgYOuKIgaGoA0NRow4MRY06MDQwtGPniCO+59O/wLsvcMHA0BFHDAxFHRiKGnVgKGrUgaGBoR07RxzxPZ/+Bd59gQsGho44YmAo6sBQ1KgDQ1GjDgwNDO3YOeKI7/n0L/DuC1wwMHTEEQNDUQeGokYdGIoadWBoYGjHzhFHfM+nf4F3X+CCgaEjjhgYijowFDXqwFDUqANDA0M7do444nuu/wIP3bHzBCcODEWNOjD0BCcODEU94ogjjogadWBox85N1+/wlB07T3DiwFDUqANDT3DiwFDUI4444oioUQeGduzcdP0OT9mx8wQnDgxFjTow9AQnDgxFPeKII46IGnVgaMfOTdfv8JQdO09w4sBQ1KgDQ09w4sBQ1COOOOKIqFEHhnbs3HT9Dk/ZsfMEJw4MRY06MPQEJw4MRT3iiCOOiBp1YGjHzk2fuOMvPHRgaGAoatSBoYGhqEccETVq1Kg7dnbsPMGJA0NRo0a96RN3/IWHDgwNDEWNOjA0MBT1iCOiRo0adcfOjp0nOHFgKGrUqDd94o6/8NCBoYGhqFEHhgaGoh5xRNSoUaPu2Nmx8wQnDgxFjRr1pk/c8RceOjA0MBQ16sDQwFDUI46IGjVq1B07O3ae4MSBoahRo970iTv+wkMHhgaGokYdGBoYinrEEVGjRo26Y2fHzhOcODAUNWrUmz5xx194aNSoA0MDQzt2BoaiDgzt2Il6xBEDQzt2okaNGnVgaGDopk/c8RceGjXqwNDA0I6dgaGoA0M7dqIeccTA0I6dqFGjRh0YGhi66RN3/IWHRo06MDQwtGNnYCjqwNCOnahHHDEwtGMnatSoUQeGBoZu+sQdf+GhUaMODA0M7dgZGIo6MLRjJ+oRRwwM7diJGjVq1IGhgaGbPnHHX3ho1KgDQwNDO3YGhqIODO3YiXrEEQNDO3aiRo0adWBoYOimT9zxJy/bsTMwFHXHTtSBoSOO2LFzxBFRo0YdGBoYiho16j/j0z/In2HHzsBQ1B07UQeGjjhix84RR0SNGnVgaGAoatSo/4xP/yB/hh07A0NRd+xEHRg64ogdO0ccETVq1IGhgaGoUaP+Mz79g/wZduwMDEXdsRN1YOiII3bsHHFE1KhRB4YGhqJGjfrP+PQP8mfYsTMwFHXHTtSBoSOO2LFzxBFRo0YdGBoYiho16j/j+g/y7oGhgaGoO3aiRo0aNWrUqFEHhnbsRB0YivoEJw4MDQzt2Lnp+h2eMjA0MBR1x07UqFGjRo0aNerA0I6dqANDUZ/gxIGhgaEdOzddv8NTBoYGhqLu2IkaNWrUqFGjRh0Y2rETdWAo6hOcODA0MLRj56brd3jKwNDAUNQdO1GjRo0aNWrUqANDO3aiDgxFfYITB4YGhnbs3HT9Dk8ZGBoYirpjJ2rUqFGjRo0adWBox07UgaGoT3DiwNDA0I6dm67f4SlRo0YdGHqCE6NGjRr1CU4cGIq6Y+eII444ImrUqFFvun6Hp0SNGnVg6AlOjBo1atQnOHFgKOqOnSOOOOKIqFGjRr3p+h2eEjVq1IGhJzgxatSoUZ/gxIGhqDt2jjjiiCOiRo0a9abrd3hK1KhRB4ae4MSoUaNGfYITB4ai7tg54ogjjogaNWrUm67f4SlRo0YdGHqCE6NGjRr1CU4cGIq6Y+eII444ImrUqFFvun6Hp+zYiTowtGMn6sBQ1KhRo0YdGIoaNeqOnYGhqFF37DzBiTddv8NTduxEHRjasRN1YChq1KhRow4MRY0adcfOwFDUqDt2nuDEm67f4Sk7dqIODO3YiTowFDVq1KhRB4aiRo26Y2dgKGrUHTtPcOJN1+/wlB07UQeGduxEHRiKGjVq1KgDQ1GjRt2xMzAUNeqOnSc48abrd3jKjp2oA0M7dqIODEWNGjVq1IGhqFGj7tgZGIoadcfOE5x40yfu2PPugaGo97kv6sBQ1Kg7dqJGjRp1x87AUNSoUaNG/Z7v/4I/+asMDEW9z31RB4aiRt2xEzVq1Kg7dgaGokaNGjXq93z/F/zJX2VgKOp97os6MBQ16o6dqFGjRt2xMzAUNWrUqFG/5/u/4E/+KgNDUe9zX9SBoahRd+xEjRo16o6dgaGoUaNGjfo93/8Ff/JXGRiKep/7og4MRY26Yydq1KhRd+wMDEWNGjVq1O/5/i/4C3+kqDt2og4MRd2xEzXqwFDUgaGoA0NRB4aiRj3iiKjf8/1f8Bf+SFF37EQdGIq6Yydq1IGhqANDUQeGog4MRY16xBFRv+f7v+Av/JGi7tiJOjAUdcdO1KgDQ1EHhqIODEUdGIoa9Ygjon7P93/BX/gjRd2xE3VgKOqOnahRB4aiDgxFHRiKOjAUNeoRR0T9nu//gr/wR4q6YyfqwFDUHTtRow4MRR0YijowFHVgKGrUI46I+j3Xf4GH7tjZsRM16o6dqFF37BxxxxMBQ1COOuM99A0NRb7p+h6fs2NmxEzXqjp2oUXfsHHHEwFDUI464z30DQ1Fvun6Hp+zY2bETNeqOnahRd+wcccTAUNQjjrjPfQNDUW+6foen7NjZsRM16o6dqFF37BxxxMBQ1COOuM99A0NRb7p+h6fs2NmxEzXqjp2oUXfsHHHEwFDUI464z30DQ1Fv+sQdX+FPuGNnx87A0I6dqDt2BoZ27ETdsRN1x07Umz5xx1f4E+7Y2bEzMLRjJ+qOnYGhHTtRd+xE3bET9aZP3PEV/oQ7dnbsDAzt2Im6Y2dgaMdO1B07UXfsRL3pE3d8hT/hjp0dOwNDO3ai7tgZGNqxE3XHTtQdO1Fv+sQdX+FPuGNnx87A0I6dqDt2BoZ27ETdsRN1x07Um67f4Sn3uW9gKOqOnahRo0YdGBoYihp1YGjHTtSoUaMODP0zrv8g777PfQNDUXfsRI0aNerA0MBQ1KgDQzt2okaNGnVg6J9x/Qd5933uGxiKumMnatSoUQeGBoaiRh0Y2rETNWrUqAND/4zrP8i773PfwFDUHTtRo0aNOjA0MBQ16sDQjp2oUaNGHRj6Z1z/Qd59n/sGhqLu2IkaNWrUgaGBoahRB4Z27ESNGjXqwNA/4/oP8u6oT3Bi1KhRo0aNGnVgKGrUqANDRxwxMBQ1atQdO1GjDgx90PUrvSzqE5wYNWrUqFGjRh0Yiho16sDQEUcMDEWNGnXHTtSoA0MfdP1KL4v6BCdGjRo1atSoUQeGokaNOjB0xBEDQ1GjRt2xEzXqwNAHXb/Sy6I+wYlRo0aNGjVq1IGhqFGjDgwdccTAUNSoUXfsRI06MPRB16/0sqhPcGLUqFGjRo0adWAoatSoA0NHHDEwFDVq1B07UaMODH3Q9Su9LGrUHTtRo0aNOjC0Y+cCF0SNGnVgKOrA0BOcGDVq1Kg3Xb/DU6JG3bETNWrUqANDO3YucEHUqFEHhqIODD3BiVGjRo160/U7PCVq1B07UaNGjTowtGPnAhdEjRp1YCjqwNATnBg1atSoN12/w1OiRt2xEzVq1KgDQzt2LnBB1KhRB4aiDgw9wYlRo0aNetP1OzwlatQdO1GjRo06MLRj5wIXRI0adWAo6sDQE5wYNWrUqDddv8NTokbdsRM16o6dqFF37EQ94oioUY84ImrUHTs7dqJ+z/Vf4KFRo+7YiRp1x07UqDt2oh5xRNSoRxwRNeqOnR07Ub/n+i/w0KhRd+xEjbpjJ2rUHTtRjzgiatQjjogadcfOjp2o33P9F3ho1Kg7dqJG3bETNeqOnahHHBE16hFHRI26Y2fHTtTvuf4LPDRq1B07UaPu2IkadcdO1COOiBr1iCOiRt2xs2Mn6vdc/wUeGjXqjp2oUY84IurA0I6dqFEHhnbsDAzt2IkadWBoYOh7rv8CD40adcdO1KhHHBF1YGjHTtSoA0M7dgaGduxEjTowNDD0Pdd/gYdGjbpjJ2rUI46IOjC0Yydq1IGhHTsDQzt2okYdGBoY+p7rv8BDo0bdsRM16hFHRB0Y2rETNerA0I6dgaEdO1GjDgwNDH3P9V/goVGj7tiJGvWII6IODO3YiRp1YGjHzsDQjp2oUQeGBoa+5/ov8NCoT3Bi1KgDQ0ccETXqjp2BoahRB4aiDgzt2BkYijow9EHXr/SyqE9wYtSoA0NHHBE16o6dgaGoUQeGog4M7dgZGIo6MPRB16/0sqhPcGLUqANDRxwRNeqOnYGhqFEHhqIODO3YGRiKOjD0Qdev9LKoT3Bi1KgDQ0ccETXqjp2BoahRB4aiDgzt2BkYijow9EHXr/SyqE9wYtSoA0NHHBE16o6dgaGoUQeGog4M7dgZGIo6MPRB16/0svvcFzXqwFDUHTtRo0aNGjVq1IGhgaGoUXfsDAxF3bFz0/U7POU+90WNOjAUdcdO1KhRo0aNGnVgaGAoatQdOwNDUXfs3HT9Dk+5z31Row4MRd2xEzVq1KhRo0YdGBoYihp1x87AUNQdOzddv8NT7nNf1KgDQ1F37ESNGjVq1KhRB4YGhqJG3bEzMBR1x85N1+/wlPvcFzXqwFDUHTtRo0aNGjVq1IGhgaGoUXfsDAxF3bFz0yfueL3+Ee/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++iHv5/76Ie/n/voh7+f++hn/+9//A5IIvTKicKfmAAAAAElFTkSuQmCC";
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-0">
        <DialogHeader className="p-4 border-b flex flex-row items-center justify-between no-print">
          <DialogTitle>Simplified Tax Invoice</DialogTitle>
          <div className="flex gap-2">
            <Button
              onClick={handlePrint}
              className="bg-green-500 hover:bg-green-600"
            >
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button variant="outline" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="p-0">
          <div
            id="invoice-content"
            className="bg-white p-6"
            style={{ fontFamily: "Arial, sans-serif" }}
          >
            {/* Header */}
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              <div style={{ fontWeight: "bold", fontSize: "18px" }}>
                فاتورة ضریبیة المبسطة
              </div>
              <div style={{ fontWeight: "bold", fontSize: "18px" }}>
                Simplified Tax Invoice
              </div>
            </div>

            {/* Company Info */}
            <div style={{ textAlign: "center", marginBottom: "20px" }}>
              {companyInfo.logo && (
                <img
                  src={companyInfo.logo}
                  alt="Company Logo"
                  style={{
                    height: "100px",
                    width: "100px",
                    marginBottom: "10px",
                  }}
                />
              )}
              <div style={{ fontSize: "16px", fontWeight: "bold" }}>
                {companyInfo.nameArabic}
              </div>
              <div style={{ fontSize: "16px", fontWeight: "bold" }}>
                {companyInfo.name}
              </div>
              <div style={{ fontSize: "12px", marginTop: "5px" }}>
                {companyInfo.addressArabic}
              </div>
              <div style={{ fontSize: "12px" }}>{companyInfo.address}</div>
              <div style={{ fontSize: "12px", marginTop: "5px" }}>
                VAT No : {companyInfo.vatNumber}
              </div>
            </div>

            {/* Invoice Details Table */}
            <div style={{ marginBottom: "20px" }}>
              <table
                style={{
                  width: "100%",
                  fontSize: "12px",
                  border: "1px solid #AEAAAA",
                  borderCollapse: "collapse",
                }}
              >
                <tbody>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        width: "25%",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Invoice Number
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        width: "50%",
                        textAlign: "center",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.invoiceNumber}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        width: "25%",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      رقم الفاتورة
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Invoice Issue Date
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "center",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.invoiceDate}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      تاریخ اصدار الفاتورة
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Customer Name
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "center",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.customerName || ""}
                      {invoiceData.customerNameArabic && (
                        <>
                          <br />
                          <span dir="rtl">
                            {invoiceData.customerNameArabic}
                          </span>
                        </>
                      )}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      اسم العميل
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Items Table */}
            <div style={{ marginBottom: "20px" }}>
              <table
                style={{
                  width: "100%",
                  fontSize: "12px",
                  border: "1px solid #AEAAAA",
                  borderCollapse: "collapse",
                }}
              >
                <thead>
                  <tr
                    style={{
                      backgroundColor: "#E7E6E6",
                      textAlign: "center",
                    }}
                  >
                    <th
                      style={{
                        padding: "5px",
                        width: "15%",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      <span>Code</span>
                      <br />
                      <span>كود</span>
                    </th>
                    <th
                      style={{
                        padding: "5px",
                        width: "35%",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      <span>Description</span>
                      <br />
                      <span>الوصف</span>
                    </th>
                    <th
                      style={{
                        padding: "5px",
                        width: "10%",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      <span>Unit Price</span>
                      <br />
                      <span>سعر الوحدة</span>
                    </th>
                    <th
                      style={{
                        padding: "5px",
                        width: "10%",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      <span>Quantity</span>
                      <br />
                      <span>الكمية</span>
                    </th>
                    <th
                      style={{
                        padding: "5px",
                        width: "30%",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      <span>Item Subtotal (Including VAT)</span>
                      <br />
                      <span dir="rtl">المجموع (شامل ضريبة القيمة المضافة)</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {invoiceData.items.map((item) => (
                    <tr key={item.id} style={{ textAlign: "center" }}>
                      <td
                        style={{
                          padding: "5px",
                          border: "1px solid #AEAAAA",
                        }}
                      >
                        {item.code}
                      </td>
                      <td
                        style={{
                          padding: "5px",
                          border: "1px solid #AEAAAA",
                        }}
                      >
                        <span>{item.name}</span>
                        {item.nameArabic && (
                          <>
                            <br />
                            <span dir="rtl">{item.nameArabic}</span>
                          </>
                        )}
                      </td>
                      <td
                        style={{
                          padding: "5px",
                          border: "1px solid #AEAAAA",
                        }}
                      >
                        {item.unitPrice.toFixed(2)}
                      </td>
                      <td
                        style={{
                          padding: "5px",
                          border: "1px solid #AEAAAA",
                        }}
                      >
                        {item.quantity}
                      </td>
                      <td
                        style={{
                          padding: "5px",
                          border: "1px solid #AEAAAA",
                        }}
                      >
                        {item.subtotal.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <hr style={{ backgroundColor: "black", height: "1px" }} />

            {/* Totals Table */}
            <div style={{ marginBottom: "20px" }}>
              <table
                style={{
                  width: "100%",
                  fontSize: "12px",
                  border: "1px solid #AEAAAA",
                  borderCollapse: "collapse",
                }}
              >
                <tbody>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        width: "40%",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Total Taxable Amount (Excluding VAT)
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        width: "20%",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.totalTaxableAmount.toFixed(2)}
                    </td>
                    <td
                      dir="rtl"
                      style={{
                        padding: "5px",
                        width: "40%",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      الإجمالي الخاضع للضريبة (غير شامل ضريبة القيمة المضافة)
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Total VAT
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.totalVAT.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      مجموع ضریبة القیمة المضافة
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Discount
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.totalDiscount.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      مجموع الخصومات
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Additional Discount
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.additionalDiscount.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      الخصومات إضافي
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Total Amount Due (Inclusive of VAT)
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.totalAmountDue.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      إجمالي المبلغ المستحق
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Payment Received
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.paymentReceived.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      المبلغ المستلم
                    </td>
                  </tr>
                  <tr>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "left",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      Amount Remaining
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      {invoiceData.amountRemaining.toFixed(2)}
                    </td>
                    <td
                      style={{
                        padding: "5px",
                        textAlign: "right",
                        border: "1px solid #AEAAAA",
                      }}
                    >
                      المبلغ المتبقي
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Remarks */}
            <table
              style={{
                width: "100%",
                fontSize: "12px",
                border: "1px solid #AEAAAA",
                borderCollapse: "collapse",
                marginBottom: "20px",
              }}
            >
              <tbody>
                <tr>
                  <td
                    style={{
                      padding: "5px",
                      border: "1px solid #AEAAAA",
                    }}
                  >
                    <span>Remarks : {invoiceData.remarks || ""}</span>
                    <span
                      dir="rtl"
                      style={{
                        float: "right",
                      }}
                    >
                      ملاحظات:
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>

            <hr style={{ backgroundColor: "black", height: "1px" }} />

            {/* QR Code */}
            <div style={{ textAlign: "center", paddingTop: "20px" }}>
              <img
                src={generateQRCode()}
                alt="QR Code"
                style={{
                  height: "150px",
                  width: "150px",
                }}
              />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
