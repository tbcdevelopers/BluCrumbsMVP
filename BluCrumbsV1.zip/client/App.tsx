import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ReservationsProvider } from "./contexts/ReservationsContext";
import { ParkedOrdersProvider } from "./contexts/ParkedOrdersContext";
import MainLayout from "./components/layout/MainLayout";
import Dashboard from "./pages/Dashboard";
import Company from "./pages/configuration/Company";
import Branches from "./pages/configuration/Branches";
import Storage from "./pages/configuration/Storage";
import Floors from "./pages/configuration/Floors";
import Sections from "./pages/configuration/Sections";
import Stations from "./pages/configuration/Stations";
import CashRegisters from "./pages/configuration/CashRegisters";
import CashRegisterLog from "./pages/configuration/CashRegisterLog";
import SpanTerminals from "./pages/configuration/SpanTerminals";
import StaffDetails from "./pages/configuration/StaffDetails";
import Teams from "./pages/configuration/Teams";
import Categories from "./pages/configuration/Categories";
import Layout from "./pages/configuration/Layout";
import Staff from "./pages/staff/Staff";
import Management from "./pages/staff/Management";
import StaffSchedules from "./pages/staff/StaffSchedules";
import Schedules from "./pages/management/Schedules";
import Checklists from "./pages/management/Checklists";
import AssignChecklist from "./pages/management/AssignChecklist";
import MyChecklist from "./pages/management/MyChecklist";
import KitchenItems from "./pages/inventory/KitchenItems";
import MenuItems from "./pages/inventory/MenuItems";
import PantryRequests from "./pages/transfers/PantryRequests";
import GoodsIssuance from "./pages/transfers/GoodsIssuance";
import GoodsReceiving from "./pages/transfers/GoodsReceiving";
import PurchaseRequest from "./pages/purchases/PurchaseRequest";
import PurchaseOrder from "./pages/purchases/PurchaseOrder";
import VendorReceiving from "./pages/purchases/VendorReceiving";
import Customer from "./pages/sales/Customer";
import Promotions from "./pages/sales/Promotions";
import Closing from "./pages/sales/Closing";
import POS from "./pages/sales/POS";
import Reservations from "./pages/sales/Reservations";
import LiveOrders from "./pages/sales/LiveOrders";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// Suppress ResizeObserver loop warnings that are harmless
window.addEventListener("error", (e) => {
  if (
    e.message ===
    "ResizeObserver loop completed with undelivered notifications."
  ) {
    e.stopImmediatePropagation();
  }
});

// Also suppress console errors for ResizeObserver
const originalError = console.error;
console.error = function (...args) {
  if (
    args[0]?.includes?.(
      "ResizeObserver loop completed with undelivered notifications",
    )
  ) {
    return;
  }
  originalError.apply(console, args);
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <ReservationsProvider>
        <ParkedOrdersProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route
                path="/"
                element={
                  <MainLayout>
                    <Dashboard />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/company"
                element={
                  <MainLayout>
                    <Company />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/branches"
                element={
                  <MainLayout>
                    <Branches />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/storage"
                element={
                  <MainLayout>
                    <Storage />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/floors"
                element={
                  <MainLayout>
                    <Floors />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/sections"
                element={
                  <MainLayout>
                    <Sections />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/stations"
                element={
                  <MainLayout>
                    <Stations />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/cash-registers"
                element={
                  <MainLayout>
                    <CashRegisters />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/span-terminals"
                element={
                  <MainLayout>
                    <SpanTerminals />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/staff-details"
                element={
                  <MainLayout>
                    <StaffDetails />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/teams"
                element={
                  <MainLayout>
                    <Teams />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/categories"
                element={
                  <MainLayout>
                    <Categories />
                  </MainLayout>
                }
              />
              <Route
                path="/configuration/layout"
                element={
                  <MainLayout>
                    <Layout />
                  </MainLayout>
                }
              />
              <Route
                path="/staff/members"
                element={
                  <MainLayout>
                    <Staff />
                  </MainLayout>
                }
              />
              <Route
                path="/staff/management"
                element={
                  <MainLayout>
                    <Management />
                  </MainLayout>
                }
              />
              <Route
                path="/staff/schedules"
                element={
                  <MainLayout>
                    <StaffSchedules />
                  </MainLayout>
                }
              />
              <Route
                path="/management/schedules"
                element={
                  <MainLayout>
                    <Schedules />
                  </MainLayout>
                }
              />
              <Route
                path="/management/checklists"
                element={
                  <MainLayout>
                    <Checklists />
                  </MainLayout>
                }
              />
              <Route
                path="/management/assign-checklist"
                element={
                  <MainLayout>
                    <AssignChecklist />
                  </MainLayout>
                }
              />
              <Route
                path="/management/my-checklist"
                element={
                  <MainLayout>
                    <MyChecklist />
                  </MainLayout>
                }
              />
              <Route
                path="/inventory/kitchen-items"
                element={
                  <MainLayout>
                    <KitchenItems />
                  </MainLayout>
                }
              />
              <Route
                path="/inventory/menu"
                element={
                  <MainLayout>
                    <MenuItems />
                  </MainLayout>
                }
              />
              <Route
                path="/transfers/requests"
                element={
                  <MainLayout>
                    <PantryRequests />
                  </MainLayout>
                }
              />
              <Route
                path="/transfers/issuance"
                element={
                  <MainLayout>
                    <GoodsIssuance />
                  </MainLayout>
                }
              />
              <Route
                path="/transfers/receiving"
                element={
                  <MainLayout>
                    <GoodsReceiving />
                  </MainLayout>
                }
              />
              <Route
                path="/purchases/request"
                element={
                  <MainLayout>
                    <PurchaseRequest />
                  </MainLayout>
                }
              />
              <Route
                path="/purchases/order"
                element={
                  <MainLayout>
                    <PurchaseOrder />
                  </MainLayout>
                }
              />
              <Route
                path="/purchases/receiving"
                element={
                  <MainLayout>
                    <VendorReceiving />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/customer"
                element={
                  <MainLayout>
                    <Customer />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/customers"
                element={
                  <MainLayout>
                    <Customer />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/promotions"
                element={
                  <MainLayout>
                    <Promotions />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/reservations"
                element={
                  <MainLayout>
                    <Reservations />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/live-orders"
                element={
                  <MainLayout>
                    <LiveOrders />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/pos"
                element={
                  <MainLayout>
                    <POS />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/closing"
                element={
                  <MainLayout>
                    <Closing />
                  </MainLayout>
                }
              />
              <Route
                path="/sales/register-log"
                element={
                  <MainLayout>
                    <CashRegisterLog />
                  </MainLayout>
                }
              />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route
                path="*"
                element={
                  <MainLayout>
                    <NotFound />
                  </MainLayout>
                }
              />
            </Routes>
          </BrowserRouter>
        </ParkedOrdersProvider>
      </ReservationsProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
