/// <reference types="vite/client" />

// Extend HTMLElement to include _reactRoot property
declare global {
  interface HTMLElement {
    _reactRoot?: any;
  }
}
