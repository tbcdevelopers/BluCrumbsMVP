export interface Reservation {
  id: string;
  customer: string;
  mobileNumber: string;
  date: string;
  timeStart: string;
  timeEnd: string;
  peopleCount: number;
  tableNumber?: string;
  description: string;
  status: "confirmed" | "pending" | "cancelled" | "completed";
  createdDate: string;
}

export interface ReservationContextType {
  reservations: Reservation[];
  setReservations: (reservations: Reservation[]) => void;
  addReservation: (reservation: Reservation) => void;
  updateReservation: (id: string, updates: Partial<Reservation>) => void;
  deleteReservation: (id: string) => void;
  getTableReservations: (tableNumber: string, date?: string) => Reservation[];
  isTableReserved: (tableNumber: string, currentTime?: string) => boolean;
}

// Utility functions
export const isCurrentTimeInReservation = (reservation: Reservation): boolean => {
  const now = new Date();
  const today = now.toISOString().split('T')[0];
  const currentTime = now.toTimeString().substring(0, 5);
  
  return (
    reservation.date === today &&
    reservation.status === 'confirmed' &&
    currentTime >= reservation.timeStart &&
    currentTime <= reservation.timeEnd
  );
};

export const getTableStatus = (tableNumber: string, reservations: Reservation[]): "available" | "occupied" | "reserved" => {
  const activeReservations = reservations.filter(res => 
    res.tableNumber === tableNumber && 
    (res.status === 'confirmed' || res.status === 'pending')
  );
  
  // Check if any reservation is currently active
  const currentlyOccupied = activeReservations.some(isCurrentTimeInReservation);
  if (currentlyOccupied) return "occupied";
  
  // Check if there are future reservations today
  const now = new Date();
  const today = now.toISOString().split('T')[0];
  const hasReservationToday = activeReservations.some(res => res.date === today);
  if (hasReservationToday) return "reserved";
  
  return "available";
};
