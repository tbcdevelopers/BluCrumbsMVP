// Shared interfaces for inventory management across the application

export interface BaseInventoryItem {
  id: string;
  code: string;
  description: string;
  unit: string;
  hasExpiry: boolean; // Controls visibility of expiry date and lot number fields
  status: "active" | "inactive";
}

// Sub-allocation interface for splitting received quantities
export interface ReceivingSubAllocation {
  id: string;
  quantity: number;
  expiryDate: string; // Required for sub-allocations
  lotNumber: string; // Required for sub-allocations
}

export interface InventoryItemWithCost extends BaseInventoryItem {
  unitCost: number;
}

// Base receiving line item interface
export interface BaseReceivingLineItem {
  id: string;
  code: string;
  description: string;
  unit: string;
  hasExpiry: boolean;
  quantityReceived: number;
  quantityShort: number;
  quantityExcess: number;

  // Sub-allocations for items with expiry
  subAllocations?: ReceivingSubAllocation[];

  // Legacy fields for backward compatibility (when sub-allocations not used)
  expiryDate?: string; // ISO date string, required when hasExpiry is true
  lotNumber?: string; // Required when hasExpiry is true
}

// Vendor receiving specific line item
export interface VendorReceivingLineItem extends BaseReceivingLineItem {
  unitCost: number;
  quantityOrdered: number;
  quantityShipped: number;
}

// Internal transfer receiving specific line item
export interface InternalReceivingLineItem extends BaseReceivingLineItem {
  quantityAvailable: number;
  quantityAllocated: number;
  transferQuantity: number;
}

// For mock data and API responses
export interface MockInventoryItem extends BaseInventoryItem {
  unitCost?: number;
  available?: number;
  allocated?: number;
}

export const mockInventoryItemsWithExpiry: MockInventoryItem[] = [
  {
    id: "OIL001",
    code: "OIL001",
    description: "Premium Olive Oil",
    unitCost: 25.5,
    unit: "ltr",
    hasExpiry: true,
    status: "active",
  },
  {
    id: "TOM001",
    code: "TOM001",
    description: "Fresh Tomatoes",
    unitCost: 8.0,
    unit: "kg",
    hasExpiry: true,
    status: "active",
  },
  {
    id: "CHK001",
    code: "CHK001",
    description: "Chicken Breast",
    unitCost: 18.0,
    unit: "kg",
    hasExpiry: true,
    status: "active",
  },
  {
    id: "RIC001",
    code: "RIC001",
    description: "Basmati Rice",
    unitCost: 12.0,
    unit: "kg",
    hasExpiry: false,
    status: "active",
  },
  {
    id: "ONI001",
    code: "ONI001",
    description: "White Onions",
    unitCost: 6.5,
    unit: "kg",
    hasExpiry: false,
    status: "active",
  },
  {
    id: "CAN001",
    code: "CAN001",
    description: "Canned Beans",
    unitCost: 4.5,
    unit: "can",
    hasExpiry: true,
    status: "active",
  },
  {
    id: "FLR001",
    code: "FLR001",
    description: "All Purpose Flour",
    unitCost: 3.2,
    unit: "kg",
    hasExpiry: false,
    status: "active",
  },
];
